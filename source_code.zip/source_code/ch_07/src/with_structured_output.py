from __future__ import annotations

from .config import OPENAI_API_KEY
import os

from typing import Literal

from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

class RiskAssessment(BaseModel):
    risk_level: Literal["low", "medium", "high"] = Field(
        description="Overall risk level for taking the position given the headline."
    )
    reasoning: str = Field(description="Short justification grounded in the headline.")
    recommended_action: Literal["hold", "reduce", "exit", "hedge"] = Field(
        description="What to do with the position."
    )
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence from 0 to 1.")


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a trading risk assistant."),
        (
            "human",
            "Headline: {headline}\n"
            "Position: {position}\n"
            "Time horizon: {horizon}\n"
            "Assess the risk and recommend an action.",
        ),
    ]
)

llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0)

# Controlled generation: enforce the schema at generation time, then parse into RiskAssessment.
# - strict=True: fail if the model output does not conform to the schema.
# - include_raw=True: return both the parsed object and the raw model message.
structured_llm = llm.with_structured_output(
    RiskAssessment,
    method="json_schema",
    strict=True,
    include_raw=True,
)

chain = prompt | structured_llm

out = chain.invoke(
    {
        "headline": "Regulator opens probe into major chip supplier accounting practices",
        "position": "Long 2% portfolio weight",
        "horizon": "2 weeks",
    }
)

raw = out["raw"]                  # The original model message
parsed: RiskAssessment | None = out["parsed"]
parsing_error: Exception | None = out["parsing_error"]

print("---- RAW MODEL MESSAGE ----")
print(raw)

if parsing_error:
    raise parsing_error

print("---- PARSED OBJECT ----")
print(parsed.model_dump())



