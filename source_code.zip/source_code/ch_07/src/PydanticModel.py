from __future__ import annotations

from typing import Literal
from .config import OPENAI_API_KEY
import os

from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers.pydantic import PydanticOutputParser

class RiskAssessment(BaseModel):
    risk_level: Literal["low", "medium", "high"] = Field(
        description="Overall risk level for taking the position given the headline."
    )
    reasoning: str = Field(description="Short justification grounded in the headline.")
    recommended_action: Literal["hold", "reduce", "exit", "hedge"] = Field(
        description="What to do with the position."
    )
    confidence: float = Field(
        ge=0.0, le=1.0, description="Confidence in this assessment, from 0 to 1."
    )


parser = PydanticOutputParser(pydantic_object=RiskAssessment)

prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a trading risk assistant. "
            "Return ONLY data that matches the required schema.\n{format_instructions}",
        ),
        (
            "human",
            "Headline: {headline}\n"
            "Position: {position}\n"
            "Time horizon: {horizon}\n"
            "Assess the risk and recommend an action.",
        ),
    ]
).partial(format_instructions=parser.get_format_instructions())

llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0.2)

chain = prompt | llm | parser

result: RiskAssessment = chain.invoke(
    {
        "headline": "Regulator opens probe into major chip supplier accounting practices",
        "position": "Long 2% portfolio weight",
        "horizon": "2 weeks",
    }
)

print(result.model_dump())
