from __future__ import annotations

from pydantic import BaseModel, Field, ValidationError


class Resume(BaseModel):
    first_name: str = Field(...)
    last_name: str = Field(...)
    email: str | None = None


raw_json = '{"first_name":"Ada","last_name":"Lovelace","email":"ada@example.com"}'

try:
    resume = Resume.model_validate_json(raw_json)
except ValidationError as e:
    raise RuntimeError(f"Invalid structured output: {e}") from e

print(resume)