from langchain_core.language_models.fake import FakeStreamingListLLM
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser

prompt = ChatPromptTemplate.from_template(
    "Return ONLY a JSON object with keys: ticker (string), action (string)."
)

model = FakeStreamingListLLM(responses=['{"ticker":"MSFT","action":"BUY"}'])
parser = JsonOutputParser()

chain = prompt | model | parser
result = chain.invoke({})

print(result)  # {'ticker': 'MSFT', 'action': 'BUY'}


