from __future__ import annotations
from typing import Any, Optional
from langchain_core.runnables import Runnable

class PrintTagsAndMetadata(Runnable[str, str]):
    def invoke(self, input: str, config: Optional[dict[str, Any]] = None, **kwargs: Any) -> str:
        cfg = config or {}
        print("TAGS:", cfg.get("tags", []))
        print("METADATA:", cfg.get("metadata", {}))
        return input  # pass-through

class SimpleAnswer(Runnable[str, str]):
    def invoke(self, input: str, config: Optional[dict[str, Any]] = None, **kwargs: Any) -> str:
        return f"Answer: I received your question: {input}"

pipeline = PrintTagsAndMetadata() | SimpleAnswer()

configured_pipeline = pipeline.with_config(
    tags=["support", "public_site"],
    metadata={"component": "order_assistant", "version": "v1"},
)

result = configured_pipeline.invoke("Where is my order?")
print("RESULT:", result)