from __future__ import annotations

from typing import Dict, Any

from langchain_core.runnables import RunnableLambda
from langchain_core.runnables.router import RouterRunnable


# --- 1) Domain-specific subchains (plain Python here, but they can be prompts/models/retrievers/etc.) ---
def support_chain(payload: Dict[str, Any]) -> str:
    return f"[SUPPORT] Created ticket for user={payload.get('user_id')}: {payload['text']}"

def sales_chain(payload: Dict[str, Any]) -> str:
    return f"[SALES] Drafted offer response for user={payload.get('user_id')}: {payload['text']}"

def trading_chain(payload: Dict[str, Any]) -> str:
    return f"[TRADING] Classified intent and requested market data: {payload['text']}"

def default_chain(payload: Dict[str, Any]) -> str:
    return f"[DEFAULT] I don't know the domain yet; asking a clarification: {payload['text']}"


support = RunnableLambda(support_chain)
sales = RunnableLambda(sales_chain)
trading = RunnableLambda(trading_chain)
default = RunnableLambda(default_chain)


# --- 2) RouterRunnable mapping: route key -> runnable ---
router = RouterRunnable(
    runnables={
        "support": support,
        "sales": sales,
        "trading": trading,
        "default": default,
    }
)

# --- 3) Classifier: produces the RouterRunnable input shape: {"key": ..., "input": ...} ---
def classify_to_router_input(payload: Dict[str, Any]) -> Dict[str, Any]:
    text = payload["text"].lower()

    if any(k in text for k in ("refund", "incident", "error", "broken", "cannot", "can't", "problem")):
        route = "support"
    elif any(k in text for k in ("price", "quote", "buy", "purchase", "plan", "subscription")):
        route = "sales"
    elif any(k in text for k in ("stock", "btc", "price chart", "trade", "position", "portfolio")):
        route = "trading"
    else:
        route = "default"

    # RouterRunnable expects:
    # - "key": route name
    # - "input": payload to pass to the selected runnable
    return {"key": route, "input": payload}


classifier = RunnableLambda(classify_to_router_input)

# --- 4) Full routing pipeline ---
routed_pipeline = classifier | router


# --- 5) Demo ---
examples = [
    {"user_id": "u-123", "text": "I can't log in; getting an error after reset."},
    {"user_id": "u-456", "text": "Can you send me a quote for the Enterprise plan?"},
    {"user_id": "u-789", "text": "BTC price chart for the last 7 days and any big moves?"},
    {"user_id": "u-000", "text": "Hello there."},
]

for e in examples:
    print(routed_pipeline.invoke(e))



