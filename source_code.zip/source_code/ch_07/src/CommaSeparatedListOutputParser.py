from langchain_core.language_models.fake import FakeStreamingListLLM
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import CommaSeparatedListOutputParser

prompt = ChatPromptTemplate.from_template(
    "Return ONLY a comma-separated list of three tickers."
)

model = FakeStreamingListLLM(responses=["MSFT, AAPL, NVDA"])
parser = CommaSeparatedListOutputParser()

chain = prompt | model | parser
result = chain.invoke({})

print(result)
