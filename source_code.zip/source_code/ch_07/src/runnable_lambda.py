from .config import OPENAI_API_KEY

import asyncio
from typing import List

from langchain_core.runnables import RunnableLambda
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

# -----------------------------
# 1. Safety check for configuration
# -----------------------------
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Please configure it in config.py or your environment.")

# -----------------------------
# 2. Sample knowledge base
# -----------------------------
KNOWLEDGE_ARTICLES: List[dict] = [
    {
        "id": "order-tracking",
        "title": "How to track your order",
        "content": (
            "You can track your order from the 'My Orders' section of your account. "
            "Tracking is available once the order has been shipped. "
            "If tracking information is missing for more than 24 hours, "
            "contact support with your order number."
        ),
    },
    {
        "id": "returns-policy",
        "title": "Returns and refunds policy",
        "content": (
            "You can return most items within 30 days of delivery. "
            "Refunds are issued to the original payment method once the returned "
            "item has been inspected. Some sale items may be final sale and "
            "not eligible for return."
        ),
    },
    {
        "id": "shipping-times",
        "title": "Shipping times",
        "content": (
            "Standard shipping usually takes 3–5 business days after dispatch. "
            "Express shipping is typically 1–2 business days in eligible regions."
        ),
    },
]

# -----------------------------
# 3. Runnables for preprocessing and retrieval
# -----------------------------
def normalise_question(raw: str) -> str:
    """
    Clean up user input:
    - strip leading/trailing spaces
    - collapse multiple spaces
    - lower-case for simple matching
    """
    cleaned = raw.strip()
    cleaned = " ".join(cleaned.split())
    return cleaned.lower()


normalize_runnable = RunnableLambda(normalise_question)


def simple_keyword_retriever(question: str) -> List[str]:
    """
    Very naive retriever:
    - looks for simple keywords in the normalised question
    - returns the 'content' fields of matching articles
    """
    q = question.lower()
    articles: List[str] = []

    if "order" in q or "track" in q:
        articles.append(KNOWLEDGE_ARTICLES[0]["content"])
    if "return" in q or "refund" in q:
        articles.append(KNOWLEDGE_ARTICLES[1]["content"])
    if "shipping" in q or "delivery" in q:
        articles.append(KNOWLEDGE_ARTICLES[2]["content"])

    if not articles:
        articles.append(
            "No specific article matched this question. "
            "Explain that the customer should check the Help Center or contact support."
        )

    return articles


# -----------------------------
# 4. LCEL support chain
# -----------------------------
support_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a support assistant for an e-commerce site. "
            "Answer clearly and concisely using ONLY the knowledge provided. "
            "If the information is not in the context, say you do not know "
            "and suggest contacting support.",
        ),
        (
            "human",
            "User question: {question}\n\n"
            "Context articles:\n{context}",
        ),
    ]
)

llm = ChatOpenAI(
    model="gpt-4.1-mini",
    api_key=OPENAI_API_KEY,
    temperature=0.0,
)
to_str = StrOutputParser()

# Pipeline shape:
# raw string
#   -> normalize_runnable (str -> str)
#   -> mapping builds {"question": str, "context": str}
#   -> prompt -> llm -> plain string
support_chain = (
    normalize_runnable
    | {
        # here `q` is a *string* (the normalised question)
        "question": lambda q: q,
        "context": lambda q: "\n\n".join(simple_keyword_retriever(q)),
    }
    | support_prompt
    | llm
    | to_str
)

# -----------------------------
# 5. Example usage: single, batch, async, streaming
# -----------------------------
# ... everything above unchanged: KNOWLEDGE_ARTICLES, normalize_runnable,
# simple_keyword_retriever, support_prompt, llm, to_str, support_chain ...


def demo_single() -> None:
    print("\n=== SINGLE CALL (invoke) ===\n")
    user_question = "Where is my order????"
    answer = support_chain.invoke(user_question)
    print("User:", user_question)
    print("Assistant:", answer)


def demo_batch() -> None:
    print("\n=== BATCH CALL (batch) ===\n")
    questions = [
        "Where is my order????",
        "How long does shipping take to arrive?",
        "What is your returns policy?",
        "Can I get a refund if I don't like the product?",
    ]

    answers = support_chain.batch(questions)

    for q, a in zip(questions, answers):
        print("User:", q)
        print("Assistant:", a)
        print("---")


async def demo_async() -> None:
    print("\n=== ASYNC CALLS (ainvoke / abatch) ===\n")
    questions = [
        "Where is my order????",
        "What happens if my parcel is lost?",
        "Explain the refunds policy in simple terms.",
    ]

    async_answers = await support_chain.abatch(questions)
    print(">>> Results from abatch:\n")
    for q, a in zip(questions, async_answers):
        print("User:", q)
        print("Assistant:", a)
        print("---")

    q2 = "How many days do I have to return an item?"
    a2 = await support_chain.ainvoke(q2)
    print("\n>>> Result from ainvoke:\n")
    print("User:", q2)
    print("Assistant:", a2)


def demo_streaming_sync() -> None:
    print("\n=== SYNC STREAMING (stream) ===\n")
    user_question = "Where is my order????"
    print("User:", user_question)
    print("Assistant: ", end="", flush=True)

    for chunk in support_chain.stream(user_question):
        print(chunk, end="", flush=True)

    print()  # newline


async def demo_streaming_async() -> None:
    """
    Stream the response in async mode, with basic error handling so
    network issues don't dump a giant stack trace.
    """
    print("\n=== ASYNC STREAMING (astream) ===\n")
    user_question = "Can you explain the returns policy in detail?"
    print("User:", user_question)
    print("Assistant: ", end="", flush=True)

    try:
        async for chunk in support_chain.astream(user_question):
            print(chunk, end="", flush=True)
    except Exception as exc:
        # In a real app you'd log this; for the demo we just show a short message.
        print(f"\n[streaming error: {type(exc).__name__}: {exc}]")

    print()  # newline


if __name__ == "__main__":
    demo_single()
    demo_batch()
    asyncio.run(demo_async())
    demo_streaming_sync()
    asyncio.run(demo_streaming_async())
