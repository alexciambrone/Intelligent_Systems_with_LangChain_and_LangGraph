from .config import OPENAI_API_KEY
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
 
prompt = ChatPromptTemplate.from_messages(
	[
    	(
            "system",
            "You write short, factual summaries of product descriptions.",
    	),
    	(
            "human",
            "Summarise the following content in 3–4 bullet points.\n\n{content}",
    	),
	]
)
 
llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0.0)
 
chain = prompt | llm | StrOutputParser()
 
result = chain.invoke(
	{
        "content": "This laptop has a 14-inch display, 16GB RAM, "
                   "and a battery rated for 10 hours of mixed use."
	}
)
 
print(result)
