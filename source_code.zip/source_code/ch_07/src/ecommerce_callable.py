from __future__ import annotations
import re
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from uuid import UUID
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.documents import Document
from langchain_core.messages import BaseMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.prompt_values import PromptValue
from langchain_core.retrievers import BaseRetriever
from langchain_core.runnables import RunnableLambda, RunnablePassthrough
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY

# Token totals (works for OpenAI via LangChain callbacks)
try:
    from langchain_community.callbacks.manager import get_openai_callback
except Exception:
    get_openai_callback = None

# -----------------------------------------------------------------------------
# 1) Readable chain-only timing logger (with input/output)
# -----------------------------------------------------------------------------
dataclass
class _Run:
    name: str
    start: float
    parent: Optional[UUID]
    tags: Optional[list]
    metadata: Optional[dict]

class PrettyStepTimings(BaseCallbackHandler):
    """
    Only chain events; prints a readable tree with timings, linkage, and input/output.
    """

    ignore_llm = True
    ignore_chat_model = True
    ignore_retriever = True
    ignore_tool = True
    ignore_agent = True

    def __init__(self, max_text: int = 260) -> None:
        super().__init__()
        self._runs: Dict[UUID, _Run] = {}
        self._max_text = max_text

    def _name(self, serialized: Any) -> str:
        if isinstance(serialized, dict):
            return serialized.get("name") or serialized.get("id") or "chain"
        return "chain"

    def _depth(self, run_id: UUID) -> int:
        d = 0
        cur = self._runs.get(run_id)
        while cur and cur.parent:
            d += 1
            cur = self._runs.get(cur.parent)
        return d

    def _indent(self, run_id: UUID) -> str:
        return "  " * self._depth(run_id)

    def _short_id(self, u: Optional[UUID]) -> str:
        if not u:
            return "—"
        return str(u).split("-")[0]

    def _fmt_tags(self, tags: Optional[list]) -> str:
        if not tags:
            return "—"
        return ", ".join(str(t) for t in tags)

    def _fmt_meta(self, meta: Optional[dict]) -> str:
        if not meta:
            return "—"
        parts = [f"{k}={v}" for k, v in sorted(meta.items(), key=lambda x: str(x[0]))]
        return ", ".join(parts)

    def _sanitize_text(self, s: str) -> str:
        s = s.replace("\n", " ").strip()
        s = re.sub(r"\b[\w\.-]+@[\w\.-]+\.\w+\b", "<email>", s)
        s = re.sub(r"\b\d{6,}\b", "<id>", s)
        if len(s) > self._max_text:
            s = s[: self._max_text - 3] + "..."
        return s

    def _preview(self, obj: Any) -> str:
        if isinstance(obj, str):
            return self._sanitize_text(obj)

        if isinstance(obj, BaseMessage):
            return f"{obj.type}: {self._sanitize_text(str(obj.content))}"

        if isinstance(obj, PromptValue):
            try:
                msgs = obj.to_messages()
                if msgs:
                    last = msgs[-1]
                    return f"prompt(last={last.type}): {self._sanitize_text(str(last.content))}"
            except Exception:
                pass
            return f"prompt: {self._sanitize_text(str(obj))}"

        if isinstance(obj, list):
            if not obj:
                return "[]"
            head = self._preview(obj[0])
            return f"list(len={len(obj)} first={head})"

        if isinstance(obj, dict):
            keys = list(obj.keys())
            interesting = []
            for k in ("input", "question", "query", "context", "text", "output"):
                if k in obj:
                    interesting.append(f"{k}={self._preview(obj[k])}")
            if interesting:
                return f"dict(keys={keys}) " + "; ".join(interesting)
            return f"dict(keys={keys})"

        return f"{type(obj).__name__}: {self._sanitize_text(str(obj))}"

    def on_chain_start(self, serialized, inputs, *, run_id: UUID, parent_run_id: Optional[UUID] = None, **kwargs):
        name = self._name(serialized)

        tags = kwargs.get("tags")
        metadata = kwargs.get("metadata")

        self._runs[run_id] = _Run(
            name=name,
            start=time.perf_counter(),
            parent=parent_run_id,
            tags=tags if isinstance(tags, list) else None,
            metadata=metadata if isinstance(metadata, dict) else None,
        )

        ind = self._indent(run_id)
        print(f"{ind}▶ {name}")
        print(f"{ind}  run={self._short_id(run_id)}  parent={self._short_id(parent_run_id)}")
        print(f"{ind}  tags={self._fmt_tags(self._runs[run_id].tags)}")
        print(f"{ind}  meta={self._fmt_meta(self._runs[run_id].metadata)}")
        print(f"{ind}  IN : {self._preview(inputs)}")

    def on_chain_end(self, outputs, *, run_id: UUID, parent_run_id: Optional[UUID] = None, **kwargs):
        r = self._runs.get(run_id)
        if not r:
            print(f"✓ <unknown>  (run={self._short_id(run_id)})")
            return

        ms = (time.perf_counter() - r.start) * 1000.0
        ind = self._indent(run_id)
        print(f"{ind}  OUT: {self._preview(outputs)}")
        print(f"{ind}✓ {r.name}  ({ms:.1f} ms)\n")

    def on_chain_error(self, error, *, run_id: UUID, parent_run_id: Optional[UUID] = None, **kwargs):
        r = self._runs.get(run_id)
        name = r.name if r else "<unknown>"
        start = r.start if r else time.perf_counter()
        ms = (time.perf_counter() - start) * 1000.0
        ind = self._indent(run_id)
        print(f"{ind}✗ {name}  ({ms:.1f} ms)")
        print(f"{ind}  run={self._short_id(run_id)}  parent={self._short_id(parent_run_id)}")
        print(f"{ind}  error={repr(error)}\n")


# -----------------------------------------------------------------------------
# 2) Minimal retriever (in-memory policy docs)
# -----------------------------------------------------------------------------

class PolicyRetriever(BaseRetriever):
    docs: List[Document]
    k: int = 1

    def _get_relevant_documents(self, query: str) -> List[Document]:
        q = query.lower()
        scored: List[Tuple[int, Document]] = []
        for d in self.docs:
            text = (d.page_content or "").lower()
            score = 0
            for kw in ("return", "refund", "exchange", "delivery", "shipping", "wore", "unused"):
                if kw in q and kw in text:
                    score += 1
            scored.append((score, d))

        scored.sort(key=lambda x: x[0], reverse=True)
        top = [d for s, d in scored if s > 0][: self.k]
        return top if top else self.docs[:1]


def format_docs(docs: List[Document]) -> str:
    return "\n".join(f"- {d.metadata.get('title', 'Doc')}: {d.page_content}" for d in docs)


# -----------------------------------------------------------------------------
# 3) Build chain
# -----------------------------------------------------------------------------

def build_chain():
    docs = [
        Document(
            page_content="Returns: items can be returned within 30 days of delivery if unused and in original packaging.",
            metadata={"title": "Returns Policy"},
        ),
        Document(
            page_content="Opened items can be returned only if defective. Refunds are issued after inspection.",
            metadata={"title": "Refund Policy"},
        ),
    ]

    retriever = PolicyRetriever(docs=docs, k=1)

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "You are a support agent. Answer using only the provided policy context."),
            ("human", "Question: {question}\n\nPolicy context:\n{context}"),
        ]
    )

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0, api_key=OPENAI_API_KEY)

    chain = (
        {
            "question": RunnablePassthrough(),
            "context": retriever | RunnableLambda(format_docs),
        }
        | prompt
        | llm
        | StrOutputParser()
    )
    return chain


# -----------------------------------------------------------------------------
# 4) Run
# -----------------------------------------------------------------------------

def main() -> None:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set. Check your .env / config.")

    chain = build_chain()
    logger = PrettyStepTimings(max_text=260)

    question = "I bought shoes last week. Can I return them if I never wore them?"

    print("\n=== RUN TRACE (chain-only) ===\n")

    cfg = {
        "callbacks": [logger],
        "tags": ["ch07", "ecommerce", "timings"],
        "metadata": {"tenant": "demo-shop", "example": "callable-chain"},
    }

    if get_openai_callback is None:
        answer = chain.invoke(question, config=cfg)
        cb = None
    else:
        with get_openai_callback() as cb:
            answer = chain.invoke(question, config=cfg)

    print("=== FINAL ANSWER ===")
    print(answer)

    print("\n=== TOKEN USAGE ===")
    if cb is None:
        print("Token callback not available (langchain_community.get_openai_callback import failed).")
    else:
        print(f"prompt_tokens     : {getattr(cb, 'prompt_tokens', None)}")
        print(f"completion_tokens : {getattr(cb, 'completion_tokens', None)}")
        print(f"total_tokens      : {getattr(cb, 'total_tokens', None)}")
        # total_cost may be present depending on version/provider accounting
        if hasattr(cb, "total_cost"):
            print(f"estimated_cost    : {cb.total_cost}")


if __name__ == "__main__":
    main()
