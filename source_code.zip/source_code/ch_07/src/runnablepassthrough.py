from .config import OPENAI_API_KEY  # if you use env vars, this import may be unnecessary
from langchain_core.runnables import RunnableParallel, RunnablePassthrough
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0.0)
to_str = StrOutputParser()

summarise_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "Summarise the user's question in one short sentence."),
        ("human", "{question}"),
    ]
)

summarisation_chain = summarise_prompt | llm | to_str

# ------------------------------------------------------------
# Option A: Explicit field preservation with RunnablePassthrough()
# (you manually list fields you want to carry forward)
# ------------------------------------------------------------
enrich_chain_parallel = RunnableParallel(
    {
        # Keep existing fields explicitly
        "question": RunnablePassthrough(),
        "articles": RunnablePassthrough(),
        # Add a new derived field
        "summary": summarisation_chain,
    }
)

# ------------------------------------------------------------
# Option B: Preserve ALL fields automatically with RunnablePassthrough.assign(...)
# (you only declare what you want to add/overwrite)
# ------------------------------------------------------------
enrich_chain_assign = RunnablePassthrough.assign(
    summary=summarisation_chain
)

if __name__ == "__main__":
    input_payload = {
        "question": "Where is my order? It was shipped three days ago.",
        "articles": ["Tracking is available in the 'My Orders' section."],
        "priority": "high",  # extra field to show the difference
    }

    enriched_a = enrich_chain_parallel.invoke(input_payload)
    print("A keys:", enriched_a.keys())
    # A keys: dict_keys(['question', 'articles', 'summary'])
    # Note: "priority" is NOT preserved unless you pass it through explicitly.

    enriched_b = enrich_chain_assign.invoke(input_payload)
    print("B keys:", enriched_b.keys())
    # B keys: dict_keys(['question', 'articles', 'priority', 'summary'])
    # Note: ALL original fields are preserved, and "summary" is added.