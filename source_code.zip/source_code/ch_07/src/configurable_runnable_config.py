from __future__ import annotations

from typing import Any, Dict

from .config import OPENAI_API_KEY

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import ConfigurableField
from langchain_openai import ChatOpenAI


# --- Basic safety checks so failures are clear up front ---
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")


def build_chain_with_configurable_fields():
    """
    Demonstrates configurable *fields* (same chain definition, runtime changes via RunnableConfig.configurable).
    We'll treat 'fast' vs 'quality' as different max_tokens / temperature settings.
    """

    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You are a first-line customer support assistant for ACME Telecom. "
                    "Answer clearly and politely. If you are not sure, say so and suggest "
                    "how the customer can get help from a human agent."
                ),
            ),
            ("human", "Customer question: {question}\n\nAccount flags: {account_flags}"),
        ]
    )

    base_model = ChatOpenAI(
        model="gpt-4.1-mini",
        temperature=0.0,
        max_tokens=80,  # default = "fast"
    )

    # Mark selected constructor fields as configurable at runtime.
    model = base_model.configurable_fields(
        max_tokens=ConfigurableField(
            id="max_out_tokens",
            name="Max output tokens",
            description="Maximum number of tokens in the model output",
        ),
        temperature=ConfigurableField(
            id="temp",
            name="Sampling temperature",
            description="Higher values are more varied; 0 is most deterministic",
        ),
    )

    chain = prompt | model | StrOutputParser()
    return chain


def build_chain_with_configurable_alternatives():
    """
    Demonstrates configurable *alternatives* (choose between pre-built runnable variants at runtime).
    Default is "fast"; a "quality" alternative is selectable via RunnableConfig.configurable.
    """

    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You are a first-line customer support assistant for ACME Telecom. "
                    "Answer clearly and politely. If you are not sure, say so and suggest "
                    "how the customer can get help from a human agent."
                ),
            ),
            ("human", "Customer question: {question}\n\nAccount flags: {account_flags}"),
        ]
    )

    fast_model = ChatOpenAI(model="gpt-4.1-mini", temperature=0.0, max_tokens=80)

    # Same provider/model family, but configured for longer answers.
    quality_model = ChatOpenAI(model="gpt-4.1-mini", temperature=0.0, max_tokens=220)

    model = fast_model.configurable_alternatives(
        ConfigurableField(id="mode"),
        default_key="fast",
        quality=quality_model,
    )

    chain = prompt | model | StrOutputParser()
    return chain


def demo() -> None:
    payload: Dict[str, Any] = {
        "question": "My broadband is down. Can I get a refund for today's outage?",
        "account_flags": "Customer has had 3 outages in 30 days; loyalty tier: Gold.",
    }

    print("\n=== Demo A: configurable fields (same chain, runtime params) ===\n")
    chain_a = build_chain_with_configurable_fields()

    # Default (fast)
    print("FAST (defaults):\n")
    print(chain_a.invoke(payload))

    # Quality mode = more room + slightly more verbose style (still deterministic here)
    print("\nQUALITY (with_config(configurable=...)):\n")
    print(
        chain_a.with_config(
            configurable={
                "max_out_tokens": 220,
                "temp": 0.0,
            }
        ).invoke(payload)
    )

    print("\n=== Demo B: configurable alternatives (choose a variant at runtime) ===\n")
    chain_b = build_chain_with_configurable_alternatives()

    # Default (fast)
    print("FAST (default_key='fast'):\n")
    print(chain_b.invoke(payload))

    # Select the alternative
    print("\nQUALITY (select alternative 'quality'):\n")
    print(chain_b.with_config(configurable={"mode": "quality"}).invoke(payload))


if __name__ == "__main__":
    demo()
