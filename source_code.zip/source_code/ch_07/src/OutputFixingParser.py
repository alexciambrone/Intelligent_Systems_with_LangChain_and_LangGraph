from __future__ import annotations
from .config import OPENAI_API_KEY
import os
import json
import re
from typing import Any, Dict
from pydantic import BaseModel, Field
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.runnables import RunnableLambda

# LangChain v1: legacy parsers live under langchain_classic
from langchain_classic.output_parsers.fix import OutputFixingParser

class RiskAssessment(BaseModel):
    risk: str = Field(description="LOW, MEDIUM, or HIGH")
    score: int = Field(description="Integer risk score")

base_parser = PydanticOutputParser(pydantic_object=RiskAssessment)

def build_prompt(payload: Dict[str, Any]) -> str:
    # Put format instructions into the prompt so the model knows the required shape.
    format_instructions = base_parser.get_format_instructions()
    question = payload["question"]
    return (
        "Return ONLY a response that matches the format instructions.\n\n"
        f"Question: {question}\n\n"
        f"Format instructions:\n{format_instructions}"
    )

def fake_llm(prompt: str) -> str:
    # Simulated model output that's "almost" right but invalid for the parser:
    # - adds prose
    # - uses single quotes (Python dict style)
    # - score is a string
    return "Sure! Here's the JSON:\n{'risk': 'HIGH', 'score': '7'}"


def deterministic_repair(payload: Dict[str, Any]) -> str:
    # OutputFixingParser will call this with a dict that contains:
    # - instructions: format instructions
    # - completion: the failing completion
    # - error: the parser error message
    completion = payload.get("completion", "") or ""

    # Strip everything before the first { ... } block.
    m = re.search(r"\{.*\}", completion, flags=re.DOTALL)
    blob = m.group(0) if m else completion

    # Convert python-ish dict text to JSON text.
    blob = blob.replace("'", '"')

    # Ensure numeric types for this demo.
    blob = blob.replace('"score": "7"', '"score": 7')

    # Validate JSON and re-emit a clean JSON string.
    obj = json.loads(blob)
    return json.dumps(obj)


prompt_step = RunnableLambda(build_prompt)
llm_step = RunnableLambda(fake_llm)

fixing_parser = OutputFixingParser(
    parser=base_parser,
    retry_chain=RunnableLambda(deterministic_repair),
    max_retries=1,
)

chain = prompt_step | llm_step | fixing_parser

result = chain.invoke({"question": "Assess portfolio concentration risk."})
print(result)
print(type(result))