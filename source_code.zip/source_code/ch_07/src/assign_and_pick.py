from .config import OPENAI_API_KEY
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0.0)
to_str = StrOutputParser()

summary_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "Summarise the user's question in at most 10 words."),
        ("human", "{question}"),
    ]
)

summarisation_chain = summary_prompt | llm | to_str

# Start from a chain that just passes through the input dict
base_chain = RunnablePassthrough()

# 1) Add a 'summary' field based on the current dict
with_summary = base_chain.assign(
    summary=summarisation_chain
)

# 2) Keep only the summary for the next step
final_chain = with_summary.pick("summary")

if __name__ == "__main__":
    result = final_chain.invoke({"question": "How do I change my delivery address?"})
    print(result)  # {'summary': 'How to change delivery address'}




