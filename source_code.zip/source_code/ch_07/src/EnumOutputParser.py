from langchain_core.language_models.fake import FakeStreamingListLLM
from langchain_core.prompts import ChatPromptTemplate
from langchain_classic.output_parsers.enum import EnumOutputParser
from enum import Enum

class TradeAction(str, Enum):
    BUY = "BUY"
    HOLD = "HOLD"
    SELL = "SELL"


prompt = ChatPromptTemplate.from_template(
    "Choose exactly one action: BUY, HOLD, or SELL. Return ONLY the action."
)

model = FakeStreamingListLLM(responses=["HOLD"])
parser = EnumOutputParser(enum=TradeAction)

chain = prompt | model | parser
result = chain.invoke({})

print(result)         # TradeAction.HOLD
print(result.value)   # "HOLD"
