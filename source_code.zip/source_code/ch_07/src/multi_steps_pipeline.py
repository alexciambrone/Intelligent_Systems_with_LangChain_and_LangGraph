from __future__ import annotations
from .config import OPENAI_API_KEY
import os
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough

llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0)

extract_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You extract structured fields from customer messages. "
            "Return ONLY valid JSON with keys: intent, order_id, urgency, missing_info.",
        ),
        ("human", "{message}"),
    ]
)

extract_chain = extract_prompt | llm | JsonOutputParser()

reply_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a customer support assistant. "
            "Write a concise reply. Use the extracted fields; do not invent an order id.",
        ),
        (
            "human",
            "Customer message: {message}\n"
            "Extracted fields (JSON): {extracted}\n"
            "Write the reply.",
        ),
    ]
)

reply_chain = reply_prompt | llm | StrOutputParser()

pipeline = RunnablePassthrough.assign(extracted=extract_chain) | reply_chain

reply = pipeline.invoke(
    {
        "message": "Hi, my order A-10499 still says 'processing' after 10 days. Can you check?",
    }
)

print(reply)