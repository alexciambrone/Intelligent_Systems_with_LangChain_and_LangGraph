from __future__ import annotations
from .config import OPENAI_API_KEY
import os
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from langchain_classic.output_parsers.retry import RetryOutputParser, RetryWithErrorOutputParser
 
class RiskAssessment(BaseModel):
	risk: str = Field(description="LOW, MEDIUM, or HIGH")
	score: int = Field(description="Integer risk score")
 
base_parser = PydanticOutputParser(pydantic_object=RiskAssessment)
 
# The prompt carries the contract (format instructions) that the retry parser needs.
prompt = ChatPromptTemplate.from_template(
	"Return ONLY a response that matches the format instructions.\n\n"
	"Question: {question}\n\n"
	"Format instructions:\n{format_instructions}"
).partial(format_instructions=base_parser.get_format_instructions())
 
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.0)
 
# In a real workflow, `completion` is the raw model text you got back from `llm.invoke(...)`.
# Here we simulate a typical “almost right” failure: extra prose + single quotes + wrong type.
prompt_value = prompt.invoke({"question": "Assess portfolio concentration risk."})
bad_completion = "Sure! Here's the JSON:\n{'risk': 'HIGH', 'score': '7'}"
 
# First, show what a strict boundary looks like.
try:
    base_parser.parse(bad_completion)
except Exception as e:
    print("Base parse failed:", type(e).__name__, str(e))
 
# Option 1: RetryOutputParser (re-prompts using the original prompt + failing completion).
retry_parser = RetryOutputParser.from_llm(parser=base_parser, llm=llm)
fixed_obj_1 = retry_parser.parse_with_prompt(bad_completion, prompt_value)
print("RetryOutputParser result:", fixed_obj_1, type(fixed_obj_1))
 
# Option 2: RetryWithErrorOutputParser (also includes the parsing error in the retry prompt).
retry_with_error = RetryWithErrorOutputParser.from_llm(parser=base_parser, llm=llm)
fixed_obj_2 = retry_with_error.parse_with_prompt(bad_completion, prompt_value)
print("RetryWithErrorOutputParser result:", fixed_obj_2, type(fixed_obj_2))

