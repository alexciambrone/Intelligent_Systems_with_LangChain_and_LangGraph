from .config import OPENAI_API_KEY
from typing import Dict
import os

from langchain_core.runnables import RunnableLambda, RunnableBranch
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

# -----------------------------
# 1. Safety check
# -----------------------------
if not os.environ.get("OPENAI_API_KEY"):
    raise RuntimeError("OPENAI_API_KEY is not set. Please export it before running.")

# -----------------------------
# 2. Shared LLMs
# -----------------------------
# Router model (deterministic, we only need a label)
router_llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0.0)

# Answering model (can be slightly more creative if you want)
answer_llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0.2)

# -----------------------------
# 3. Classification (routing) chain
# -----------------------------
route_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a router for a multi-domain assistant. "
            "Given a user message, choose exactly one domain:\n"
            "- support: order issues, returns, delivery, account problems\n"
            "- sales: pricing, discounts, bulk orders, product selection\n"
            "- trading: markets, stocks, portfolios, risk, ETFs\n"
            "Reply with only one word: support, sales, or trading.",
        ),
        ("human", "User message: {message}"),
    ]
)

route_chain = route_prompt | router_llm | StrOutputParser()

# -----------------------------
# 4. Domain-specific subchains
# -----------------------------
support_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a customer support assistant for an e-commerce site. "
            "Answer clearly and concisely using a friendly but professional tone.",
        ),
        ("human", "User message: {message}"),
    ]
)
support_chain = support_prompt | answer_llm | StrOutputParser()

sales_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a sales assistant for an e-commerce site. "
            "Help the user with pricing, discounts, and product choices. "
            "Be concise and concrete.",
        ),
        ("human", "User message: {message}"),
    ]
)
sales_chain = sales_prompt | answer_llm | StrOutputParser()

trading_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a trading and market analysis assistant. "
            "Give high-level, educational answers. "
            "Do not give personalised investment advice.",
        ),
        ("human", "User message: {message}"),
    ]
)
trading_chain = trading_prompt | answer_llm | StrOutputParser()

default_chain = RunnableLambda(
    lambda x: (
        "I am not sure which domain this belongs to. "
        "Please clarify if this is a support, sales, or trading question."
    )
)

# -----------------------------
# 5. Router runnable
# -----------------------------
router_branch = RunnableBranch(
    (
        lambda x: "support" in x["route"].lower(),
        support_chain,
    ),
    (
        lambda x: "sales" in x["route"].lower(),
        sales_chain,
    ),
    (
        lambda x: "trading" in x["route"].lower(),
        trading_chain,
    ),
    default_chain,  # runs if no condition matches
)

# Full routing pipeline:
# 1) Classify the message into a route label.
# 2) Combine the route label with the original message.
# 3) Use RunnableBranch to select the correct subchain.
routing_chain = (
    {
        "route": route_chain,
        "message": lambda x: x["message"],
    }
    | router_branch
)

# -----------------------------
# 6. Example usage
# -----------------------------
def demo() -> None:
    test_messages = [
        "Where is my order? It was supposed to arrive yesterday.",
        "Can I get a discount if I buy 50 units of this product?",
        "Is it risky to invest in leveraged ETFs for the long term?",
        "Hi, just testing you.",
    ]

    for msg in test_messages:
        answer = routing_chain.invoke({"message": msg})
        print("USER:      ", msg)
        print("ASSISTANT: ", answer)
        print("-" * 60)

if __name__ == "__main__":
    demo()



