from langchain_core.language_models.fake import FakeStreamingListLLM
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import XMLOutputParser

prompt = ChatPromptTemplate.from_template(
    "Return ONLY XML with root <trade> and children <ticker> and <action>."
)

model = FakeStreamingListLLM(
    responses=["<trade><ticker>MSFT</ticker><action>BUY</action></trade>"]
)
parser = XMLOutputParser()

chain = prompt | model | parser
result = chain.invoke({})

print(result)  # Parsed XML structure (type depends on parser implementation)

