from .config import OPENAI_API_KEY

from typing import Dict, List
import os

from langchain_core.runnables import RunnableLambda
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI

# Safety check
if not os.environ.get("OPENAI_API_KEY"):
    raise RuntimeError("OPENAI_API_KEY is not set.")

# --- 1. Tiny in-memory "retriever" ----------------------------
class Article:
    def __init__(self, page_content: str):
        self.page_content = page_content


ARTICLES = [
    Article("You can track your order from the 'My Orders' section of your account."),
    Article("Returns are accepted within 30 days of delivery for most items."),
]

def build_features(inputs: Dict) -> Dict:
    """
    Take the raw input dict and return a new dict with a normalised 'question' field.
    This is the main 'dict-based input' step.
    """
    raw = inputs["question_raw"]
    normalised = " ".join(raw.strip().split()).lower()
    return {
        "question": normalised,
        # keep raw around if you want it later
        "question_raw": raw,
    }

feature_builder = RunnableLambda(build_features)

def simple_retriever(inputs: Dict) -> List[Article]:
    """
    Very simple 'retriever' that looks at the normalised question text.
    """
    q = inputs["question"]
    if "return" in q:
        return [ARTICLES[1]]
    return [ARTICLES[0]]

retriever = RunnableLambda(simple_retriever)

# --- 2. Prompt and model --------------------------------------
formatting_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a support assistant. Use ONLY the provided context. "
            "If the answer is not in the context, say you don't know.",
        ),
        (
            "human",
            "Question: {question}\n\n"
            "Context:\n{context}",
        ),
    ]
)

llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0.0)
to_str = StrOutputParser()

# --- 3. LCEL RAG chain ----------------------------------------
rag_chain = (
    # First step: turn {"question_raw": "..."} into {"question": "...", "question_raw": "..."}
    feature_builder
    # Second step: build the prompt inputs from that dict
    | {
        "question": lambda inputs: inputs["question"],
        "context": lambda inputs: "\n".join(
            doc.page_content
            for doc in retriever.invoke({"question": inputs["question"]})
        ),
    }
    | formatting_prompt
    | llm
    | to_str
)

if __name__ == "__main__":
    answer = rag_chain.invoke({"question_raw": "How do I return an item?"})
    print(answer)
