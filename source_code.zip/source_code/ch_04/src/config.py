from dotenv import load_dotenv
import os

# Load values from .env into environment variables as soon as this module is imported
load_dotenv()

# Provider API keys
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

# LangSmith / LangChain tracing configuration
LANGCHAIN_TRACING_V2 = os.getenv("LANGCHAIN_TRACING_V2", "false").lower() == "true"
LANGCHAIN_API_KEY = os.getenv("LANGCHAIN_API_KEY")
LANGCHAIN_ENDPOINT = os.getenv("LANGCHAIN_ENDPOINT")
LANGCHAIN_PROJECT = os.getenv("LANGCHAIN_PROJECT", "llm-app-dev")


def configure_langsmith_env() -> None:
    """
    Configure environment variables expected by LangChain / LangSmith.

    Call this once at startup before you create LangChain or LangGraph objects.
    """
    if LANGCHAIN_TRACING_V2 and LANGCHAIN_API_KEY:
        # Enable tracing
        os.environ["LANGCHAIN_TRACING_V2"] = "false"
        os.environ["LANGCHAIN_API_KEY"] = LANGCHAIN_API_KEY

        if LANGCHAIN_ENDPOINT:
            os.environ["LANGCHAIN_ENDPOINT"] = LANGCHAIN_ENDPOINT

        if LANGCHAIN_PROJECT:
            os.environ["LANGCHAIN_PROJECT"] = LANGCHAIN_PROJECT
