from __future__ import annotations

from typing import Literal
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END


# Subgraph schema (private to the returns specialist)
class ReturnsSubState(TypedDict):
    question: str
    outcome: str


def returns_specialist(state: ReturnsSubState) -> dict:
    # Deterministic rules for a runnable example.
    q = state["question"].lower()
    if "damaged" in q:
        return {"outcome": "Returns: start a damaged-item return and attach photos."}
    if "does not fit" in q or "size" in q:
        return {"outcome": "Returns: start a size/fit return; confirm the item is unused."}
    return {"outcome": "Returns: start a standard return from your orders page."}


returns_builder = StateGraph(ReturnsSubState)
returns_builder.add_node("returns_specialist", returns_specialist)
returns_builder.add_edge(START, "returns_specialist")
returns_builder.add_edge("returns_specialist", END)
returns_graph = returns_builder.compile()


# Parent schema (public support interface)
class SupportState(TypedDict):
    question: str
    route: Literal["returns", "other"]
    answer: str


def triage(state: SupportState) -> dict:
    q = state["question"].lower()
    route: Literal["returns", "other"] = "returns" if any(k in q for k in ["return", "refund", "exchange"]) else "other"
    return {"route": route}


def route_after_triage(state: SupportState) -> Literal["call_returns", "fallback"]:
    return "call_returns" if state["route"] == "returns" else "fallback"


def call_returns(state: SupportState) -> dict:
    child_out = returns_graph.invoke({"question": state["question"], "outcome": ""})
    return {"answer": child_out["outcome"]}


def fallback(state: SupportState) -> dict:
    return {"answer": "Support: I can help with orders, returns, billing, and technical issues. What happened?"}


parent_builder = StateGraph(SupportState)
parent_builder.add_node("triage", triage)
parent_builder.add_node("call_returns", call_returns)
parent_builder.add_node("fallback", fallback)

parent_builder.add_edge(START, "triage")
parent_builder.add_conditional_edges(
    "triage",
    route_after_triage,
    {"call_returns": "call_returns", "fallback": "fallback"},
)
parent_builder.add_edge("call_returns", END)
parent_builder.add_edge("fallback", END)

support_graph = parent_builder.compile()

if __name__ == "__main__":
    out = support_graph.invoke({"question": "How do I return an item that arrived damaged?", "route": "other", "answer": ""})
    print(out["answer"])


