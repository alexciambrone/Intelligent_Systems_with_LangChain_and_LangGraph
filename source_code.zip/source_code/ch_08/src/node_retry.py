from __future__ import annotations

import time
from typing_extensions import TypedDict

from langgraph.graph import START, END, StateGraph
from langgraph.types import RetryPolicy


# 1. Define State
class SupportState(TypedDict, total=False):
    question: str
    answer: str


# 2. The Fragile Node
def search_docs(state: SupportState) -> dict:
    question = state.get("question", "Unknown")
    print(f"--- Attempting search_docs for: '{question}' ---")
    raise TimeoutError("Backend timeout")


# 3. Build the Graph
builder = StateGraph(SupportState)

builder.add_node(
    "search_docs",
    search_docs,
    retry_policy=RetryPolicy(
        max_attempts=3,
        initial_interval=1.0,
        max_interval=5.0,
        backoff_factor=2.0,
        jitter=False,
        # Change: explicitly retry on TimeoutError
        retry_on=lambda exc: isinstance(exc, TimeoutError),
    ),
)

builder.add_edge(START, "search_docs")
builder.add_edge("search_docs", END)

graph = builder.compile()


# 4. Execution
if __name__ == "__main__":
    inputs = {"question": "Retry Demo"}

    try:
        graph.invoke(inputs)
    except Exception:
        print("\n[Behavior 1 Complete] LangGraph exhausted all 3 attempts.")
        print("[Behavior 2 Triggered] Providing Fallback Answer.")
        print("Final Output: Manual Fallback: The search service is currently unavailable.")



