from __future__ import annotations
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver

class CounterState(TypedDict):
    counter: int

def increment(state: CounterState) -> dict:
    # This will now correctly pull the existing value from the DB
    return {"counter": state["counter"] + 1}

builder = StateGraph(CounterState)
builder.add_node("increment", increment)
builder.add_edge(START, "increment")
builder.add_edge("increment", END)

with SqliteSaver.from_conn_string("checkpoints_8_3.db") as saver:
    graph = builder.compile(checkpointer=saver)
    thread_cfg = {"configurable": {"thread_id": "counter-thread"}}

    # First run: Initialize counter at 0. Result: 1
    print("Run 1:", graph.invoke({"counter": 0}, config=thread_cfg))

    # Second run: Pass an empty dict. 
    # LangGraph loads 'counter': 1 from the DB. Result: 2
    print("Run 2:", graph.invoke({}, config=thread_cfg))