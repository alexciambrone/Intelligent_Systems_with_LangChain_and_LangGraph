from __future__ import annotations

import os
import operator
from typing import Annotated, Literal
from typing_extensions import TypedDict

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from .config import OPENAI_API_KEY
from langgraph.graph import StateGraph, START, END


# --- State -----------------------------------------------------------------
class SupportState(TypedDict, total=False):
    question: str
    answer: str

    # Reflection additions
    draft: str
    critique: str
    iterations: Annotated[int, operator.add]
    max_iterations: int


# --- Model -----------------------------------------------------------------
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
model = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)


# --- Prompts ---------------------------------------------------------------

draft_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a careful e-commerce support assistant."),
        ("human", "{question}"),
    ]
)

critique_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are reviewing a customer support answer.\n"
            "Critique it for: clarity, completeness, policy safety, and actionability.\n"
            "If the answer is acceptable, start your response with exactly: OK\n"
            "Otherwise start with exactly: FIX and then list the issues.\n",
        ),
        ("human", "Customer request:\n{question}\n\nDraft answer:\n{draft}"),
    ]
)

revise_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "Revise the draft using the critique.\n"
            "Keep the response customer-facing (no internal process notes).\n"
            "If the critique starts with OK, return the draft unchanged.\n",
        ),
        ("human", "Customer request:\n{question}\n\nDraft:\n{draft}\n\nCritique:\n{critique}"),
    ]
)


# --- Nodes -----------------------------------------------------------------

def generate(state: SupportState) -> dict:
    msg = (draft_prompt | model).invoke({"question": state["question"]})
    return {"draft": msg.content.strip()}

def critique(state: SupportState) -> dict:
    msg = (critique_prompt | model).invoke(
        {"question": state["question"], "draft": state.get("draft", "")}
    )
    return {"critique": msg.content.strip()}

def revise(state: SupportState) -> dict:
    msg = (revise_prompt | model).invoke(
        {
            "question": state["question"],
            "draft": state.get("draft", ""),
            "critique": state.get("critique", ""),
        }
    )
    # Count one full reflection cycle (critique+revise) as one iteration.
    return {"draft": msg.content.strip(), "iterations": 1}

def should_continue(state: SupportState) -> Literal["critique", "finalize"]:
    """
    Stop when:
      - the critique says OK, or
      - we reached max_iterations (budget exhausted).
    """
    max_iters = state.get("max_iterations", 2)
    iters = state.get("iterations", 0)
    crit = (state.get("critique", "") or "").lstrip()

    if crit.startswith("OK"):
        return "finalize"
    if iters >= max_iters:
        return "finalize"
    return "critique"

def finalize(state: SupportState) -> dict:
    # The final answer is the latest draft.
    return {"answer": state.get("draft", "")}


# --- Graph ------------------------------------------------------------------
builder = StateGraph(SupportState)

builder.add_node("generate", generate)
builder.add_node("critique", critique)
builder.add_node("revise", revise)
builder.add_node("finalize", finalize)

builder.add_edge(START, "generate")
builder.add_edge("generate", "critique")
builder.add_edge("critique", "revise")
builder.add_conditional_edges("revise", should_continue, {"critique": "critique", "finalize": "finalize"})
builder.add_edge("finalize", END)

graph = builder.compile()


if __name__ == "__main__":
    out = graph.invoke(
        {
            "question": "My package says delivered but I can't find it. What should I do?",
            "iterations": 0,
            "max_iterations": 2,
        }
    )
    print(out["answer"])



