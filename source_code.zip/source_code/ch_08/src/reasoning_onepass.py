from __future__ import annotations
from typing_extensions import TypedDict
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY
from langgraph.graph import StateGraph, START, END

# --- State -----------------------------------------------------------------
class SupportState(TypedDict, total=False):
    question: str
    answer: str

# --- One reasoning pass -----------------------------------------------------
prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a careful e-commerce support assistant."),
        ("human", "{question}"),
    ]
)

model = ChatOpenAI()
chain = prompt | model

def single_pass(state: SupportState) -> dict:
    msg = chain.invoke({"question": state["question"]})
    return {"answer": msg.content}

# --- Graph ------------------------------------------------------------------
builder = StateGraph(SupportState)
builder.add_node("single_pass", single_pass)

builder.add_edge(START, "single_pass")
builder.add_edge("single_pass", END)

graph = builder.compile()

if __name__ == "__main__":
    out = graph.invoke({"question": "Where is my order #1234?"})
    print(out["answer"])