from __future__ import annotations

import json
from typing_extensions import TypedDict

from langgraph.graph import START, END, StateGraph
from langgraph.types import Command

# 1. Define the State schema
class TicketState(TypedDict, total=False):
    message: str
    extracted_json: str
    extracted: dict
    parse_error: str
    attempts: int

# 2. Define the extraction logic with error handling
def extract_fields(state: TicketState) -> Command:
    attempts = int(state.get("attempts", 0)) + 1
    raw = state.get("extracted_json") or ""

    try:
        data = json.loads(raw)
        # Validation check for required fields
        if "account_id" not in data:
            raise ValueError("Missing required field: account_id")

        # On success, update state and end the graph
        return Command(
            update={"attempts": attempts, "extracted": data, "parse_error": ""},
            goto=END,
        )
    except Exception as e:
        # On failure, store the error and route to the repair node
        print(f"--- Extraction Failed (Attempt {attempts}): {e} ---")
        return Command(
            update={"attempts": attempts, "parse_error": str(e)},
            goto="repair_output",
        )

# 3. Define the repair logic
def repair_output(state: TicketState) -> Command:
    """Simulates repairing invalid JSON for the next extraction attempt."""
    parse_error = state.get("parse_error") or "unknown error"
    print(f"--- Repairing output after error: {parse_error} ---")

    # Placeholder for a repaired JSON string that includes 'account_id'
    repaired = json.dumps({"account_id": "12345", "intent": "password_reset"})

    # Return to the extraction node with updated data
    return Command(
        update={"extracted_json": repaired, "parse_error": f"repaired after: {parse_error}"},
        goto="extract_fields",
    )

# 4. Build the Graph
builder = StateGraph(TicketState)
builder.add_node("extract_fields", extract_fields)
builder.add_node("repair_output", repair_output)

builder.add_edge(START, "extract_fields")
# The 'Command' object in nodes handles the routing, so explicit edges between 
# extract_fields and repair_output are managed by the 'goto' parameter.

graph = builder.compile()

# 5. Execute the Graph
if __name__ == "__main__":
    # Input with malformed/incomplete JSON to trigger the repair cycle
    initial_state = {
        "message": "I need to reset my password",
        "extracted_json": '{"intent": "password_reset"}', # Missing account_id
        "attempts": 0
    }
    
    print("Starting Recovery Graph...")
    final_state = graph.invoke(initial_state)
    
    print("\n--- Final State ---")
    print(f"Attempts: {final_state['attempts']}")
    print(f"Extracted Data: {final_state['extracted']}")
    print(f"Last Parse Error Status: {final_state['parse_error'] if final_state['parse_error'] else 'None'}")