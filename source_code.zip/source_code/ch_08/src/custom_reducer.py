from __future__ import annotations

from typing import Annotated, List, Union
from typing_extensions import TypedDict

from langgraph.graph import END, START, StateGraph

EventUpdate = Union[str, List[str]]


def merge_events(left: List[str], right: EventUpdate, *, max_items: int = 10) -> List[str]:
    """
    Custom reducer: bounded, de-duplicated event history.

    - left: current value stored in state (List[str])
    - right: new update produced by a node (either a single str or a List[str])
    - returns: a NEW List[str] (does not mutate left)
    """
    if right is None:
        return list(left)

    # Normalize update to a list.
    if isinstance(right, str):
        incoming = [right]
    else:
        incoming = list(right)

    # Merge while de-duplicating, preserving first-seen order.
    merged: List[str] = list(left)
    seen = set(merged)
    for item in incoming:
        if item not in seen:
            merged.append(item)
            seen.add(item)

    # Cap to last max_items.
    if len(merged) > max_items:
        merged = merged[-max_items:]

    return merged


class State(TypedDict):
    events: Annotated[List[str], merge_events]
    answer: str


def step_a(state: State) -> dict:
    # Single item update (allowed by custom reducer).
    return {"events": "a:started"}


def step_b(state: State) -> dict:
    # List update (also allowed). Includes a duplicate on purpose.
    return {"events": ["b:started", "b:finished", "a:started"]}


def finalize(state: State) -> dict:
    # Reducer has already merged everything into a bounded, de-duplicated list.
    return {"answer": "ok"}


def build_graph():
    builder = StateGraph(State)
    builder.add_node("a", step_a)
    builder.add_node("b", step_b)
    builder.add_node("finalize", finalize)

    builder.add_edge(START, "a")
    builder.add_edge("a", "b")
    builder.add_edge("b", "finalize")
    builder.add_edge("finalize", END)

    return builder.compile()


if __name__ == "__main__":
    graph = build_graph()
    out = graph.invoke({"events": [], "answer": ""})
    print("events:", out["events"])
    print("answer:", out["answer"])
