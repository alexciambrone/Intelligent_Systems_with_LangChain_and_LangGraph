from langchain_core.language_models.fake_chat_models import FakeChatModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate


def test_chain_wiring_with_fake_chat_model() -> None:
    # 1) Build a chat prompt that produces chat messages (System + Human).
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "You are a helpful assistant."),
            ("human", "Return any output for: {topic}"),
        ]
    )

    # 2) FakeChatModel ignores the prompt content and always returns a deterministic reply.
    model = FakeChatModel()

    # 3) StrOutputParser extracts the .content from the AIMessage returned by the chat model.
    chain = prompt | model | StrOutputParser()

    out = chain.invoke({"topic": "unit testing"})

    # FakeChatModel always yields the same content, regardless of input.
    print("Fake model response:", out)
    assert out == "fake response"


if __name__ == "__main__":
    # Run as a normal script (no pytest required).
    test_chain_wiring_with_fake_chat_model()
    print("OK: FakeChatModel wiring test passed.")



