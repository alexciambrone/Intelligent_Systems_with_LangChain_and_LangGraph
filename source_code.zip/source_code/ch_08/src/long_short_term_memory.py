from __future__ import annotations

from typing_extensions import TypedDict
from langchain_core.runnables import RunnableConfig
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import START, END, StateGraph
from langgraph.store.base import BaseStore
from langgraph.store.memory import InMemoryStore


class SupportState(TypedDict, total=False):
    turn: int
    message: str
    prefs: dict
    reply: str


def load_prefs(state: SupportState, config: RunnableConfig, *, store: BaseStore) -> dict:
    """Long-term memory read: pull user prefs into the thread state."""
    thread_id = config["configurable"].get("thread_id")
    user_id = config["configurable"].get("user_id")

    if not user_id:
        print(f"[load_prefs] thread={thread_id} user=None loaded_prefs=None")
        return {"prefs": {}}

    namespace = (user_id, "profile")
    item = store.get(namespace, "preferences")
    loaded = None if item is None else item.value

    print(f"[load_prefs] thread={thread_id} user={user_id} loaded_prefs={loaded}")
    return {"prefs": {} if item is None else item.value}


def reply_or_remember(state: SupportState, config: RunnableConfig, *, store: BaseStore) -> dict:
    """
    Short-term memory write: increment turn and save reply into the thread state.
    Long-term memory write (optional): persist a preference to the shared store.
    """
    thread_id = config["configurable"].get("thread_id")
    user_id = config["configurable"]["user_id"]

    loaded_turn = state.get("turn")
    turn = int(loaded_turn or 0) + 1
    print(f"[reply_or_remember] thread={thread_id} loaded_turn={loaded_turn} next_turn={turn}")

    message = (state.get("message") or "").strip()
    namespace = (user_id, "profile")

    # Long-term write: one command stores a durable preference for this user.
    if message.lower().startswith("remember:"):
        value = message.split(":", 1)[1].strip().lower()
        prefs = {"short_mode": ("short" in value)}
        store.put(namespace, "preferences", prefs)

        reply = f"[turn {turn}] Saved preferences for {user_id}: {prefs}"
        return {"turn": turn, "reply": reply}

    # Use long-term prefs (loaded by the previous node) to shape the reply.
    short_mode = bool(state.get("prefs", {}).get("short_mode", False))

    if short_mode:
        reply = f"[turn {turn}] OK: {message}"
    else:
        reply = f"[turn {turn}] I received: '{message}'. (No short_mode preference set.)"

    return {"turn": turn, "reply": reply}


def build_graph():
    g = StateGraph(SupportState)
    g.add_node("load_prefs", load_prefs)
    g.add_node("reply_or_remember", reply_or_remember)
    g.add_edge(START, "load_prefs")
    g.add_edge("load_prefs", "reply_or_remember")
    g.add_edge("reply_or_remember", END)
    return g


def main() -> None:
    store = InMemoryStore()  # simplest store: put/get by key

    # Use an in-memory SQLite checkpointer so every run starts clean.
    with SqliteSaver.from_conn_string(":memory:") as saver:
        graph = build_graph().compile(checkpointer=saver, store=store)

        user_id = "user-42"

        # Thread A: save long-term preference (store write) + checkpoint turn=1
        cfg_a = {"configurable": {"thread_id": "thread-A", "user_id": user_id}}
        print("--- Thread A / Run 1 ---")
        print(graph.invoke({"message": "remember: short"}, config=cfg_a)["reply"])

        # Same thread A: short-term memory (checkpoint) continues turn counter
        print("\n--- Thread A / Run 2 (same thread_id) ---")
        print(graph.invoke({"message": "Hello again"}, config=cfg_a)["reply"])

        # Thread B: new thread_id => no checkpoint history (turn resets),
        # but long-term preference is still applied (store read)
        cfg_b = {"configurable": {"thread_id": "thread-B", "user_id": user_id}}
        print("\n--- Thread B / Run 1 (new thread_id) ---")
        print(graph.invoke({"message": "How do I reset my password?"}, config=cfg_b)["reply"])


if __name__ == "__main__":
    main()



