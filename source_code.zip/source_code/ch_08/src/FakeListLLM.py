from __future__ import annotations

from langchain_core.language_models.fake import FakeListLLM
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate


def test_fake_list_llm_for_text_chains() -> None:
    # PromptTemplate produces a plain string prompt (not chat messages)
    prompt = PromptTemplate.from_template("Summarize: {text}")

    # FakeListLLM returns the scripted responses in order, one per invocation,
    # ignoring the input prompt content.
    llm = FakeListLLM(responses=["SUMMARY_1", "SUMMARY_2"])

    # FakeListLLM already returns a string, so StrOutputParser is optional here,
    # but keeping it makes the pipeline style consistent across examples.
    chain = prompt | llm | StrOutputParser()

    out1 = chain.invoke({"text": "first"})
    out2 = chain.invoke({"text": "second"})

    assert out1 == "SUMMARY_1", f"Expected SUMMARY_1, got: {out1!r}"
    assert out2 == "SUMMARY_2", f"Expected SUMMARY_2, got: {out2!r}"


def main() -> None:
    test_fake_list_llm_for_text_chains()
    print("OK: FakeListLLM returned scripted responses in order.")


if __name__ == "__main__":
    main()



