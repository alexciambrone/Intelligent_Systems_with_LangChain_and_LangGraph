from __future__ import annotations
import os
import operator
from collections import Counter
from typing import Annotated, Literal
from typing_extensions import TypedDict
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY
from langgraph.graph import StateGraph, START, END

# --- State -----------------------------------------------------------------
class SupportState(TypedDict, total=False):
    question: str
    answer: str

    # Self-consistency additions
    k: int
    samples: Annotated[int, operator.add]
    candidates: Annotated[list[str], operator.add]
    final_answer: str

# --- One reasoning pass (unchanged in spirit) ------------------------------
prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a careful e-commerce support assistant."),
        ("human", "{question}"),
    ]
)

# For self-consistency you usually want some diversity across samples.
model = ChatOpenAI(temperature=0.8)
chain = prompt | model

def single_pass(state: SupportState) -> dict:
    """
    The same “one pass” you already had, but in self-consistency we treat each
    pass as a candidate. We store it as an appended list element.
    """
    msg = chain.invoke({"question": state["question"]})
    return {
        "answer": msg.content,        # last sample (useful for debugging)
        "candidates": [msg.content],  # accumulate across iterations
        "samples": 1,                 # increment loop counter
    }

def should_continue(state: SupportState) -> Literal["single_pass", "vote"]:
    """
    Loop until we have collected k samples, then move to the vote step.
    """
    k = state.get("k", 5)
    samples = state.get("samples", 0)
    return "single_pass" if samples < k else "vote"

def vote(state: SupportState) -> dict:
    """
    The simplest aggregator: majority vote on exact strings.
    (Later in the chapter you can swap this node for scoring / judging.)
    """
    candidates = state.get("candidates", [])
    if not candidates:
        return {"final_answer": "", "answer": ""}

    winner = Counter(candidates).most_common(1)[0][0]
    return {"final_answer": winner, "answer": winner}

# --- Graph ------------------------------------------------------------------
builder = StateGraph(SupportState)

builder.add_node("single_pass", single_pass)
builder.add_node("vote", vote)

builder.add_edge(START, "single_pass")
builder.add_conditional_edges("single_pass", should_continue)
builder.add_edge("vote", END)

graph = builder.compile()


if __name__ == "__main__":
    out = graph.invoke(
        {
            "question": "Where is my order #1234?",
            "k": 5,
            "samples": 0,
            "candidates": [],
            "final_answer": "",
        }
    )

    print("Candidates:")
    for i, c in enumerate(out["candidates"], start=1):
        print(f"{i}. {c}")

    print("\nFinal:")
    print(out["final_answer"])