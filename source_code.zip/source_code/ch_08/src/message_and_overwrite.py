from __future__ import annotations

import operator
from typing import Annotated

from typing_extensions import TypedDict

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import Overwrite


class State(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    logs: Annotated[list[str], operator.add]
    reset_logs: bool


def reply(state: State) -> dict:
    """
    Read the last user message and append an AIMessage reply plus a log entry.
    """
    last = state["messages"][-1]
    if not isinstance(last, HumanMessage):
        return {"logs": [f"reply: expected HumanMessage, got {type(last).__name__}"]}

    text = last.content
    return {
        "messages": [AIMessage(content=f"Echo: {text}")],
        "logs": [f"reply: input_len={len(text)}"],
    }


def maybe_reset(state: State) -> dict:
    """
    If reset_logs is true, clear the entire logs list by bypassing the reducer.
    """
    if state["reset_logs"]:
        return {"logs": Overwrite([])}
    return {}


builder = StateGraph(State)
builder.add_node("reply", reply)
builder.add_node("maybe_reset", maybe_reset)

builder.add_edge(START, "reply")
builder.add_edge("reply", "maybe_reset")
builder.add_edge("maybe_reset", END)

graph = builder.compile()


if __name__ == "__main__":
    # Run 1: normal flow (logs accumulate, messages accumulate)
    state_1: State = {
        "messages": [HumanMessage(content="Hello")],
        "logs": [],
        "reset_logs": False,
    }
    out_1 = graph.invoke(state_1)

    print("Run 1 logs:", out_1["logs"])
    print("Run 1 last message:", out_1["messages"][-1].content)

    # Run 2: carry forward message history, request a reset, and clear logs via Overwrite
    state_2: State = {
        "messages": out_1["messages"] + [HumanMessage(content="/reset")],
        "logs": out_1["logs"],
        "reset_logs": True,
    }
    out_2 = graph.invoke(state_2)

    print("Run 2 logs:", out_2["logs"])
    print("Run 2 last message:", out_2["messages"][-1].content)


