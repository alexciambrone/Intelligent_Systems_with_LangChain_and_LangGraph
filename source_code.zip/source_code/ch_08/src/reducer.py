import operator
from typing import Annotated, List, Union
from typing_extensions import TypedDict

from langchain_core.messages import AnyMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages

# 1. Define the State with Reducers
# Annotated + a function (like add_messages or operator.add) 
# tells LangGraph how to merge updates instead of overwriting.
class SupportState(TypedDict):
    # Appends messages to the list
    messages: Annotated[List[AnyMessage], add_messages]
    # Appends strings to the list
    logs: Annotated[List[str], operator.add]
    # Overwrites with the latest string (no reducer)
    answer: str

# 2. Define the Nodes
def classify_and_log(state: SupportState) -> dict:
    """Extracts intent and adds a log entry."""
    user_text = state["messages"][-1].content
    route = "returns" if "return" in str(user_text).lower() else "general"
    
    print(f"--- Node: Classify (Route: {route}) ---")
    return {
        "logs": [f"classify: detected route={route}"],
    }

def reply(state: SupportState) -> dict:
    """Generates the final response and adds a final log."""
    user_text = state["messages"][-1].content
    answer = f"I am a support bot. I see you're asking about: '{user_text}'."
    
    print("--- Node: Reply ---")
    return {
        "messages": [AIMessage(content=answer)],
        "answer": answer,
        "logs": ["reply: generated answer"],
    }

# 3. Build the Graph
builder = StateGraph(SupportState)

builder.add_node("classify_and_log", classify_and_log)
builder.add_node("reply", reply)

# Linear flow
builder.add_edge(START, "classify_and_log")
builder.add_edge("classify_and_log", "reply")
builder.add_edge("reply", END)

# 4. Compile and Run
graph = builder.compile()

if __name__ == "__main__":
    # Initial input
    initial_input = {
        "messages": [HumanMessage(content="I'd like to return my order")],
        "logs": ["init: started workflow"]
    }

    # Execute
    final_output = graph.invoke(initial_input)

    # 5. Review the Accumulated State
    print("\n--- Final State Summary ---")
    print(f"Final Answer: {final_output['answer']}")
    
    print("\nLogs (Accumulated via operator.add):")
    for log in final_output['logs']:
        print(f"  > {log}")
        
    print("\nMessages (Accumulated via add_messages):")
    for msg in final_output['messages']:
        role = "User" if isinstance(msg, HumanMessage) else "Bot"
        print(f"  {role}: {msg.content}")

