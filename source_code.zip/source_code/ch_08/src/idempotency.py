from __future__ import annotations
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver

class OrderState(TypedDict):
    order_id: str
    payment_confirmed: bool
    payment_receipt_id: str

def charge_payment(state: OrderState) -> dict:
    # This check provides idempotency logic inside the node
    if state.get("payment_confirmed"):
        print("--- Payment already confirmed. Skipping gateway call. ---")
        return {} 

    print("--- Calling Payment Gateway... ---")
    receipt_id = f"receipt-{state['order_id']}"
    return {"payment_confirmed": True, "payment_receipt_id": receipt_id}

builder = StateGraph(OrderState)
builder.add_node("charge_payment", charge_payment)
builder.add_edge(START, "charge_payment")
builder.add_edge("charge_payment", END)

# 1. Use the 'with' statement to properly initialize the SQLite connection
with SqliteSaver.from_conn_string("checkpoints_payments.db") as saver:
    graph = builder.compile(checkpointer=saver)
    cfg = {"configurable": {"thread_id": "order-123"}}

    # 2. First Run: This will trigger the payment gateway logic
    print("Run 1:")
    initial_input = {"order_id": "order-123", "payment_confirmed": False, "payment_receipt_id": ""}
    print(graph.invoke(initial_input, config=cfg))

    # 3. Second Run: Use an empty dict to resume the state from the checkpoint
    # If you pass 'payment_confirmed': False here, it will overwrite the DB and charge again!
    print("\nRun 2 (Idempotent check):")
    print(graph.invoke({}, config=cfg))