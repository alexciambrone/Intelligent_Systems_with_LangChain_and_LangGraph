from __future__ import annotations

import operator
from typing import Annotated, Literal
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.types import Send


class OrderLine(TypedDict):
    sku: str
    delivered_days_ago: int
    opened: bool
    category: Literal["apparel", "electronics", "consumable"]


class LineResult(TypedDict):
    sku: str
    eligible: bool
    reason: str


class ReturnsState(TypedDict, total=False):
    # Inputs
    order_id: str
    lines: list[OrderLine]

    # Per-task input for mapped nodes (each task gets one line)
    line: OrderLine

    # Aggregated outputs (many tasks update the same key; reducer required)
    line_results: Annotated[list[LineResult], operator.add]

    # Final outputs
    decision: Literal["approve_return", "request_more_info", "reject_return"]
    answer: str


def prepare(state: ReturnsState) -> dict:
    # Anchor node: in a real system, this could fetch the order lines.
    return {}


def fanout_lines(state: ReturnsState):
    # Map step: create one task per line item.
    return [Send("check_line", {"line": line}) for line in state["lines"]]


def check_line(state: ReturnsState) -> dict:
    # Deterministic policy checks for a runnable example.
    line = state["line"]
    sku = line["sku"]

    if line["delivered_days_ago"] > 30:
        return {"line_results": [{"sku": sku, "eligible": False, "reason": "outside 30-day window"}]}

    if line["category"] == "consumable":
        return {"line_results": [{"sku": sku, "eligible": False, "reason": "consumables not eligible"}]}

    if line["category"] == "electronics" and line["opened"]:
        return {"line_results": [{"sku": sku, "eligible": False, "reason": "opened electronics not eligible"}]}

    return {"line_results": [{"sku": sku, "eligible": True, "reason": "eligible"}]}


def reduce_and_decide(state: ReturnsState) -> dict:
    results = state.get("line_results", [])

    if not results:
        return {
            "decision": "request_more_info",
            "answer": "I need the order lines to assess return eligibility.",
        }

    any_eligible = any(r["eligible"] for r in results)
    any_ineligible = any(not r["eligible"] for r in results)

    if any_eligible and any_ineligible:
        return {
            "decision": "request_more_info",
            "answer": (
                "Some items are eligible and some are not. "
                "Confirm which SKU(s) you want to return: "
                + ", ".join(r["sku"] for r in results)
            ),
        }

    if any_ineligible and not any_eligible:
        return {
            "decision": "reject_return",
            "answer": "No items are eligible: " + "; ".join(f"{r['sku']} ({r['reason']})" for r in results),
        }

    return {
        "decision": "approve_return",
        "answer": "All checked items are eligible. Start the return from your orders page.",
    }


builder = StateGraph(ReturnsState)

builder.add_node("prepare", prepare)
builder.add_node("check_line", check_line)
builder.add_node("reduce_and_decide", reduce_and_decide)

builder.add_edge(START, "prepare")

# Conditional edge returning a list[Send] implements map-reduce fan-out.
builder.add_conditional_edges("prepare", fanout_lines)

# Reduce step: aggregate all per-line results into one decision.
builder.add_edge("check_line", "reduce_and_decide")
builder.add_edge("reduce_and_decide", END)

graph = builder.compile()

if __name__ == "__main__":
    out = graph.invoke(
        {
            "order_id": "ORD-1001",
            "lines": [
                {"sku": "TSHIRT-RED-M", "delivered_days_ago": 12, "opened": True, "category": "apparel"},
                {"sku": "HEADPHONES-X", "delivered_days_ago": 9, "opened": True, "category": "electronics"},
                {"sku": "COFFEE-BEANS", "delivered_days_ago": 5, "opened": False, "category": "consumable"},
            ],
            "line_results": [],
            "decision": "request_more_info",
            "answer": "",
        }
    )

    print("decision:", out["decision"])
    print("line_results:", out["line_results"])
    print("answer:", out["answer"])


