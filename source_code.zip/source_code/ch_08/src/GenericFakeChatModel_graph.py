from __future__ import annotations

from typing import Annotated, List
from typing_extensions import TypedDict

from langchain_core.language_models.fake_chat_models import GenericFakeChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages


class FailOnceThenOK:
    """Iterator that fails on the first read, then succeeds forever."""
    def __init__(self) -> None:
        self._count = 0

    def __iter__(self) -> "FailOnceThenOK":
        return self

    def __next__(self) -> AIMessage:
        self._count += 1
        if self._count == 1:
            raise ValueError("transient")
        return AIMessage(content="Recovered")


class ChatState(TypedDict, total=False):
    # add_messages is a reducer: returned messages are merged/appended into state["messages"]
    messages: Annotated[List[BaseMessage], add_messages]


def node(state: ChatState) -> dict:
    # Make the fake model fail once, then succeed. Wrap ONLY the risky call with retry.
    model = GenericFakeChatModel(messages=iter(FailOnceThenOK())).with_retry(
        stop_after_attempt=2,
        retry_if_exception_type=(ValueError,),
    )

    # LangGraph chat-style state typically stores messages. Pass them to the chat model.
    messages = state.get("messages", [])
    reply = model.invoke(messages)

    # With add_messages, return ONLY the new messages to add.
    return {"messages": [reply]}


def build_graph():
    builder = StateGraph(ChatState)
    builder.add_node("node", node)
    builder.add_edge(START, "node")
    builder.add_edge("node", END)
    return builder.compile()


def test_graph_node_retry_path() -> None:
    graph = build_graph()
    out = graph.invoke({"messages": [HumanMessage(content="start")]})
    assert out["messages"][-1].content == "Recovered"


if __name__ == "__main__":
    # Run as a script (no pytest required)
    graph = build_graph()
    result = graph.invoke({"messages": [HumanMessage(content="start")]})
    print([f"{m.type}: {m.content}" for m in result["messages"]])
    assert result["messages"][-1].content == "Recovered"
    print("OK")



