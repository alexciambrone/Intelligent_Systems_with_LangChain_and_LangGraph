from __future__ import annotations

from typing import Literal, Optional
from typing_extensions import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import StateGraph, START, END
from langgraph.types import Command, interrupt


class TradeState(TypedDict):
    symbol: str
    side: Literal["BUY", "SELL"]
    qty: int
    notional_usd: int
    status: Optional[Literal["pending", "approved", "rejected", "executed"]]


def pretrade_checks(state: TradeState) -> dict:
    # Deterministic placeholder: in real life this could compute risk, slippage, limits, etc.
    return {"status": "pending"}


def approval_gate(state: TradeState) -> Command[Literal["execute", "reject"]]:
    requires_approval = state["notional_usd"] >= 100_000

    if not requires_approval:
        return Command(update={"status": "approved"}, goto="execute")

    approved = interrupt(
        {
            "question": "Approve trade execution?",
            "symbol": state["symbol"],
            "side": state["side"],
            "qty": state["qty"],
            "notional_usd": state["notional_usd"],
        }
    )

    if approved:
        return Command(update={"status": "approved"}, goto="execute")

    return Command(update={"status": "rejected"}, goto="reject")


def execute(state: TradeState) -> dict:
    # Deterministic placeholder for an execution step.
    return {"status": "executed"}


def reject(state: TradeState) -> dict:
    return {"status": "rejected"}


builder = StateGraph(TradeState)
builder.add_node("pretrade_checks", pretrade_checks)
builder.add_node("approval_gate", approval_gate)
builder.add_node("execute", execute)
builder.add_node("reject", reject)

builder.add_edge(START, "pretrade_checks")
builder.add_edge("pretrade_checks", "approval_gate")
builder.add_edge("execute", END)
builder.add_edge("reject", END)

checkpointer = MemorySaver()
graph = builder.compile(checkpointer=checkpointer)

if __name__ == "__main__":
    # thread_id is required for the checkpointer to store and reload state for resumes.
    config = {"configurable": {"thread_id": "trade-thread-42"}}

    first = graph.invoke(
        {
            "symbol": "AAPL",
            "side": "BUY",
            "qty": 500,
            "notional_usd": 125_000,
            "status": None,
        },
        config=config,
    )

    print("interrupt_payload:", first["__interrupt__"])

    # Resume with the human's decision using the same thread_id.
    resumed = graph.invoke(Command(resume=True), config=config)
    print("final_status:", resumed["status"])


