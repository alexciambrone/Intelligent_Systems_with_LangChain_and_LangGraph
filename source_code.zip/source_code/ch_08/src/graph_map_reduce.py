from __future__ import annotations

import operator
from typing import Annotated, List, Tuple
from typing_extensions import TypedDict

from langgraph.graph import START, END, StateGraph
from langgraph.types import Send
import requests
from bs4 import BeautifulSoup


class ChunkSummary(TypedDict):
    chunk_id: int
    summary: str


class SummarizeState(TypedDict, total=False):
    # Inputs
    text: str
    chunk_size: int
    chunk_overlap: int

    # Derived
    chunks: List[str]

    # Map outputs (many parallel workers update this key)
    chunk_summaries: Annotated[List[ChunkSummary], operator.add]

    # Final output
    final_summary: str


def _split_text(text: str, chunk_size: int, chunk_overlap: int) -> List[str]:
    if chunk_size <= 0:
        raise ValueError("chunk_size must be > 0")
    if chunk_overlap < 0:
        raise ValueError("chunk_overlap must be >= 0")
    if chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be < chunk_size")

    chunks: List[str] = []
    start = 0
    text = text or ""

    while start < len(text):
        end = min(len(text), start + chunk_size)
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = end - chunk_overlap

    return chunks


def chunk_document(state: SummarizeState) -> dict:
    text = state.get("text", "")
    chunk_size = int(state.get("chunk_size", 800))
    chunk_overlap = int(state.get("chunk_overlap", 80))
    chunks = _split_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    return {"chunks": chunks}


def continue_to_map(state: SummarizeState) -> List[Send]:
    sends: List[Send] = []
    for i, chunk in enumerate(state.get("chunks", [])):
        sends.append(Send("summarize_chunk", {"chunk_id": i, "chunk_text": chunk}))
    return sends

def fetch_webpage_text(url: str, timeout: int = 20) -> str:
    resp = requests.get(
        url,
        timeout=timeout,
        headers={"User-Agent": "Mozilla/5.0 (compatible; LangGraphSummarizer/1.0)"},
    )
    resp.raise_for_status()

    soup = BeautifulSoup(resp.text, "html.parser")

    # Remove script/style/noscript to reduce junk.
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    # Basic text extraction. (For article-like pages, Option B is better.)
    text = soup.get_text(separator="\n")

    # Normalize whitespace a bit
    lines = [ln.strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]
    return "\n".join(lines)

class ChunkTaskState(TypedDict):
    chunk_id: int
    chunk_text: str


def _cheap_deterministic_summary(text: str, max_words: int = 40) -> str:
    # A deterministic summariser so the example runs without external model calls.
    # Replace this with an LLM call in production.
    words = (text or "").strip().split()
    if not words:
        return ""
    return " ".join(words[:max_words]).strip()


def summarize_chunk(state: ChunkTaskState) -> dict:
    chunk_id = int(state["chunk_id"])
    chunk_text = state["chunk_text"]
    summary = _cheap_deterministic_summary(chunk_text, max_words=40)
    return {"chunk_summaries": [{"chunk_id": chunk_id, "summary": summary}]}


def reduce_summaries(state: SummarizeState) -> dict:
    items = state.get("chunk_summaries", []) or []
    # LangGraph notes that updates from parallel branches may not be consistently ordered.
    # Sort by chunk_id to enforce stable, reproducible synthesis.
    items_sorted = sorted(items, key=lambda x: int(x["chunk_id"]))

    combined = []
    for item in items_sorted:
        s = (item.get("summary") or "").strip()
        if s:
            combined.append(f"[chunk {item['chunk_id']}] {s}")

    final = "\n".join(combined).strip()
    return {"final_summary": final}


def build_graph():
    builder = StateGraph(SummarizeState)
    builder.add_node("chunk_document", chunk_document)
    builder.add_node("summarize_chunk", summarize_chunk)
    builder.add_node("reduce_summaries", reduce_summaries)

    builder.add_edge(START, "chunk_document")
    # Dynamic fan-out using Send
    builder.add_conditional_edges("chunk_document", continue_to_map, ["summarize_chunk"])
    builder.add_edge("summarize_chunk", "reduce_summaries")
    builder.add_edge("reduce_summaries", END)
    return builder.compile()


def main() -> None:
    graph = build_graph()

    url = "https://qdrant.tech/documentation/concepts/collections/"
    long_text = fetch_webpage_text(url)

    # You can control concurrency when invoking; LangGraph documents max_concurrency as a config option.
    # For portability across versions, pass it as part of the second argument dict.
    result = graph.invoke(
        {"text": long_text, "chunk_size": 300, "chunk_overlap": 30},
        {
            "max_concurrency": 8,
            "configurable": {
                "thread_id": "thread-A",   # if you use checkpointing/threads
                "user_id": "user-42",      # if your nodes read config["configurable"]["user_id"]
            },
        },
    )

    print(result["final_summary"])


if __name__ == "__main__":
    main()


