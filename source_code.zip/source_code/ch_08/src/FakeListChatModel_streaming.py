from langchain_core.language_models.fake_chat_models import (
    FakeListChatModel,
    FakeListChatModelError,
)

def test_fail_mid_stream() -> None:
    # FakeListChatModel streams its response one character at a time.
    # error_on_chunk_number is 0-based: 0 = first char, 1 = second char, etc.
    model = FakeListChatModel(
        responses=["streaming output"],
        error_on_chunk_number=5,  # raise right before yielding chunk #5
    )

    received_chunks: list[str] = []

    try:
        for chunk in model.stream("ignored input"):
            # chunk is an AIMessageChunk; .content contains the next streamed piece
            received_chunks.append(chunk.content)

        raise AssertionError("Expected FakeListChatModelError, but the stream completed successfully.")
    except FakeListChatModelError:
        partial = "".join(received_chunks)

        # "streaming output" streamed as: s(0) t(1) r(2) e(3) a(4) ... then error at chunk 5
        assert partial == "strea", f"Unexpected partial output: {partial!r}"


if __name__ == "__main__":
    # Run as a plain script (no pytest needed)
    test_fail_mid_stream()
    print("OK: FakeListChatModelError was raised mid-stream as expected.")