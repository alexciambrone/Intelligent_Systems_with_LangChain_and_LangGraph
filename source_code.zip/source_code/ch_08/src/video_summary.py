from __future__ import annotations

import operator
from typing import Annotated, List
from typing_extensions import TypedDict

from langgraph.graph import START, END, StateGraph
from langgraph.types import Send


class Segment(TypedDict):
    start_s: float
    end_s: float
    text: str


class IntervalSummary(TypedDict):
    interval_id: int
    start_s: float
    end_s: float
    summary: str


class VideoState(TypedDict, total=False):
    # Inputs
    segments: List[Segment]
    max_chars_per_window: int

    # Derived windows
    windows: List[List[Segment]]

    # Map outputs
    interval_summaries: Annotated[List[IntervalSummary], operator.add]

    # Final output
    timeline: str


def group_segments(state: VideoState) -> dict:
    segments = state.get("segments", []) or []
    max_chars = int(state.get("max_chars_per_window", 800))

    windows: List[List[Segment]] = []
    current: List[Segment] = []
    current_len = 0

    for seg in segments:
        seg_text = (seg.get("text") or "").strip()
        if not seg_text:
            continue
        seg_len = len(seg_text)

        # Start a new window if adding this segment would exceed the budget.
        if current and (current_len + seg_len) > max_chars:
            windows.append(current)
            current = []
            current_len = 0

        current.append(seg)
        current_len += seg_len

    if current:
        windows.append(current)

    return {"windows": windows}


def continue_to_map(state: VideoState) -> List[Send]:
    sends: List[Send] = []
    for i, window in enumerate(state.get("windows", []) or []):
        sends.append(Send("summarize_interval", {"interval_id": i, "window": window}))
    return sends


class IntervalTaskState(TypedDict):
    interval_id: int
    window: List[Segment]


def _deterministic_interval_summary(window: List[Segment], max_words: int = 35) -> str:
    joined = " ".join((seg.get("text") or "").strip() for seg in window).strip()
    words = joined.split()
    return " ".join(words[:max_words]).strip()


def summarize_interval(state: IntervalTaskState) -> dict:
    interval_id = int(state["interval_id"])
    window = state["window"]

    start_s = float(window[0]["start_s"])
    end_s = float(window[-1]["end_s"])
    summary = _deterministic_interval_summary(window, max_words=35)

    return {
        "interval_summaries": [
            {
                "interval_id": interval_id,
                "start_s": start_s,
                "end_s": end_s,
                "summary": summary,
            }
        ]
    }


def build_timeline(state: VideoState) -> dict:
    items = state.get("interval_summaries", []) or []
    items_sorted = sorted(items, key=lambda x: int(x["interval_id"]))

    lines = []
    for it in items_sorted:
        lines.append(f"{it['start_s']:.1f}s–{it['end_s']:.1f}s: {it['summary']}")
    return {"timeline": "\n".join(lines).strip()}


def build_graph():
    builder = StateGraph(VideoState)
    builder.add_node("group_segments", group_segments)
    builder.add_node("summarize_interval", summarize_interval)
    builder.add_node("build_timeline", build_timeline)

    builder.add_edge(START, "group_segments")
    builder.add_conditional_edges("group_segments", continue_to_map, ["summarize_interval"])
    builder.add_edge("summarize_interval", "build_timeline")
    builder.add_edge("build_timeline", END)

    return builder.compile()


def main() -> None:
    # Simulated transcript segments (in practice produced by a transcription system).
    segments: List[Segment] = [
        {"start_s": 0.0, "end_s": 8.0, "text": "Welcome back. Today we will reset a password and review account security."},
        {"start_s": 8.0, "end_s": 18.0, "text": "First, open settings. Then choose security. Enable two-factor authentication."},
        {"start_s": 18.0, "end_s": 30.0, "text": "If you lost access to your phone, use recovery codes or contact support."},
        {"start_s": 30.0, "end_s": 45.0, "text": "Finally, confirm the email address and sign out of other devices."},
    ]

    graph = build_graph()
    result = graph.invoke(
        {"segments": segments, "max_chars_per_window": 120},
        {"configurable": {"max_concurrency": 4}},
    )

    print(result["timeline"])


if __name__ == "__main__":
    main()


