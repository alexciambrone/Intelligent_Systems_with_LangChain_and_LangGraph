from typing import TypedDict, Annotated
from dataclasses import dataclass
from langgraph.graph import StateGraph, START, END

# 1. State Definition
class State(TypedDict):
    question: str
    answer: str

# 2. Context Schema
@dataclass
class Context:
    region: str = "US"

# 3. Node Definition
# We use the argument name 'runtime'—LangGraph will inject the object here
def answer_returns(state: State, runtime): 
    q = state["question"].lower()
    
    # Access context via the injected runtime object
    region = runtime.context.region
    
    if "return" not in q and "refund" not in q:
        return {"answer": "Ask me about orders, returns, payments, or accounts."}

    if region == "EU":
        text = "EU returns: start a return with your order number within 30 days of delivery."
    else:
        text = "US returns: start a return from your order page; a label is provided for eligible items."
    
    return {"answer": text}

# 4. Graph Construction
# Passing context_schema tells the graph how to validate the 'context' arg in invoke
builder = StateGraph(State, context_schema=Context)
builder.add_node("answer_returns", answer_returns)
builder.add_edge(START, "answer_returns")
builder.add_edge("answer_returns", END)

graph = builder.compile()

if __name__ == "__main__":
    # 5. Invoke passing 'context' directly as a keyword argument
    out = graph.invoke(
        {"question": "How do I return an item?", "answer": ""},
        context=Context(region="EU"),
    )
    print(out["answer"])