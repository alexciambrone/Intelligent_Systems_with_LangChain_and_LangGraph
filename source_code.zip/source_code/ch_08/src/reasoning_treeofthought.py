from __future__ import annotations

import os
import operator
import re
from typing import Annotated, Literal
from typing_extensions import TypedDict

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END

from .config import OPENAI_API_KEY


# -----------------------------------------------------------------------------
# State
# -----------------------------------------------------------------------------
class SupportState(TypedDict, total=False):
    """
    State is the shared memory that moves through the graph.

    NOTE on reducers:
    - `trace` uses operator.add so every node can append lines without overwriting.
    - Everything else overwrites by default (last write wins).
    """

    # Input question from user
    question: str

    # ToT loop controls
    depth: int
    max_depth: int
    fanout: int
    beam_width: int

    # Working sets produced each round (we overwrite these explicitly each round)
    candidates: list[str]
    survivors: list[str]

    # The best answer found so far (we overwrite each round)
    final_answer: str

    # Human-readable trace of the ToT process (accumulates across rounds)
    trace: Annotated[list[str], operator.add]


# Temperature 0 makes the demo more deterministic (better for teaching).
model = ChatOpenAI(model="gpt-4o-mini", temperature=0)


# -----------------------------------------------------------------------------
# Prompts
# -----------------------------------------------------------------------------
# Minimal adjustment: accept a "seed_answer" that is empty at depth 0, and filled
# at later depths. The model is instructed to IMPROVE the seed rather than
# regenerate from scratch.
expand_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You generate multiple candidate answers for an e-commerce support question.\n\n"
            "Hard rules:\n"
            "- Do NOT invent order status, shipment dates, tracking numbers, or internal system facts.\n"
            "- If information is missing, ask for what you need and give a helpful next action.\n\n"
            "Refinement rule:\n"
            "- If a SEED ANSWER is provided, generate improved variants of it (clearer, more helpful, better next step).\n"
            "- If no seed is provided, generate candidates from scratch.\n\n"
            "Output requirements:\n"
            "- Provide exactly {fanout} candidates.\n"
            "- Output exactly one candidate per line, prefixed with: 'CANDIDATE <n>: '\n"
            "- Do not add any other text.\n",
        ),
        (
            "human",
            "Question:\n{question}\n\n"
            "SEED ANSWER (may be empty):\n{seed_answer}\n",
        ),
    ]
)

# Selector prompt chooses the best candidate by number.
select_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "Select the single best support answer by number.\n"
            "Criteria:\n"
            "- Correctness (no made-up facts)\n"
            "- Clarity\n"
            "- Helpful next action\n\n"
            "Output format: 'BEST: <n>' and nothing else.\n",
        ),
        ("human", "Question:\n{question}\n\nCandidates:\n{candidates_block}"),
    ]
)


# -----------------------------------------------------------------------------
# Parsers (turn model output into structured data)
# -----------------------------------------------------------------------------
_candidate_line = re.compile(r"^CANDIDATE\s+\d+:\s*(.*)\s*$", re.IGNORECASE)
_best_line = re.compile(r"BEST:\s*(\d+)", re.IGNORECASE)


def parse_candidates(text: str) -> list[str]:
    """
    Extract candidate lines like:
      CANDIDATE 1: ...
      CANDIDATE 2: ...
    Returns list of candidate strings (without the prefix).
    """
    out: list[str] = []
    for line in text.splitlines():
        m = _candidate_line.match(line.strip())
        if m:
            out.append(m.group(1).strip())
    return out


def parse_best_index(text: str) -> int | None:
    """
    Extract BEST: <n> and convert to 0-based index.
    Returns None if parsing fails.
    """
    m = _best_line.search(text)
    if not m:
        return None
    idx = int(m.group(1)) - 1
    return idx if idx >= 0 else None


def preview(s: str, n: int = 90) -> str:
    """
    Produce a compact one-line preview for trace output.
    """
    s = " ".join(s.split())
    return s if len(s) <= n else s[: n - 3] + "..."


# -----------------------------------------------------------------------------
# Nodes (graph steps)
# -----------------------------------------------------------------------------
def expand(state: SupportState) -> dict:
    """
    Fan-out step:
    - depth == 0: generate candidates from scratch (seed empty)
    - depth >= 1: generate improved variants of the current best answer
                 (seed = state['final_answer'])
    """
    question = state["question"]
    depth = state.get("depth", 0)
    fanout = state.get("fanout", 5)

    # Minimal adjustment: feed the prior best answer back in as "seed_answer"
    seed_answer = "" if depth == 0 else state.get("final_answer", "")

    msg = (expand_prompt | model).invoke(
        {"question": question, "fanout": fanout, "seed_answer": seed_answer}
    )

    candidates = parse_candidates(msg.content)

    # If formatting is wrong, fall back to one "candidate" (keeps demo resilient).
    if not candidates:
        candidates = [msg.content.strip()]

    trace_lines = [f"D{depth} expand: {len(candidates)} candidates"]
    if seed_answer:
        trace_lines.append(f"  seed: {preview(seed_answer)}")
    for i, c in enumerate(candidates, start=1):
        trace_lines.append(f"  - C{i}: {preview(c)}")

    # IMPORTANT PASSAGE:
    # We overwrite candidates each round (not append), to keep each depth self-contained.
    return {"candidates": candidates, "trace": trace_lines}


def select_and_prune(state: SupportState) -> dict:
    """
    Prune step:
    - Choose the best candidate (BEST: n)
    - Keep a small survivor set (beam), primarily to show the concept
      (we don't actually expand per-survivor in this minimal demo).
    """
    candidates = state.get("candidates", [])
    depth = state.get("depth", 0)

    if not candidates:
        # Defensive: should not happen, but keeps the graph stable.
        return {"survivors": [], "final_answer": "", "trace": [f"D{depth} select: no candidates"]}

    beam_width = state.get("beam_width", 2)
    candidates_block = "\n".join(f"{i+1}. {c}" for i, c in enumerate(candidates))

    msg = (select_prompt | model).invoke(
        {"question": state["question"], "candidates_block": candidates_block}
    )

    best_idx = parse_best_index(msg.content)

    # Defensive: if selector output is malformed, default to the first candidate.
    if best_idx is None or best_idx >= len(candidates):
        best_idx = 0

    best = candidates[best_idx]

    # Beam survivors: keep best + a couple backups (simple demonstration).
    others = [c for i, c in enumerate(candidates) if i != best_idx]
    survivors = [best] + others[: max(0, beam_width - 1)]

    trace_lines = [
        f"D{depth} select: BEST={best_idx+1}",
        f"  keep beam_width={beam_width} => survivors={len(survivors)}",
        f"  best: {preview(best)}",
    ]

    # IMPORTANT PASSAGE:
    # `final_answer` is the "best so far". Next round uses it as a seed.
    return {"survivors": survivors, "final_answer": best, "trace": trace_lines}


def increment_depth(state: SupportState) -> dict:
    """
    Loop bookkeeping:
    - Increase depth by 1
    - Clear candidates so the next round doesn't carry old candidates forward.
    """
    d = state.get("depth", 0) + 1
    return {"depth": d, "candidates": [], "trace": [f"advance: depth -> {d}"]}


def route(state: SupportState) -> Literal["expand", "end"]:
    """
    Decide whether to continue looping.

    We stop when depth >= max_depth.
    """
    return "expand" if state.get("depth", 0) < state.get("max_depth", 2) else "end"


# -----------------------------------------------------------------------------
# Graph wiring
# -----------------------------------------------------------------------------
builder = StateGraph(SupportState)

# Register nodes
builder.add_node("expand", expand)
builder.add_node("select_and_prune", select_and_prune)
builder.add_node("increment_depth", increment_depth)

# Linear: START -> expand -> select -> increment -> (expand or END)
builder.add_edge(START, "expand")
builder.add_edge("expand", "select_and_prune")
builder.add_edge("select_and_prune", "increment_depth")
builder.add_conditional_edges("increment_depth", route, {"expand": "expand", "end": END})

graph = builder.compile()


# -----------------------------------------------------------------------------
# Run (print tree trace + final answer)
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    out = graph.invoke(
        {
            "question": "Where is my order #1234?",
            "depth": 0,
            "max_depth": 2,   # number of refine rounds
            "fanout": 3,      # how many candidates each round
            "beam_width": 2,  # how many survivors to keep (demo)
            "candidates": [],
            "survivors": [],
            "final_answer": "",
            "trace": [],
        }
    )

    print("\n=== TREE TRACE (ToT artifacts, not hidden reasoning) ===")
    for line in out.get("trace", []):
        print(line)

    print("\n=== FINAL ANSWER ===")
    print(out.get("final_answer", ""))
