import operator
from typing import List, Union
from typing_extensions import TypedDict, Annotated

from langchain_core.messages import AnyMessage, HumanMessage, AIMessage
from langgraph.graph import MessagesState, StateGraph, START, END
from langgraph.graph.message import add_messages

# 1. Define the State
# MessagesState already contains "messages": Annotated[list[AnyMessage], add_messages]
class ChatState(MessagesState):
    # Optional: You can add more fields here
    user_name: str

# 2. Define the Node function
def reply_node(state: ChatState) -> dict:
    """
    Takes the current state, processes the last message, 
    and returns a new message to be appended.
    """
    # Get the last message from the list
    last_message = state["messages"][-1]
    user_text = last_message.content
    
    # Create the AI response
    response_content = f"Echoing back: '{user_text}'"
    
    # Return a dictionary where the key matches the state key
    # Because of the 'add_messages' reducer, this will append to the list
    return {"messages": [AIMessage(content=response_content)]}

# 3. Build the Graph
builder = StateGraph(ChatState)

# Add our node
builder.add_node("reply", reply_node)

# Define the flow
builder.add_edge(START, "reply")
builder.add_edge("reply", END)

# 4. Compile the Graph
graph = builder.compile()

# 5. Execute the Graph
if __name__ == "__main__":
    # Define initial input
    # We pass a list with one HumanMessage
    initial_input = {
        "messages": [HumanMessage(content="Hello, LangGraph!")],
        "user_name": "Alice"
    }

    print("--- Starting Graph Execution ---")
    result = graph.invoke(initial_input)

    # 6. Print the conversation history
    print("\nConversation History:")
    for m in result["messages"]:
        # Print the type (Human/AI) and the text content
        role = "User" if isinstance(m, HumanMessage) else "Assistant"
        print(f"{role}: {m.content}")


