from __future__ import annotations

from typing_extensions import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import START, END, StateGraph
from langgraph.types import interrupt, Command


# 1. State Definition
class SupportState(TypedDict, total=False):
    message: str
    account_id: str
    answer: str


# 2. Node Definitions
def ensure_account_id(state: SupportState) -> dict:
    account_id = (state.get("account_id") or "").strip()
    if account_id:
        return {}

    # Pause here and surface a payload to the caller
    resume_value = interrupt(
        {
            "problem": "Missing account_id",
            "question": "Which account should I use?",
        }
    )

    # This only runs on the resume call (the node restarts, interrupt returns a value)
    print(f"--- Node resumed with value: {resume_value} ---")
    return {"account_id": str(resume_value).strip()}


def handle_request(state: SupportState) -> dict:
    # This runs after resume and after ensure_account_id returns an account_id
    return {
        "answer": f"Handling request for account_id={state['account_id']}: {state['message']}"
    }


# 3. Graph Construction
builder = StateGraph(SupportState)
builder.add_node("ensure_account_id", ensure_account_id)
builder.add_node("handle_request", handle_request)

builder.add_edge(START, "ensure_account_id")
builder.add_edge("ensure_account_id", "handle_request")
builder.add_edge("handle_request", END)

# 4. Compile with Checkpointer (Crucial for state recovery)
checkpointer = MemorySaver()
graph = builder.compile(checkpointer=checkpointer)

# Use a consistent thread_id so the checkpointer can find the paused state
config = {"configurable": {"thread_id": "recovery-test-thread"}}

# STEP 1: Initial call. Pauses at interrupt.
print("--- Step 1: Initial call (Triggers Interrupt) ---")
step1 = graph.invoke({"message": "Please reset my password."}, config=config)

# Most LangGraph setups surface the interrupt payload in the return value.
# Print it so the demo visibly shows "we paused and asked a question".
print("Step 1 returned:", step1)

# STEP 2: Resume call. Provide the resume value via Command(resume=...).
print("\n--- Step 2: Resuming (Proving Recovery) ---")
final_output = graph.invoke(Command(resume="ACC-12345"), config=config)

# Verification: must have reached END and produced "answer"
if "answer" in final_output:
    print(f"Recovery Successful! Final Answer: {final_output['answer']}")
else:
    print("Recovery Failed: 'answer' not found. Final output was:", final_output)
