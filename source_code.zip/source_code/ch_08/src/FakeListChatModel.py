from __future__ import annotations

from langchain_core.language_models.fake_chat_models import FakeListChatModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate


def build_two_call_chain(model: FakeListChatModel):
    # Call 1: produce a label
    step1_prompt = ChatPromptTemplate.from_messages(
        [("human", "Give a short label for: {topic}")]
    )

    # Call 2: expand the label
    step2_prompt = ChatPromptTemplate.from_messages(
        [("human", "Now expand on this label in one sentence: {label}")]
    )

    # First model call -> string label
    label_chain = step1_prompt | model | StrOutputParser()

    # Second model call: map {"label": <result of label_chain>} into the second prompt
    step2_chain = (
        {"label": label_chain}
        | step2_prompt
        | model
        | StrOutputParser()
    )

    return step2_chain


def test_multi_call_flow_with_fake_list_chat_model() -> None:
    model = FakeListChatModel(
        responses=[
            "ALPHA",
            "ALPHA is the first letter of the Greek alphabet.",
        ]
    )
    chain = build_two_call_chain(model)

    out = chain.invoke({"topic": "Greek alphabet"})
    assert out == "ALPHA is the first letter of the Greek alphabet."


if __name__ == "__main__":
    # Run the test as a simple script (no pytest required).
    test_multi_call_flow_with_fake_list_chat_model()
    print("OK")



