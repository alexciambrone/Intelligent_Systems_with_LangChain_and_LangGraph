from __future__ import annotations

import os
import json
import operator
from typing import Annotated, Literal
from typing_extensions import TypedDict

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

from .config import OPENAI_API_KEY
from langgraph.graph import StateGraph, START, END


# --- State -----------------------------------------------------------------
class SupportState(TypedDict, total=False):
    question: str
    answer: str

    # Least-to-most additions
    subtasks: Annotated[list[str], operator.add]
    solutions: Annotated[list[str], operator.add]
    idx: Annotated[int, operator.add]


# --- Model -----------------------------------------------------------------
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY
model = ChatOpenAI(temperature=0.2)


# --- Prompts ---------------------------------------------------------------

# 1) Decompose into ordered subtasks (least -> most)
decompose_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a careful e-commerce support assistant.\n"
            "Break the user's request into 2-5 smaller subquestions ordered from easiest to hardest.\n"
            "Return ONLY valid JSON in this exact shape:\n"
            '{{ "subtasks": ["...","..."] }}',  # <-- escaped braces
        ),
        ("human", "{question}"),
    ]
)

# 2) Solve one subtask at a time
solve_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a careful e-commerce support assistant.\n"
            "Answer the subtask concisely and precisely.\n"
            "Do not invent order data; if details are missing, state what would be needed.\n",
        ),
        ("human", "Original request:\n{question}\n\nSubtask:\n{subtask}"),
    ]
)

# 3) Combine intermediate answers into a final response
combine_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a careful e-commerce support assistant.\n"
            "Write the final customer-facing answer using the solved subtasks.\n"
            "Be clear, actionable, and avoid internal process language.\n",
        ),
        ("human", "Original request:\n{question}\n\nSolved subtasks:\n{solutions}"),
    ]
)


# --- Nodes -----------------------------------------------------------------

def decompose(state: SupportState) -> dict:
    msg = (decompose_prompt | model).invoke({"question": state["question"]})
    text = msg.content.strip()

    # Parse the required JSON shape. If parsing fails, fall back to a single subtask.
    subtasks: list[str]
    try:
        data = json.loads(text)
        subtasks = [s.strip() for s in data.get("subtasks", []) if s and s.strip()]
        if not subtasks:
            subtasks = [state["question"]]
    except Exception:
        subtasks = [state["question"]]

    # Initialize the loop counter.
    return {"subtasks": subtasks, "solutions": [], "idx": 0}

def solve_next(state: SupportState) -> dict:
    subtasks = state.get("subtasks", [])
    idx = state.get("idx", 0)

    # Defensive: if nothing left, do nothing (router will move to combine).
    if idx >= len(subtasks):
        return {}

    subtask = subtasks[idx]
    msg = (solve_prompt | model).invoke({"question": state["question"], "subtask": subtask})

    return {
        "solutions": [msg.content.strip()],
        "idx": 1,  # accumulated via reducer to advance to the next subtask
    }

def route(state: SupportState) -> Literal["solve_next", "combine"]:
    subtasks = state.get("subtasks", [])
    idx = state.get("idx", 0)
    return "solve_next" if idx < len(subtasks) else "combine"

def combine(state: SupportState) -> dict:
    solutions = state.get("solutions", [])
    numbered = "\n".join(f"{i+1}. {s}" for i, s in enumerate(solutions)) or "(no intermediate results)"
    msg = (combine_prompt | model).invoke({"question": state["question"], "solutions": numbered})
    return {"answer": msg.content.strip()}


# --- Graph ------------------------------------------------------------------
builder = StateGraph(SupportState)

builder.add_node("decompose", decompose)
builder.add_node("solve_next", solve_next)
builder.add_node("combine", combine)

builder.add_edge(START, "decompose")
builder.add_edge("decompose", "solve_next")
builder.add_conditional_edges("solve_next", route)
builder.add_edge("combine", END)

graph = builder.compile()


if __name__ == "__main__":
    out = graph.invoke(
        {
            "question": "My package says delivered but I can't find it. Also, I might need to change the delivery address for my next order. What should I do?"
        }
    )
    print(out["answer"])



