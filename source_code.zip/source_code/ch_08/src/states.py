from __future__ import annotations
import operator
from typing import Annotated, Literal
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END

# -----------------------------
# 1) Public API: input + output
# -----------------------------
class InputState(TypedDict):
    # What the caller must supply
    user_id: str
    question: str

class OutputState(TypedDict):
    # What the caller receives back
    answer: str
    sources: list[str]

# -----------------------------------------
# 2) Internal union: everything nodes touch
# -----------------------------------------
# IMPORTANT: every key any node will write must exist here.
# "Private/internal channels" are simply keys you keep OUT of OutputState.
class OverallState(InputState):
    # Internal working data
    normalized_question: str
    need_retrieval: bool
    docs: list[str]

    # Internal diagnostics / paper trail (private)
    debug_log: Annotated[list[str], operator.add]

    # Final output keys (still part of internal state because nodes write them)
    answer: str
    sources: list[str]

# -----------------------------
# 3) Nodes: read state, emit updates
# -----------------------------
def preprocess(state: InputState) -> dict:
    q = state["question"].strip()
    normalized = " ".join(q.split())  # collapse whitespace
    return {
        "normalized_question": normalized,
        "debug_log": [f"preprocess: normalized question='{normalized}'"],
    }


def decide_route(state: OverallState) -> dict:
    # A toy routing rule: do retrieval if the question looks factual.
    q = state["normalized_question"].lower()
    need = any(word in q for word in ("who", "what", "when", "where", "source", "cite"))
    return {
        "need_retrieval": need,
        "debug_log": [f"route: need_retrieval={need}"]
    }

def retrieve(state: OverallState) -> dict:
    # In a real app you'd call a retriever / DB here.
    # We keep it deterministic so the example is runnable without external dependencies.
    q = state["normalized_question"]
    docs = [
        f"Doc A relevant to: {q}",
        f"Doc B relevant to: {q}"
    ]
    return {
        "docs": docs,
        "debug_log": [f"retrieve: fetched {len(docs)} docs"],
    }

def generate(state: OverallState) -> dict:
    # In a real app you'd call an LLM here. We'll just synthesize a response.
    q = state["normalized_question"]
    docs = state.get("docs", [])
    if docs:
        draft = f"Answer to '{q}' using {len(docs)} document(s)."
    else:
        draft = f"Answer to '{q}' (no retrieval used)."

    return {
        "answer": draft,
        "sources": docs,  # we’ll expose these in OutputState
        "debug_log": ["generate: produced final answer"],
    }

# -----------------------------
# 4) Conditional routing
# -----------------------------
def route_next(state: OverallState) -> Literal["retrieve", "generate"]:
    return "retrieve" if state["need_retrieval"] else "generate"

# -----------------------------
# 5) Build graph with input/output filters
# -----------------------------
builder = StateGraph(OverallState, input_schema=InputState, output_schema=OutputState)
builder.add_node("preprocess", preprocess)
builder.add_node("decide_route", decide_route)
builder.add_node("retrieve", retrieve)
builder.add_node("generate", generate)

builder.add_edge(START, "preprocess")
builder.add_edge("preprocess", "decide_route")
builder.add_conditional_edges("decide_route", route_next)
builder.add_edge("retrieve", "generate")
builder.add_edge("generate", END)

graph = builder.compile()

if __name__ == "__main__":
    # Caller supplies ONLY InputState.
    result = graph.invoke({"user_id": "u-123", "question": "What is LangGraph?"})
    print("invoke() result (filtered by OutputState):")
    print(result)

    # If you want to inspect internal state evolution (including "private" channels),
    # stream the run in "values" mode to see full state snapshots. 
    print("\nstream(values) snapshots (full internal state, including debug_log):")
    for snapshot in graph.stream(
        {"user_id": "u-123", "question": "What is LangGraph?"},
        stream_mode="values",
    ):
        print(snapshot)