from __future__ import annotations

from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.sqlite import SqliteSaver


class MyState(TypedDict, total=False):
    counter: int
    some_flag: str


def my_node(state: MyState) -> dict:
    new_counter = int(state.get("counter", 0)) + 1
    print(
        f"--- Executing Node: Counter is {new_counter}, "
        f"Flag is '{state.get('some_flag')}' ---"
    )
    return {"counter": new_counter}


builder = StateGraph(MyState)
builder.add_node("my_node", my_node)
builder.add_edge(START, "my_node")
builder.add_edge("my_node", END)

DB_PATH = "timetravel_demo.db"

with SqliteSaver.from_conn_string(DB_PATH) as saver:
    graph = builder.compile(checkpointer=saver)

    thread_id = "t-1"
    base_config = {"configurable": {"thread_id": thread_id}}

    # ----------------------------
    # Phase 1: Normal execution
    # ----------------------------
    print("--- Phase 1: Normal Execution ---")
    graph.invoke({"counter": 0, "some_flag": "broken"}, config=base_config)
    graph.invoke({}, config=base_config)

    # ----------------------------
    # Phase 2: Time travel recovery
    # ----------------------------
    print("\n--- Phase 2: Time Travel Recovery ---")

    history = list(graph.get_state_history(base_config))
    print(f"Checkpoints found: {len(history)}")

    # Show a few and also find a usable target checkpoint:
    # pick the first checkpoint (in history order) whose stored state is non-empty
    # and ideally includes 'some_flag' so this demo is unambiguous.
    target = None
    for i, h in enumerate(history):
        cfg = h.config.get("configurable", {})
        checkpoint_id = cfg.get("checkpoint_id")
        vals = graph.get_state(h.config).values

        # Print a compact view
        if i < 100:
            print(f"  [{i}] checkpoint_id={checkpoint_id} state={vals}")

        # Choose a checkpoint that has our domain fields
        if isinstance(vals, dict) and ("some_flag" in vals or "counter" in vals):
            target = h

    if target is None:
        raise RuntimeError(
            "Could not find a checkpoint with application state (counter/some_flag). "
            "Your DB likely contains only structural checkpoints for this thread."
        )

    print("\nChosen target checkpoint:")
    print("checkpoint_id:", target.config["configurable"].get("checkpoint_id"))
    print("state:", graph.get_state(target.config).values)

    print("\nRewinding and patching state...")

    # IMPORTANT: return type of update_state is version-dependent.
    # Some versions return a snapshot-like object, others return a dict, others None.
    graph.update_state(target.config, {"some_flag": "fixed"})

    # After patching, get the CURRENT state for the thread (latest checkpoint)
    # This avoids relying on update_state return shape.
    patched_latest = graph.get_state(base_config).values
    print("Patched latest state for thread:", patched_latest)

    print("\nResuming execution from patched thread state...")
    # Invoke with base_config so the runtime uses the latest checkpoint for this thread.
    result = graph.invoke({}, config=base_config)

    print("\n--- Final Result after Recovery ---")
    print(f"Counter: {result.get('counter')}")
    print(f"Some Flag: {result.get('some_flag')}")
