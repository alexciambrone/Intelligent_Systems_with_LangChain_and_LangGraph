from __future__ import annotations

import json
from typing import Literal
from typing_extensions import TypedDict

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, START, END
from .config import OPENAI_API_KEY


# --- State -----------------------------------------------------------------
class SupportState(TypedDict, total=False):
    question: str
    answer: str

    # Verification additions
    verdict_ok: bool
    issues: list[str]


# --- Model -----------------------------------------------------------------
model = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)


# --- Prompts ---------------------------------------------------------------

generate_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a careful e-commerce support assistant."),
        ("human", "{question}"),
    ]
)

check_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a strict quality checker for an e-commerce support assistant.\n"
            "Evaluate the draft answer against these rules:\n"
            "1) Do not invent order/shipping/account facts.\n"
            "2) If info is missing, explicitly ask for what is needed.\n"
            "3) Provide clear, actionable next steps.\n"
            "Return ONLY valid JSON in this exact shape:\n"
            '{{ "ok": true/false, "issues": ["..."] }}',
        ),
        ("human", "Customer question:\n{question}\n\nDraft answer:\n{answer}"),
    ]
)

repair_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a careful e-commerce support assistant.\n"
            "Rewrite the answer to fix the issues listed by the checker.\n"
            "Do not invent facts. If required info is missing, ask for it.\n"
            "Return a final customer-facing answer.\n",
        ),
        (
            "human",
            "Customer question:\n{question}\n\nDraft answer:\n{answer}\n\nIssues:\n{issues}",
        ),
    ]
)


# --- Nodes -----------------------------------------------------------------

def generate(state: SupportState) -> dict:
    msg = (generate_prompt | model).invoke({"question": state["question"]})
    return {"answer": msg.content.strip()}

def check(state: SupportState) -> dict:
    msg = (check_prompt | model).invoke(
        {"question": state["question"], "answer": state.get("answer", "")}
    )
    text = msg.content.strip()

    # Make the routing decision machine-readable.
    try:
        data = json.loads(text)
        ok = bool(data.get("ok", False))
        issues = data.get("issues", [])
        if not isinstance(issues, list):
            issues = [str(issues)]
        issues = [str(i).strip() for i in issues if str(i).strip()]
    except Exception:
        # Conservative fallback: if parsing fails, treat as not OK and request repair.
        ok = False
        issues = ["Checker returned invalid JSON; answer must be reviewed and rewritten."]

    return {"verdict_ok": ok, "issues": issues}

def route_after_check(state: SupportState) -> Literal["accept", "repair"]:
    return "accept" if state.get("verdict_ok", False) else "repair"

def repair(state: SupportState) -> dict:
    issues_text = "\n".join(f"- {i}" for i in state.get("issues", [])) or "- (no details)"
    msg = (repair_prompt | model).invoke(
        {
            "question": state["question"],
            "answer": state.get("answer", ""),
            "issues": issues_text,
        }
    )
    return {"answer": msg.content.strip()}


# --- Graph ------------------------------------------------------------------
builder = StateGraph(SupportState)

builder.add_node("generate", generate)
builder.add_node("check", check)
builder.add_node("repair", repair)

builder.add_edge(START, "generate")
builder.add_edge("generate", "check")

builder.add_conditional_edges("check", route_after_check, {"accept": END, "repair": "repair"})
builder.add_edge("repair", END)

graph = builder.compile()


if __name__ == "__main__":
    out = graph.invoke(
        {
            "question": "My package says delivered but I can't find it. What should I do?",
        }
    )
    print(out["answer"])



