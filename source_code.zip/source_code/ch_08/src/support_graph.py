from __future__ import annotations

import operator
from dataclasses import dataclass
from typing import Annotated, Literal
from typing_extensions import TypedDict

from langchain_core.runnables import RunnableConfig
from langgraph.graph import StateGraph, START, END
from langgraph.runtime import Runtime


# Immutable run-scoped context (not part of state).
@dataclass(frozen=True)
class Context:
    region: Literal["EU", "US"]


# Shared mutable state.
class State(TypedDict):
    question: str
    route: Literal["returns", "general"]
    retrieved: Annotated[list[str], operator.add]  # merged from parallel branches
    logs: Annotated[list[str], operator.add]       # merged from parallel branches
    answer: str


def classify(state: State, config: RunnableConfig) -> dict:
    """
    Classify the question. This node reads run-scoped configuration to decide
    what words count as "returns related".
    """
    keywords = config.get("configurable", {}).get("returns_keywords", ["return", "refund"])
    q = state["question"].lower()
    route: Literal["returns", "general"] = "returns" if any(k in q for k in keywords) else "general"
    return {
        "route": route,
        "logs": [f"classify: route={route} (keywords={keywords})"],
    }


def route_after_classify(state: State) -> Literal["returns_fanout", "fetch_general_info"]:
    return "returns_fanout" if state["route"] == "returns" else "fetch_general_info"


def returns_fanout(state: State) -> dict:
    """
    Fan-out node. It exists only to trigger multiple outgoing edges so downstream
    nodes can be scheduled concurrently in the next superstep.
    """
    return {"logs": ["returns_fanout"]}


def fetch_policy(state: State, runtime: Runtime[Context]) -> dict:
    """
    Fetch region-specific policy. The behaviour changes based on runtime context.
    """
    if runtime.context.region == "EU":
        policy = "EU policy: returns accepted within 30 days of delivery."
    else:
        policy = "US policy: returns accepted within 30 days; label provided for eligible items."
    return {
        "retrieved": [policy],
        "logs": [f"fetch_policy: region={runtime.context.region}"],
    }


def fetch_order_facts(state: State) -> dict:
    """
    Fetch order facts. This node is independent of policy lookup and can run in parallel.
    """
    return {
        "retrieved": ["Order facts: the item was delivered 12 days ago."],
        "logs": ["fetch_order_facts: delivery_age_days=12"],
    }


def fetch_general_info(state: State) -> dict:
    return {
        "retrieved": ["General support scope: orders, returns, payments, accounts."],
        "logs": ["fetch_general_info"],
    }


def synthesize(state: State) -> dict:
    """
    Produce a final answer based on whatever was retrieved.
    """
    evidence = " ".join(state["retrieved"])
    if state["route"] == "returns":
        answer = f"You can start a return. {evidence}"
    else:
        answer = f"I can help. {evidence}"
    return {
        "answer": answer,
        "logs": ["synthesize"],
    }


def build_graph():
    builder = StateGraph(State, context_schema=Context)

    builder.add_node("classify", classify)
    builder.add_node("returns_fanout", returns_fanout)
    builder.add_node("fetch_policy", fetch_policy)
    builder.add_node("fetch_order_facts", fetch_order_facts)
    builder.add_node("fetch_general_info", fetch_general_info)
    builder.add_node("synthesize", synthesize)

    builder.add_edge(START, "classify")

    # Conditional routing based on the classification.
    builder.add_conditional_edges(
        "classify",
        route_after_classify,
        {
            "returns_fanout": "returns_fanout",
            "fetch_general_info": "fetch_general_info",
        },
    )

    # Fan-out for the "returns" path: policy and order facts run as two branches.
    builder.add_edge("returns_fanout", "fetch_policy")
    builder.add_edge("returns_fanout", "fetch_order_facts")

    # Fan-in: synthesize runs after both branches complete.
    builder.add_edge("fetch_policy", "synthesize")
    builder.add_edge("fetch_order_facts", "synthesize")

    # Straight-line for the "general" path.
    builder.add_edge("fetch_general_info", "synthesize")

    builder.add_edge("synthesize", END)

    return builder.compile()


if __name__ == "__main__":
    graph = build_graph()

    initial_state: State = {
        "question": "How do I return an item that does not fit?",
        "route": "general",
        "retrieved": [],
        "logs": [],
        "answer": "",
    }

    out = graph.invoke(
        initial_state,
        config={
            "configurable": {"returns_keywords": ["return", "refund", "does not fit"]},
            "tags": ["support", "routing-demo"],
        },
        context=Context(region="EU"),
    )

    print("answer:", out["answer"])
    print("retrieved:", out["retrieved"])
    print("logs:")
    for line in out["logs"]:
        print("-", line)



