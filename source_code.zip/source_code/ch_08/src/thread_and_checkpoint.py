from __future__ import annotations

from typing import Annotated, List
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph.message import add_messages

from langchain_core.messages import HumanMessage, AIMessage, BaseMessage


# StateGraph state with an APPEND reducer for messages
class ChatState(TypedDict, total=False):
    messages: Annotated[List[BaseMessage], add_messages]


def test_node(state: ChatState) -> dict:
    messages = state.get("messages", [])
    history = messages[:-1]  # everything except the current human input

    print("--- Node Execution ---")
    print(f"History length (previous messages) = {len(history)}")

    # IMPORTANT: with add_messages, you return ONLY the new messages to append
    return {"messages": [AIMessage(content="Hello!")]}


# Build graph
builder = StateGraph(ChatState)
builder.add_node("test_node", test_node)
builder.add_edge(START, "test_node")
builder.add_edge("test_node", END)

memory = MemorySaver()
graph = builder.compile(checkpointer=memory)

# Run with different thread IDs
print("Running Thread A (Initial)")
graph.invoke(
    {"messages": [HumanMessage(content="Hi from A")]},
    config={"configurable": {"thread_id": "thread-a"}},
)

print("\nRunning Thread B (Initial)")
graph.invoke(
    {"messages": [HumanMessage(content="Hi from B")]},
    config={"configurable": {"thread_id": "thread-b"}},
)

# Same thread ID again -> history should now include prior Human+AI from thread-a
print("\nRunning Thread A again (Resuming history)")
graph.invoke(
    {"messages": [HumanMessage(content="Second message from A")]},
    config={"configurable": {"thread_id": "thread-a"}},
)

# Inspect checkpoints for Thread A
print("\n--- Checkpoint History for Thread A ---")
checkpoints = list(memory.list(config={"configurable": {"thread_id": "thread-a"}}))
# The in-memory checkpointer's list method in the current MemorySaver
# implementation, checkpoints are typically returned newest-first; do not rely on # ordering unless the backend guarantees it—sort by checkpoint metadata when
# order matters.
for cp in checkpoints:
    print(f"checkpoint_id: {cp.config['configurable']['checkpoint_id']}")

# Time travel to an earlier checkpoint: checkpoints[-1] is the oldest checkpoint for this thread
earlier_checkpoint_id = checkpoints[-1].config["configurable"]["checkpoint_id"]

print(f"\nTime Traveling on Thread A to checkpoint: {earlier_checkpoint_id}")
# IMPORTANT: passing checkpoint_id does not “continue from that point” mid-execution.
# It forks from that checkpoint: LangGraph replays steps up to checkpoint_id, then executes
# subsequent steps as a new history branch (a new fork), even if they ran before.
graph.invoke(
    {"messages": [HumanMessage(content="Restored input")]},
    config={"configurable": {"thread_id": "thread-a", "checkpoint_id": earlier_checkpoint_id}},
)
