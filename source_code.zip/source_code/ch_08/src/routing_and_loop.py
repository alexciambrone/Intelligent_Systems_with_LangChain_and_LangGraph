from typing import Literal, List
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END

# 1. Define the State
class ResearchState(TypedDict):
    question: str
    step_counter: int
    needs_more_research: bool
    notes: List[str]
    answer: str

# 2. Define the Nodes
def research(state: ResearchState) -> dict:
    # Handle initial empty values
    current_step = state.get("step_counter", 0)
    current_notes = state.get("notes", [])
    
    step = current_step + 1
    new_note = f"note {step}: looked up something relevant"
    notes = current_notes + [new_note]
    
    # Logic: Stop after 2 steps
    needs_more = step < 2
    
    print(f"--- Researching (Step {step}) ---")
    return {
        "step_counter": step,
        "notes": notes,
        "needs_more_research": needs_more,
    }

def write_answer(state: ResearchState) -> dict:
    print("--- Writing Final Answer ---")
    joined = "; ".join(state["notes"])
    return {"answer": f"Answer based on: {joined}"}

# 3. Define the Router
def route_after_research(state: ResearchState) -> Literal["research", "write_answer"]:
    if state["needs_more_research"]:
        return "research"
    return "write_answer"

# 4. Build the Graph
builder = StateGraph(ResearchState)

builder.add_node("research", research)
builder.add_node("write_answer", write_answer)

builder.add_edge(START, "research")
builder.add_conditional_edges(
    "research", 
    route_after_research, 
    {
        "research": "research",
        "write_answer": "write_answer",
    }
)
builder.add_edge("write_answer", END)

# 5. Compile and Run
graph = builder.compile()

if __name__ == "__main__":
    # Initial state
    initial_input = {
        "question": "What is LangGraph?",
        "step_counter": 0,
        "notes": []
    }

    # Execute the graph
    final_state = graph.invoke(initial_input)

    # Print the output
    print("\nFinal Results:")
    print(f"Steps taken: {final_state['step_counter']}")
    print(f"Notes: {final_state['notes']}")
    print(f"Final Answer: {final_state['answer']}")


