from __future__ import annotations

from collections.abc import Iterator
from typing import Union

from langchain_core.language_models.fake_chat_models import GenericFakeChatModel
from langchain_core.messages import AIMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate


class FailOnceThenSucceed(Iterator[Union[AIMessage, str]]):
    """
    Iterator consumed by GenericFakeChatModel.
    First "generation" raises ValueError, second returns an AIMessage.
    """

    def __init__(self) -> None:
        self._count = 0

    def __iter__(self) -> "FailOnceThenSucceed":
        return self

    def __next__(self) -> Union[AIMessage, str]:
        self._count += 1
        if self._count == 1:
            raise ValueError("simulated transient failure")
        return AIMessage(content="OK after retry")


def test_retry_only_wraps_the_model_call() -> None:
    prompt = ChatPromptTemplate.from_messages([("human", "Ping")])

    flaky_model = GenericFakeChatModel(messages=FailOnceThenSucceed())

    # Retry only the model call (the part that can fail).
    model_with_retry = flaky_model.with_retry(
        stop_after_attempt=2,
        retry_if_exception_type=(ValueError,),
    )

    chain = prompt | model_with_retry | StrOutputParser()

    out = chain.invoke({})
    assert out == "OK after retry"


if __name__ == "__main__":
    # Run the "test" as a normal script.
    test_retry_only_wraps_the_model_call()
    print("PASS")



