from .config import OPENAI_API_KEY
from typing import List
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_text_splitters import RecursiveCharacterTextSplitter

def build_model() -> ChatOpenAI:
    """
    Single chat model used for both map and reduce steps.
    """
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")

    return ChatOpenAI(
        model="gpt-4.1-mini",
        temperature=0.2,
    )

def build_text_splitter() -> RecursiveCharacterTextSplitter:
    """
    Split long documents into overlapping chunks that fit comfortably
    within the model's context window.
    """
    return RecursiveCharacterTextSplitter(
        chunk_size=1500,
        chunk_overlap=200,
        separators=["\n\n", "\n", ". "],
    )

def build_map_prompt() -> ChatPromptTemplate:
    """
    Map step: summarise a single chunk with a stable, targeted template.
    """
    return ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You are helping to summarise a long technical document. "
                    "Produce a concise summary of the given chunk, focusing on:\n"
                    "- main claims or points\n"
                    "- key evidence or arguments\n"
                    "- important risks or implications\n"
                    "Do NOT try to reference other chunks. Only use the text provided."
                ),
            ),
            ("human", "{chunk_text}"),
        ]
    )

def build_reduce_prompt() -> ChatPromptTemplate:
    """
    Reduce step: combine multiple chunk summaries into a single global summary.
    """
    return ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You will receive several partial summaries of one long document. "
                    "Combine them into a single, coherent summary that a busy engineer "
                    "could read in under two minutes. Focus on:\n"
                    "- overall problem and context\n"
                    "- main findings or proposals\n"
                    "- key risks, trade-offs, and open questions\n"
                    "Avoid repetition and do not invent details that are not implied "
                    "by the partial summaries."
                ),
            ),
            (
                "human",
                (
                    "Here are the partial summaries, in order:\n\n"
                    "{chunk_summaries}\n\n"
                    "Write the final overall summary."
                ),
            ),
        ]
    )

def split_into_chunks(long_text: str) -> List[str]:
    splitter = build_text_splitter()
    return [chunk.page_content for chunk in splitter.create_documents([long_text])]

def map_summarise_chunks(
    model: ChatOpenAI,
    map_prompt: ChatPromptTemplate,
    chunks: List[str],
) -> List[str]:
    """
    Map step: apply the same summarisation prompt to each chunk.
    This is the part you would typically parallelise in production.
    """
    map_chain = map_prompt | model

    chunk_summaries: List[str] = []
    for i, chunk_text in enumerate(chunks, start=1):
        result = map_chain.invoke({"chunk_text": chunk_text})
        summary_text = result.content if hasattr(result, "content") else str(result)
        print(f"\n=== Map summary for chunk {i} ===")
        print(summary_text)
        chunk_summaries.append(summary_text)

    return chunk_summaries

def reduce_summaries(
    model: ChatOpenAI,
    reduce_prompt: ChatPromptTemplate,
    chunk_summaries: List[str],
) -> str:
    """
    Reduce step: summarise the list of chunk summaries into one global summary.
    """
    reduce_chain = reduce_prompt | model

    # Join partial summaries into one text for the reduce step.
    joined_summaries = "\n\n---\n\n".join(chunk_summaries)
    result = reduce_chain.invoke({"chunk_summaries": joined_summaries})
    final_summary = result.content if hasattr(result, "content") else str(result)

    return final_summary

def map_reduce_summarise(long_text: str) -> str:
    """
    End-to-end map–reduce summarisation for a single long document.
    """
    model = build_model()
    map_prompt = build_map_prompt()
    reduce_prompt = build_reduce_prompt()

    # 1) Split the long text into manageable chunks.
    chunks = split_into_chunks(long_text)
    print(f"Document split into {len(chunks)} chunks.")

    # 2) Map: summarise each chunk independently.
    chunk_summaries = map_summarise_chunks(model, map_prompt, chunks)

    # Optional: here you could insert a 'collapse' stage to recursively
    # summarise the chunk_summaries if there are too many of them.

    # 3) Reduce: summarise the partial summaries into a global summary.
    final_summary = reduce_summaries(model, reduce_prompt, chunk_summaries)

    return final_summary

if __name__ == "__main__":
    # For the book, you can replace this with any long article, report, or transcript.
    long_text = (
        "Lorem ipsum style placeholder for a long technical document. "
        "In your real code, this would be the content of a multi-page report, "
        "a long PDF extracted to text, or a transcript. "
        * 50  # just to create something 'long' for demonstration
    )

    summary = map_reduce_summarise(long_text)

    print("\n=== Final map–reduce summary ===")
    print(summary)