from langchain_classic.evaluation import load_evaluator
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY


def print_eval(title: str, question: str, prediction: str, reference: str, res: dict) -> None:
    # Be defensive: different versions may return slightly different keys
    value = res.get("value", res.get("label", "<?>"))
    score = res.get("score", "<?>")
    reasoning = res.get("reasoning", "").strip()

    line = "=" * 80
    print(f"\n{line}\n{title}\n{line}")
    print("QUESTION  :", question)
    print("REFERENCE :", reference)
    print("PREDICTION:", prediction)
    print(f"\nRESULT: value={value} | score={score}")
    if reasoning:
        print("\nREASONING:\n" + reasoning)


judge_llm = ChatOpenAI(model="gpt-4o-mini", temperature=0, api_key=OPENAI_API_KEY)

rubric = {
    "policy_alignment": (
        "Given the policy excerpt in the reference, does the answer follow it exactly "
        "and avoid adding unsupported claims?"
    ),
    "actionability": (
        "Does the answer state the user-facing decision and the next step clearly "
        "in one or two sentences?"
    ),
}

evaluator = load_evaluator(
    "labeled_criteria",
    llm=judge_llm,
    criteria=rubric,
)

question = "Can I return an opened item after 30 days?"

policy_reference = (
    "Return policy: Items may be returned within 30 days of delivery. "
    "Opened items are returnable only if defective. After 30 days, returns are not accepted."
)

good_answer = (
    "No—returns aren’t accepted after 30 days. If it’s been less than 30 days and the item is defective, "
    "start a return claim with your order details."
)

bad_answer = (
    "Yes—opened items can be returned up to 60 days with the receipt; just bring it to the store for a refund."
)

good_res = evaluator.evaluate_strings(
    input=question,
    prediction=good_answer,
    reference=policy_reference,
)
bad_res = evaluator.evaluate_strings(
    input=question,
    prediction=bad_answer,
    reference=policy_reference,
)

print_eval("GOOD (expected Y)", question, good_answer, policy_reference, good_res)
print_eval("BAD  (expected N)", question, bad_answer, policy_reference, bad_res)
