from langchain_classic.evaluation import (
    JsonValidityEvaluator,
    JsonEqualityEvaluator,
    JsonEditDistanceEvaluator,
    JsonSchemaEvaluator,
)

def print_result(title: str, result):
    print(f"\n=== {title} ===")
    print(result)


def main():
    # 1) json_validity: can we parse it as JSON at all?
    validity = JsonValidityEvaluator()

    valid_json = '{"a": 1, "b": 2}'
    invalid_json = '{"a": 1, "b": }'  # malformed JSON

    print_result("json_validity (valid)", validity.evaluate_strings(prediction=valid_json))
    print_result("json_validity (invalid)", validity.evaluate_strings(prediction=invalid_json))

    # 2) json_equality: does parsed JSON match reference JSON?
    equality = JsonEqualityEvaluator()

    same_as_ref = '{"a": 1}'
    different_from_ref = '{"a": 2}'
    ref = '{"a": 1}'

    print_result(
        "json_equality (match)",
        equality.evaluate_strings(prediction=same_as_ref, reference=ref),
    )
    print_result(
        "json_equality (mismatch)",
        equality.evaluate_strings(prediction=different_from_ref, reference=ref),
    )

    # 3) json_edit_distance: how close is prediction JSON to reference JSON?
    # Useful for “getting closer” rather than strict pass/fail.
    edit_distance = JsonEditDistanceEvaluator()

    pred_close = '{"a": 1, "b": 2}'
    ref_close = '{"a": 1, "b": 3}'  # small change

    print_result(
        "json_edit_distance (small difference)",
        edit_distance.evaluate_strings(prediction=pred_close, reference=ref_close),
    )

    # 4) json_schema_validation: does JSON conform to a schema contract?
    schema_eval = JsonSchemaEvaluator()

    schema = {
        "type": "object",
        "properties": {
            "answer": {"type": "string"},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        },
        "required": ["answer", "confidence"],
        "additionalProperties": False,
    }

    schema_ok = '{"answer": "Paris", "confidence": 0.92}'
    schema_bad_missing = '{"answer": "Paris"}'  # missing required field confidence
    schema_bad_extra = '{"answer": "Paris", "confidence": 0.92, "extra": true}'  # extra key not allowed
    schema_bad_range = '{"answer": "Paris", "confidence": 1.7}'  # out of range

    print_result(
        "json_schema_validation (valid)",
        schema_eval.evaluate_strings(prediction=schema_ok, reference=schema),
    )
    print_result(
        "json_schema_validation (missing required field)",
        schema_eval.evaluate_strings(prediction=schema_bad_missing, reference=schema),
    )
    print_result(
        "json_schema_validation (extra field not allowed)",
        schema_eval.evaluate_strings(prediction=schema_bad_extra, reference=schema),
    )
    print_result(
        "json_schema_validation (value out of range)",
        schema_eval.evaluate_strings(prediction=schema_bad_range, reference=schema),
    )


if __name__ == "__main__":
    main()
