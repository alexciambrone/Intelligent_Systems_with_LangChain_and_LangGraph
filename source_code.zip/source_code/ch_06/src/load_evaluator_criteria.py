from langchain_classic.evaluation import load_evaluator
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY


def print_criteria_eval(title: str, question: str, prediction: str, res: dict) -> None:
    line = "=" * 80
    print(f"\n{line}\n{title}\n{line}")
    print("INPUT     :", question)
    print("PREDICTION:", prediction)

    # Common keys returned by CriteriaEvalChain
    value = res.get("value", res.get("label", "<?>"))
    score = res.get("score", "<?>")
    reasoning = (res.get("reasoning") or "").strip()

    print(f"\nRESULT: value={value} | score={score}")
    if reasoning:
        print("\nREASONING:\n" + reasoning)
    else:
        print("\nREASONING: <none>")

    # If other fields exist, print them so nothing is hidden
    extras = {k: v for k, v in res.items() if k not in {"value", "label", "score", "reasoning"}}
    if extras:
        print("\nEXTRA FIELDS:")
        for k, v in extras.items():
            print(f"- {k}: {v}")


judge_llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0,
    api_key=OPENAI_API_KEY,
)

crit_eval = load_evaluator(
    "criteria",
    llm=judge_llm,
    criteria={
        "conciseness": "Is the submission concise and to the point?",
        "coherence": "Is the submission coherent, well-structured, and organized?",
    },
)

question = "Explain what an API is."

good_prediction = "An API is a contract that lets software systems communicate in a defined way."
bad_prediction = (
    "An API is like, you know, a thingy that does stuff, and it’s basically whatever the developer wants, "
    "so it’s hard to say."
)

good_res = crit_eval.evaluate_strings(input=question, prediction=good_prediction)
bad_res = crit_eval.evaluate_strings(input=question, prediction=bad_prediction)

print_criteria_eval("GOOD (expected to score higher)", question, good_prediction, good_res)
print_criteria_eval("BAD  (expected to score lower)", question, bad_prediction, bad_res)
