from __future__ import annotations

from .config import OPENAI_API_KEY
import json
from typing import Any, Dict

from langchain_openai import ChatOpenAI


def build_cod_prompt(review_text: str) -> str:
    """
    Build a simple chain-of-density style prompt for a single review.

    The model is asked to:
    1. Write an initial, vague summary.
    2. List a few important entities missing from that summary.
    3. Rewrite the summary to include those entities, without making it longer.
    """
    return f"""
You are helping to analyse customer feedback.

Here is one detailed customer review:
\"\"\"{review_text}\"\"\"

Follow these steps carefully:
1) Write an INITIAL_SUMMARY of about 60 words. It should be understandable
   but not very detailed. Use only a few concrete entities.
2) Read the original review again. Identify 2–4 important MISSING_ENTITIES
   that are not clearly mentioned in the INITIAL_SUMMARY. Each entity must be:
   - specific and short (no more than 5 words),
   - relevant to the main issues or praise in the review,
   - actually present in the review text.
3) Write a DENSER_SUMMARY of about 60 words that:
   - keeps all information from the INITIAL_SUMMARY,
   - also mentions all MISSING_ENTITIES,
   - removes filler phrases to make space,
   - stays clear and readable on its own.

Return your answer as valid JSON with exactly these keys:
- "initial_summary": string
- "missing_entities": list of strings
- "denser_summary": string

Do NOT wrap the JSON in backticks or markdown fences.
""".strip()


def _strip_code_fences(text: str) -> str:
    """
    Remove leading/trailing ``` / ```json fences if the model adds them.

    This handles outputs like:

        ```json
        { ... }
        ```
    """
    stripped = text.strip()
    if not stripped.startswith("```"):
        return stripped

    lines = stripped.splitlines()
    # Drop first line if it's a fence (``` or ```json)
    if lines and lines[0].lstrip().startswith("```"):
        lines = lines[1:]
    # Drop last line if it's a fence
    if lines and lines[-1].lstrip().startswith("```"):
        lines = lines[:-1]
    return "\n".join(lines).strip()


def run_simple_cod(review_text: str, model: ChatOpenAI) -> Dict[str, Any]:
    """
    Run a simple, single-step chain-of-density on one review.

    Returns a dict with:
        - initial_summary
        - missing_entities
        - denser_summary
    """
    prompt = build_cod_prompt(review_text)

    # Send the whole instruction as one message
    response = model.invoke(prompt)

    # The model is instructed to return JSON; parse it defensively
    content = _strip_code_fences(response.content or "")

    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Model did not return valid JSON: {content}") from exc

    # Minimal shape checks
    for key in ("initial_summary", "missing_entities", "denser_summary"):
        if key not in data:
            raise ValueError(f"Missing expected key '{key}' in model output: {data}")

    if not isinstance(data["missing_entities"], list):
        raise ValueError("missing_entities must be a list of strings")

    return data


if __name__ == "__main__":
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file or config module.")

    model = ChatOpenAI(
        model="gpt-4.1-mini",
        api_key=OPENAI_API_KEY,
        temperature=0.2,
    )

    long_review = """
    I ordered the ACME UltraComfort office chair last month after reading several
    positive reviews. Assembly was straightforward and the build quality looked
    solid at first. After two weeks, however, the right armrest started wobbling
    and making a loud creaking noise every time I moved. I also noticed that the
    lumbar support is fixed and sits too low for my height, even at the highest
    seat position. On the positive side, the seat cushion is comfortable and I
    like the breathable mesh back during long work days. Customer service offered
    to send a replacement armrest, but shipping will take another two weeks.
    Overall I am unsure whether to keep the chair or return it.
    """

    result = run_simple_cod(long_review, model)

    print("\nINITIAL SUMMARY:\n")
    print(result["initial_summary"])

    print("\nMISSING ENTITIES:\n")
    for entity in result["missing_entities"]:
        print(f"- {entity}")

    print("\nDENSER SUMMARY:\n")
    print(result["denser_summary"])
