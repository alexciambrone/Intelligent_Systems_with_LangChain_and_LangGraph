from langchain_classic.evaluation import load_evaluator

exact = load_evaluator("exact_match")

print(exact.evaluate_strings(prediction="OK", reference="OK"))
print(exact.evaluate_strings(prediction="ok", reference="OK"))


