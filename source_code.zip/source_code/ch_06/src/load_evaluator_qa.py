from langchain_classic.evaluation import load_evaluator
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY

judge_llm = ChatOpenAI(model="gpt-4o-mini", temperature=0, api_key=OPENAI_API_KEY)

evaluator = load_evaluator("qa", llm=judge_llm)

result = evaluator.evaluate_strings(
    input="What is the capital of France?",
    prediction="Paris.",
    reference="Paris",
)

print(result)
