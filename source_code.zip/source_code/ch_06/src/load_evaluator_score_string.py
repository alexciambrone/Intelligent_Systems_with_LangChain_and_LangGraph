from langchain_classic.evaluation import load_evaluator
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY


def print_score_eval(title: str, question: str, prediction: str, res: dict) -> None:
    line = "=" * 80
    print(f"\n{line}\n{title}\n{line}")
    print("INPUT     :", question)
    print("PREDICTION:", prediction)

    # score_string usually returns {"reasoning": "... Rating: [[10]]", "score": 1.0}
    score = res.get("score", "<?>")
    reasoning = (res.get("reasoning") or "").strip()

    print(f"\nSCORE (normalized 0..1): {score}")
    if reasoning:
        print("\nREASONING:\n" + reasoning)
    else:
        print("\nREASONING: <none>")

    extras = {k: v for k, v in res.items() if k not in {"score", "reasoning"}}
    if extras:
        print("\nEXTRA FIELDS:")
        for k, v in extras.items():
            print(f"- {k}: {v}")


judge_llm = ChatOpenAI(model="gpt-4o-mini", temperature=0, api_key=OPENAI_API_KEY)

score_eval = load_evaluator(
    "score_string",
    llm=judge_llm,
    criteria="correctness",
    normalize_by=10,
)

question = "What is the chemical formula for water?"
prediction = "H2O"

# IMPORTANT: score_string ignores "reference" by design (hence your warning),
# so don't pass it here.
result = score_eval.evaluate_strings(
    input=question,
    prediction=prediction,
)

print_score_eval("SCORE_STRING (correctness)", question, prediction, result)
