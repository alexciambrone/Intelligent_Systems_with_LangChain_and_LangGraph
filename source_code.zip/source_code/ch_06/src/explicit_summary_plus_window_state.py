from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Any

from .config import OPENAI_API_KEY

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, BaseMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI


@dataclass
class ConversationState:
    """Mixed memory: a running summary plus a window of recent messages."""
    summary: str = ""
    recent_messages: List[BaseMessage] = field(default_factory=list)


def approx_token_length(messages: List[BaseMessage]) -> int:
    """
    Very rough token proxy: count words across message contents.
    Good enough to trigger summarisation decisions in this example.
    """
    return sum(len((m.content or "").split()) for m in messages)


def build_summariser_chain(model: ChatOpenAI):
    """
    Chain that updates the running summary using the latest dialogue chunk.
    It takes the existing summary and new dialogue, and returns an updated summary.
    """
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You summarise long-running support conversations for later reuse. "
                    "Keep the summary concise (80–120 words) and focused on:\n"
                    "- the main problem,\n"
                    "- steps already taken,\n"
                    "- current status,\n"
                    "- any explicit user preferences or constraints.\n"
                    "Do not include greetings or small talk."
                ),
            ),
            (
                "human",
                (
                    "Existing summary (may be empty):\n"
                    "{existing_summary}\n\n"
                    "New dialogue turns:\n"
                    "{new_dialogue}\n\n"
                    "Update the summary so it reflects the whole conversation so far. "
                    "Overwrite the old summary; do not append a second one."
                ),
            ),
        ]
    )
    return prompt | model


def maybe_update_summary(
    state: ConversationState,
    summariser_chain,
    max_window_tokens: int = 80,
    max_total_tokens: int = 200,
) -> None:
    """
    Decide whether to fold recent messages into the summary.

    If the recent window is small, do nothing.
    If recent + summary is too large, summarise and shrink the window.
    """
    # If the recent window is still small, keep it as-is.
    if approx_token_length(state.recent_messages) <= max_window_tokens:
        return

    # Build a plain-text view of the recent dialogue.
    lines: List[str] = []
    for msg in state.recent_messages:
        if isinstance(msg, HumanMessage):
            prefix = "User"
        elif isinstance(msg, AIMessage):
            prefix = "Assistant"
        else:
            prefix = "Other"
        lines.append(f"{prefix}: {msg.content}")
    new_dialogue = "\n".join(lines)

    # Call the summariser to produce an updated running summary.
    updated_summary = summariser_chain.invoke(
        {
            "existing_summary": state.summary,
            "new_dialogue": new_dialogue,
        }
    )

    # Store the new summary.
    state.summary = updated_summary.content.strip()

    # Keep only the last few turns in the window to preserve local coherence.
    # Here we keep the last 2 user–assistant exchanges (4 messages) if available.
    if len(state.recent_messages) > 4:
        state.recent_messages = state.recent_messages[-4:]


def build_support_model() -> ChatOpenAI:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set. Check your config or .env file.")
    return ChatOpenAI(model="gpt-4.1-mini", temperature=0.2)


def build_support_system_message() -> SystemMessage:
    return SystemMessage(
        content=(
            "You are a patient, technically skilled support assistant. "
            "Use the conversation summary to remember the ongoing ticket, "
            "and the recent messages to respond naturally to the latest question. "
            "Ask clarifying questions when needed."
        )
    )


def build_assistant_reply(model: ChatOpenAI, state: ConversationState, user_text: str) -> AIMessage:
    """
    Build the prompt for the assistant using:
    - system instruction,
    - optional summary,
    - recent messages,
    - latest user message.
    """
    messages: List[BaseMessage] = [build_support_system_message()]

    if state.summary:
        messages.append(
            SystemMessage(
                content=f"Conversation summary so far:\n{state.summary}"
            )
        )

    # Include previous few messages for local context.
    messages.extend(state.recent_messages)

    # Add the latest user message.
    user_msg = HumanMessage(content=user_text)
    messages.append(user_msg)

    # Call the model.
    ai_msg = model.invoke(messages)

    # Update state with the new turn.
    state.recent_messages.append(user_msg)
    state.recent_messages.append(ai_msg)

    return ai_msg


def demo_long_running_ticket():
    model = build_support_model()
    summariser_model = build_support_model()
    summariser_chain = build_summariser_chain(summariser_model)

    state = ConversationState()

    user_turns = [
        "Hi, my web app keeps timing out when saving large reports.",
        "Yes, the error appears in the logs as a 504 gateway timeout.",
        "We tried increasing the load balancer timeout, but it still happens.",
        "Now it's mostly happening during peak traffic in the evenings.",
        "Given all this, what would you recommend as the next debugging step?"
    ]

    for i, text in enumerate(user_turns, start=1):
        print(f"\n=== USER TURN {i} ===")
        print(text)

        reply = build_assistant_reply(model, state, text)
        print("\nAssistant:")
        print(reply.content)

        # Maybe fold part of the window into the summary.
        maybe_update_summary(state, summariser_chain)

        print("\n[DEBUG] Current summary:")
        print(state.summary or "(no summary yet)")
        print("\n[DEBUG] Recent window size:", len(state.recent_messages))

    print("\n=== FINAL STATE ===")
    print("Summary:")
    print(state.summary)
    print("\nRecent messages:")
    for msg in state.recent_messages:
        role = "User" if isinstance(msg, HumanMessage) else "Assistant"
        print(f"{role}: {msg.content}")


if __name__ == "__main__":
    demo_long_running_ticket()



