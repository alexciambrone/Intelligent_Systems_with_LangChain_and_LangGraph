from langchain_classic.evaluation import load_evaluator

dist_eval = load_evaluator("string_distance", distance="damerau_levenshtein")

result = dist_eval.evaluate_strings(
    prediction="Order ID: 12346",
    reference="Order ID: 12345",
)

print(result)
