from .config import OPENAI_API_KEY

from typing import List

from langchain_core.documents import Document
from langchain_community.retrievers import BM25Retriever
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings, ChatOpenAI

# Advanced retrievers now live in langchain-classic on v1.x
from langchain_classic.retrievers import (
    EnsembleRetriever,
    ContextualCompressionRetriever,
)
from langchain_classic.retrievers.document_compressors import LLMChainExtractor
from langchain_core.prompts import ChatPromptTemplate


if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")


def build_corpus() -> List[Document]:
    """Create a small product manual + FAQ corpus with metadata."""
    docs = [
        Document(
            page_content=(
                "To reset the ACME Router X100 to factory settings, press and hold "
                "the reset button on the back for 10 seconds until the power light "
                "starts blinking. This will erase all custom configuration."
            ),
            metadata={
                "title": "ACME Router X100 – Factory reset",
                "doc_type": "manual",
                "version": "1.2",
            },
        ),
        Document(
            page_content=(
                "If your router is not responding, try unplugging it for 30 seconds "
                "and plugging it back in. This power cycle does not erase your settings."
            ),
            metadata={
                "title": "Troubleshooting unresponsive routers",
                "doc_type": "faq",
                "version": "3.0",
            },
        ),
        Document(
            page_content=(
                "You can change the Wi-Fi password from the web interface under "
                "Settings → Wireless. Changing the password will disconnect all devices."
            ),
            metadata={
                "title": "Changing your Wi-Fi password",
                "doc_type": "manual",
                "version": "1.0",
            },
        ),
        Document(
            page_content=(
                "Factory reset restores all options (Wi-Fi name, password, admin "
                "credentials) to their defaults. You will need to set up the router again."
            ),
            metadata={
                "title": "FAQ: What does factory reset do?",
                "doc_type": "faq",
                "version": "2.1",
            },
        ),
    ]
    return docs


def build_retrievers(docs: List[Document]):
    """Create lexical, vector, and hybrid (ensemble) retrievers over the same corpus."""
    # Lexical retriever (BM25-style)
    bm25_retriever = BM25Retriever.from_documents(docs)
    bm25_retriever.k = 4  # limit how many documents it returns

    # Vector retriever using a FAISS vector store
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    vectorstore = FAISS.from_documents(docs, embeddings)
    vector_retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

    # Hybrid retriever that combines lexical + vector results
    ensemble_retriever = EnsembleRetriever(
        retrievers=[bm25_retriever, vector_retriever],
        weights=[0.5, 0.5],
    )
    return ensemble_retriever


def build_compression_retriever(base_retriever):
    """Wrap the hybrid retriever with contextual compression."""
    llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0)
    compressor = LLMChainExtractor.from_llm(llm)

    compression_retriever = ContextualCompressionRetriever(
        base_compressor=compressor,
        base_retriever=base_retriever,
    )
    return compression_retriever, llm


def format_sources(docs: List[Document], max_chars: int = 280) -> str:
    """Turn a list of Documents into a compact, numbered sources block."""
    lines = []
    for idx, doc in enumerate(docs, start=1):
        title = doc.metadata.get("title", "Untitled")
        doc_type = doc.metadata.get("doc_type", "unknown")
        version = doc.metadata.get("version", "n/a")

        snippet = doc.page_content.strip().replace("\n", " ")
        if len(snippet) > max_chars:
            snippet = snippet[:max_chars].rstrip() + "..."

        lines.append(f"[{idx}] {title} ({doc_type}, v{version})\n{snippet}")
    return "\n\n".join(lines)


def build_prompt() -> ChatPromptTemplate:
    """Define a prompt that uses a sources section and asks for source-based answers."""
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You are a helpful support assistant for ACME routers. "
                    "Answer the question using only the information in the sources. "
                    "If the sources do not contain the answer, say you do not know."
                ),
            ),
            (
                "human",
                (
                    "Question:\n{question}\n\n"
                    "Sources:\n{sources}\n\n"
                    "Answer the question. When you refer to a fact, mention the "
                    "source index like [1], [2], etc."
                ),
            ),
        ]
    )
    return prompt


def answer_question(question: str):
    """Run retrieval + compression, then call the model with a structured sources block."""
    docs = build_corpus()
    ensemble_retriever = build_retrievers(docs)
    compression_retriever, llm = build_compression_retriever(ensemble_retriever)
    prompt = build_prompt()

    # 1) Selection: hybrid retrieval + contextual compression (v1 API)
    compressed_docs = compression_retriever.invoke(question)

    # 2) Packaging: build the sources string and inject it into the chat prompt
    sources_str = format_sources(compressed_docs)
    messages = prompt.format_messages(question=question, sources=sources_str)
    response = llm.invoke(messages)

    return response.content, compressed_docs, sources_str


if __name__ == "__main__":
    user_question = "How do I reset my ACME router to factory settings?"
    answer, used_docs, sources_block = answer_question(user_question)

    print("=== Answer ===")
    print(answer)
    print("\n=== Sources sent to the model ===")
    print(sources_block)
