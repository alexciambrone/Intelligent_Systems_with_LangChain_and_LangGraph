from __future__ import annotations

from typing import List

from .config import OPENAI_API_KEY

from langchain_core.messages import (
    SystemMessage,
    HumanMessage,
    AIMessage,
    BaseMessage,
    trim_messages,
)
from langchain_openai import ChatOpenAI


def build_model() -> ChatOpenAI:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set. Check your config or .env file.")
    # We use the same model both for token counting and for answering.
    return ChatOpenAI(model="gpt-4.1-mini", temperature=0.2)


def build_initial_history() -> List[BaseMessage]:
    """
    Build an artificial long conversation with a system prompt
    and several user/assistant exchanges.
    """
    system = SystemMessage(
        content=(
            "You are a helpful, concise support assistant for a SaaS analytics dashboard. "
            "Answer questions based only on the information in the conversation history."
        )
    )

    # Simulate several past turns that might push us over the token budget.
    turns: List[BaseMessage] = [
        HumanMessage(
            content=(
                "Hi, I'm trying to understand why my monthly active users metric suddenly "
                "dropped last week. Can you help me investigate?"
            )
        ),
        AIMessage(
            content=(
                "Sure. First, can you confirm which project or workspace you are looking at, "
                "and whether any filters are applied to the dashboard?"
            )
        ),
        HumanMessage(
            content=(
                "The project is 'Acme Retail Web', and I applied a segment for EU users only. "
                "I didn't change any other filters."
            )
        ),
        AIMessage(
            content=(
                "Thanks. Have there been any recent changes to your tracking implementation, "
                "such as SDK upgrades, new consent banners, or changes to event names?"
            )
        ),
        HumanMessage(
            content=(
                "Yes, we rolled out a new cookie consent banner last Tuesday. Some users may "
                "be opting out of tracking now. Also, our team renamed the 'page_view' event "
                "to 'screen_view' on mobile, but I thought the dashboard handled that."
            )
        ),
        AIMessage(
            content=(
                "That could explain part of the drop: users who decline cookies will no "
                "longer be counted, and renamed events might not be mapped yet. We should "
                "check the tracking diagnostics and event mapping settings."
            )
        ),
        HumanMessage(
            content=(
                "Today I also noticed a spike in 500 errors on the /events API endpoint. "
                "Could that be related to the drop in active users as well?"
            )
        ),
    ]

    return [system] + turns


def trim_history_for_budget(
    model: ChatOpenAI,
    messages: List[BaseMessage],
    max_tokens: int = 180,
) -> List[BaseMessage]:
    """
    Use trim_messages to enforce a token budget while keeping:
    - the system message,
    - a coherent conversation that starts with a human message,
    - as many recent turns as fit.
    """
    trimmed = trim_messages(
        messages=messages,
        max_tokens=max_tokens,
        # Let LangChain use the model's tokenizer to count tokens.
        token_counter=model,
        # Keep the last messages (most recent context) within the budget.
        strategy="last",
        # Always keep the system message if possible.
        include_system=True,
        # Ensure the resulting conversation starts with a human message
        # after the system instruction.
        start_on="human",
    )
    return trimmed


def run_windowed_conversation():
    model = build_model()

    # Start with a long history that might not fit comfortably in one prompt.
    history: List[BaseMessage] = build_initial_history()

    print("=== Full history (before trimming) ===")
    for msg in history:
        role = type(msg).__name__.replace("Message", "")
        print(f"{role}: {msg.content}\n")

    # Now the user asks a new question that we want to answer.
    latest_user_question = HumanMessage(
        content=(
            "Given everything we discussed, what are the top two checks I should run "
            "first to confirm whether the drop is caused by tracking changes or API errors?"
        )
    )
    history.append(latest_user_question)

    # Apply token-based trimming before calling the model.
    trimmed_history = trim_history_for_budget(model, history, max_tokens=180)

    print("\n=== History sent to the model (after trimming) ===")
    for msg in trimmed_history:
        role = type(msg).__name__.replace("Message", "")
        print(f"{role}: {msg.content}\n")

    # Ask the model to answer based on the trimmed window.
    response = model.invoke(trimmed_history)

    print("\n=== Assistant reply ===")
    print(response.content)


if __name__ == "__main__":
    run_windowed_conversation()



