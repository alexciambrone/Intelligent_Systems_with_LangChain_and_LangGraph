import random
from collections import Counter

from langchain_classic.evaluation import load_evaluator
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY

# 1) Judge model (LLM-as-a-judge)
judge_llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# 2) Pairwise evaluator: compares prediction vs prediction_b for the same input
pairwise = load_evaluator("pairwise_string", llm=judge_llm)

# 3) Tiny dataset: each item has the same input, and two candidate outputs
examples = [
    {
        "input": "Explain what an API is.",
        "baseline": "An API lets programs talk to each other.",
        "candidate": "An API is a contract that defines how software components communicate, usually via requests and responses.",
    },
    {
        "input": "Summarize: 'We will refund items within 30 days with proof of purchase.'",
        "baseline": "Refunds are possible.",
        "candidate": "Refunds are available within 30 days if you have proof of purchase.",
    },
    {
        "input": "What is the capital of France?",
        "baseline": "Paris.",
        "candidate": "The capital of France is Paris.",
    },
]

results = Counter()

for ex in examples:
    # Randomize order to reduce bias: sometimes baseline is A, sometimes candidate is A.
    a_is_candidate = random.choice([True, False])

    if a_is_candidate:
        pred_a = ex["candidate"]
        pred_b = ex["baseline"]
    else:
        pred_a = ex["baseline"]
        pred_b = ex["candidate"]

    verdict = pairwise.evaluate_string_pairs(
        input=ex["input"],
        prediction=pred_a,
        prediction_b=pred_b,
    )

    # Common output includes a preference-like field (often "value" or "preference").
    # To be robust, check both.
    preference = verdict.get("value") or verdict.get("preference")

    # Normalize outcome into win/loss/tie for the *candidate* variant.
    # Many pairwise judges return "A", "B", or "tie"/"equal". Handle common variants.
    pref_norm = str(preference).strip().lower()

    if pref_norm in ("a", "prediction", "first"):
        winner_is_candidate = a_is_candidate
    elif pref_norm in ("b", "prediction_b", "second"):
        winner_is_candidate = not a_is_candidate
    else:
        winner_is_candidate = None  # tie/unknown

    if winner_is_candidate is None:
        results["tie"] += 1
    elif winner_is_candidate:
        results["candidate_win"] += 1
    else:
        results["baseline_win"] += 1

print("Pairwise results:", dict(results))
total = sum(results.values()) or 1
print("Candidate win-rate:", results["candidate_win"] / total)



