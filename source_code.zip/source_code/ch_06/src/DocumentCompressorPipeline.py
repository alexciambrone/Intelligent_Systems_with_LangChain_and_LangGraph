from langchain_core.documents import Document
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_transformers import EmbeddingsRedundantFilter
from langchain_classic.retrievers import ContextualCompressionRetriever
from langchain_classic.retrievers.document_compressors import DocumentCompressorPipeline
from langchain_classic.retrievers.document_compressors import EmbeddingsFilter
from .config import OPENAI_API_KEY

# 1) A tiny corpus (in a real app this comes from loaders + splitters + indexing)
docs = [
    Document(
        id="a",
        page_content=(
            "Refund policy: you can request a refund within 30 days of purchase. "
            "Refunds are processed to the original payment method. "
            "Shipping fees are not refundable."
        ),
        metadata={"source": "policy"},
    ),
    Document(
        id="b",
        page_content=(
            "Returns policy: items can be returned within 30 days if unused and in original packaging. "
            "Contact support to obtain an RMA before sending items back."
        ),
        metadata={"source": "policy"},
    ),
    Document(
        id="c",
        page_content=(
            "Warranty: electronics have a 2-year limited warranty covering manufacturing defects. "
            "Accidental damage is not covered."
        ),
        metadata={"source": "warranty"},
    ),
]

# 2) Index the docs into a simple in-memory vector store (good enough for demos/tests)
embeddings = OpenAIEmbeddings()
vector_store = InMemoryVectorStore(embeddings)
vector_store.add_documents(docs)

base_retriever = vector_store.as_retriever(search_kwargs={"k": 8})

# 3) Build a multi-step refinement pipeline:
#    - split candidates into smaller chunks
#    - remove near-duplicate chunks
#    - keep only the top-k chunks most similar to the query
pipeline = DocumentCompressorPipeline(
    transformers=[
        RecursiveCharacterTextSplitter(chunk_size=120, chunk_overlap=20),
        EmbeddingsRedundantFilter(embeddings=embeddings),
        EmbeddingsFilter(embeddings=embeddings, k=3),
    ]
)

# 4) Wrap the base retriever with contextual compression (refinement happens after retrieval)
compression_retriever = ContextualCompressionRetriever(
    base_retriever=base_retriever,
    base_compressor=pipeline,
)

query = "Can I get a refund after 30 days?"
refined_docs = compression_retriever.invoke(query)

print("Refined documents (after split -> dedupe -> filter):\n")
for i, d in enumerate(refined_docs, start=1):
    src = d.metadata.get("source", "unknown")
    print(f"{i}. source={src} id={getattr(d, 'id', None)}")
    print(d.page_content)
    print("-" * 60)