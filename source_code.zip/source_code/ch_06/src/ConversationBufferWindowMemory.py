from langchain_classic.chains import ConversationChain
from langchain_classic.memory import ConversationBufferWindowMemory
from langchain_community.chat_models.fake import FakeListChatModel

# A deterministic chat model: each call returns the next response in the list.
chat_llm = FakeListChatModel(
    responses=[
        "Noted. What's the user's name?",
        "Got it. What city are they in?",
        "Thanks. I'll remember those details for the next step."
    ]
)

# Keep only the last 2 exchanges (user+assistant pairs).
memory = ConversationBufferWindowMemory(k=2, return_messages=True)

conversation = ConversationChain(llm=chat_llm, memory=memory, verbose=False)

conversation.predict(input="We are onboarding a new customer.")
conversation.predict(input="Her name is Ada.")
conversation.predict(input="She is based in Rome.")

# Show what the memory retained (only the most recent window).
# With return_messages=True, this is a list of chat messages (HumanMessage/AIMessage).
print("WINDOWED HISTORY:")
for msg in memory.chat_memory.messages:
    print(f"- {msg.type}: {msg.content}")


