from __future__ import annotations
from typing import List, Optional, Literal
from pydantic import BaseModel, Field, ValidationError
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY

# ---------------------------
# Pass 1 schema: the "coverage set" we refuse to lose
# ---------------------------

class CoverageSet(BaseModel):
    times: List[str] = Field(default_factory=list, description="Times like '09:12' (24h, leading zero).")
    region: Optional[Literal["EU", "US", "APAC"]] = Field(default=None, description="Region if stated.")
    error_code: Optional[str] = Field(default=None, description="HTTP error code like '502'.")
    impact_count: Optional[int] = Field(default=None, description="Numeric impact count, e.g. 1200.")
    impact_what: Optional[str] = Field(default=None, description="Short phrase, e.g. 'failed checkouts'.")
    cause: Optional[str] = Field(default=None, description="Short phrase, no full sentences.")
    mitigation: Optional[str] = Field(default=None, description="Short phrase, no full sentences.")
    follow_ups: List[str] = Field(default_factory=list, description="Short action items (phrases).")

def required_tokens_from_coverage(cov: CoverageSet) -> List[str]:
    # Turn structured coverage into a small set of exact tokens that MUST appear verbatim in the summary.
    # Keep this strict so omissions are detectable.
    tokens: List[str] = []
    tokens.extend(cov.times)

    if cov.region:
        tokens.append(cov.region)

    if cov.error_code:
        tokens.append(cov.error_code)

    if cov.impact_count is not None:
        tokens.append(str(cov.impact_count))

    if cov.impact_what:
        tokens.append(cov.impact_what)

    if cov.cause:
        tokens.append(cov.cause)

    if cov.mitigation:
        tokens.append(cov.mitigation)

    # Optional: include only first 2 follow-ups as strict tokens (avoid over-constraining).
    tokens.extend(cov.follow_ups[:2])

    # De-duplicate (preserve order)
    seen = set()
    out: List[str] = []
    for t in tokens:
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out

def assert_summary_covers(summary: str, required_tokens: List[str]) -> None:
    missing = [tok for tok in required_tokens if tok not in summary]
    if missing:
        raise AssertionError(f"Summary is missing required tokens: {missing}")

# ---------------------------
# Demo
# ---------------------------
if __name__ == "__main__":
    # Requires OPENAI_API_KEY in your environment.
    llm = ChatOpenAI(model="gpt-4.1", temperature=0)

    # Pass 1 will return a validated Pydantic object.
    extractor = llm.with_structured_output(CoverageSet)

    source_text = (
        "At 09:12 CET, we saw a spike in 502s on the checkout API (EU region only). "
        "Error rate peaked at ~18% between 09:18–09:31. "
        "We rolled back the gateway config change deployed at 09:05 and errors dropped by 09:36. "
        "Preliminary cause: misconfigured header rewrite rule affecting requests with X-Client-Version < 4.2. "
        "Mitigation applied: feature flag gw_header_rewrite disabled in EU only. "
        "Follow-up needed: confirm whether any orders were dropped and reconcile payment provider logs; "
        "also add a regression test for the header rewrite rule. "
        "Customer impact: approximately 1,200 failed checkouts."
    )

    # ---------------------------
    # Pass 1: extract coverage set (LLM -> Pydantic)
    # ---------------------------
    extraction_messages = [
        ("system",
         "Extract an incident coverage set. "
         "Return only the schema fields. "
         "Make cause and mitigation SHORT phrases (not sentences). "
         "Make follow_ups a list of short phrases. "
         "Use times exactly like '09:12' (24h). "
         "If a field is not present, leave it null/empty."),
        ("user", source_text),
    ]

    try:
        coverage: CoverageSet = extractor.invoke(extraction_messages)
    except ValidationError as e:
        raise RuntimeError(f"Structured extraction failed validation: {e}") from e

    print("PASS 1 CoverageSet:")
    print(coverage.model_dump())
    print()

    required_tokens = required_tokens_from_coverage(coverage)

    # ---------------------------
    # Pass 2: write summary under a contract (must include tokens)
    # ---------------------------
    summary_messages = [
        ("system",
         "Write a concise incident handover summary in <= 120 words. "
         "Hard requirement: include every REQUIRED TOKEN verbatim somewhere in the summary. "
         "Do not add new numbers. Do not rename tokens."),
        ("user",
         "SOURCE:\n"
         f"{source_text}\n\n"
         "REQUIRED TOKENS (must appear verbatim):\n"
         + "\n".join(f"- {t}" for t in required_tokens)),
    ]

    summary_msg = llm.invoke(summary_messages)
    summary = summary_msg.content

    print("PASS 2 Summary:")
    print(summary)
    print()

    # ---------------------------
    # Contract check
    # ---------------------------
    assert_summary_covers(summary, required_tokens)
    print("OK: summary includes every required token from the extracted coverage set.")