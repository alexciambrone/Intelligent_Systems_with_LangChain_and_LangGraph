from .config import OPENAI_API_KEY

from datetime import date
from typing import List, Dict, Any

from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import ChatPromptTemplate


# -------------------------------------------------------------------
# Corpus: research notes and risk policies with rich metadata
# -------------------------------------------------------------------


def build_research_corpus() -> List[Document]:
    """
    Create a small corpus of research and policy documents.
    Each document has metadata we can use for filtering.
    """
    return [
        Document(
            page_content=(
                "AAPL is a large-cap US tech stock with strong cash flows. "
                "Current risks include concentration in a few product lines "
                "and exposure to US consumer demand."
            ),
            metadata={
                "title": "AAPL risk overview Q1",
                "instrument": "AAPL",
                "region": "US",
                "doc_type": "research_note",
                "published_at": "20250210",
            },
        ),
        Document(
            page_content=(
                "TSLA remains highly volatile and sensitive to changes in interest "
                "rates and EV subsidies. Position sizing should reflect this."
            ),
            metadata={
                "title": "TSLA volatility and macro sensitivity",
                "instrument": "TSLA",
                "region": "US",
                "doc_type": "research_note",
                "published_at": "20250120",
            },
        ),
        Document(
            page_content=(
                "For retail clients in the EU with medium risk tolerance, "
                "single-stock positions should generally not exceed 10% of "
                "total portfolio value."
            ),
            metadata={
                "title": "EU retail risk policy",
                "instrument": "ALL",
                "region": "EU",
                "doc_type": "risk_policy",
                "published_at": "20241101",
            },
        ),
        Document(
            page_content=(
                "For retail clients in the US with medium risk tolerance, "
                "single-stock positions should generally not exceed 8% of "
                "total portfolio value."
            ),
            metadata={
                "title": "US retail risk policy",
                "instrument": "ALL",
                "region": "US",
                "doc_type": "risk_policy",
                "published_at": "20241215",
            },
        ),
    ]


def build_vectorstore(docs: List[Document]) -> Chroma:
    """
    Build a simple in-memory vector store that supports metadata filters.
    """
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")

    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    vectorstore = Chroma.from_documents(
        documents=docs,
        embedding=embeddings,
        collection_name="trading_research",
    )
    return vectorstore


# -------------------------------------------------------------------
# Structured state: portfolio and user profile → compact text blocks
# -------------------------------------------------------------------


def build_sample_portfolio() -> Dict[str, Any]:
    return {
        "positions": [
            {"symbol": "AAPL", "size": 120, "entry_price": 175.0},
            {"symbol": "TSLA", "size": 40, "entry_price": 220.0},
        ]
    }


def build_sample_profile() -> Dict[str, Any]:
    return {
        "risk_tolerance": "medium",
        "base_currency": "USD",
        "region": "US",
    }


def format_portfolio_snapshot(portfolio: Dict[str, Any]) -> str:
    """
    Turn a portfolio dict into a terse, three-line-style snapshot.
    """
    lines: List[str] = []
    for pos in portfolio.get("positions", []):
        symbol = pos["symbol"]
        size = pos["size"]
        entry_price = pos["entry_price"]
        lines.append(f"- {symbol}: {size} shares @ {entry_price:.2f}")
    if not lines:
        return "No open positions."
    return "\n".join(lines)


def format_profile_summary(profile: Dict[str, Any]) -> str:
    """
    Turn user profile into one or two short sentences.
    """
    risk = profile.get("risk_tolerance", "unknown")
    currency = profile.get("base_currency", "USD")
    region = profile.get("region", "US")
    return (
        f"Client region: {region}. Base currency: {currency}. "
        f"Declared risk tolerance: {risk}."
    )


# -------------------------------------------------------------------
# Retrieval and packaging: metadata filters + state-driven blocks
# -------------------------------------------------------------------


from typing import List, Dict, Any
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document

def retrieve_filtered_docs(
    vectorstore: Chroma,
    question: str,
    instruments: List[str],
    region: str,
    min_date: int,
) -> List[Document]:
    """
    Use metadata filters so we only retrieve documents relevant to
    the current positions and region.

    - instrument in user_instruments OR generic policy docs (instrument == 'ALL')
    - region matches the user's region
    - published_at >= min_date (numeric YYYYMMDD)
    """
    filter_dict: Dict[str, Any] = {
        "$and": [
            {
                "$or": [
                    {"instrument": {"$in": instruments}},
                    {"instrument": {"$eq": "ALL"}},
                ]
            },
            {"region": {"$eq": region}},
            {"published_at": {"$gte": min_date}},
        ]
    }

    docs = vectorstore.similarity_search(
        question,
        k=4,
        filter=filter_dict,
    )
    return docs


def format_sources_block(docs: List[Document]) -> str:
    """
    Format retrieved documents into a compact 'sources' section.
    """
    if not docs:
        return "No recent research or risk policies available."

    lines: List[str] = []
    for idx, d in enumerate(docs, start=1):
        meta = d.metadata
        title = meta.get("title", "Untitled")
        instrument = meta.get("instrument", "N/A")
        region = meta.get("region", "N/A")
        published_at = meta.get("published_at", "N/A")
        snippet = d.page_content.strip().replace("\n", " ")
        if len(snippet) > 240:
            snippet = snippet[:240].rstrip() + "..."
        lines.append(
            f"[{idx}] {title} (instrument={instrument}, region={region}, "
            f"published_at={published_at})\n{snippet}"
        )
    return "\n\n".join(lines)


def build_prompt() -> ChatPromptTemplate:
    """
    Prompt that takes a profile block, a sources block, and the question.
    """
    return ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You are a trading assistant preparing a concise risk summary for "
                    "a client's equity portfolio. Use only the provided profile and "
                    "sources. If information is missing, say so explicitly."
                ),
            ),
            (
                "human",
                (
                    "Client profile:\n{profile_block}\n\n"
                    "Current portfolio:\n{portfolio_block}\n\n"
                    "Relevant research and policies:\n{sources_block}\n\n"
                    "Question:\n{question}\n\n"
                    "Write a short risk summary (3–5 sentences) that:\n"
                    "- highlights key risks for the current positions,\n"
                    "- relates them to the client's stated risk tolerance and region,\n"
                    "- does not invent facts not supported by the sources."
                ),
            ),
        ]
    )


def generate_risk_summary() -> None:
    """
    End-to-end context assembly and model call.
    """
    docs = build_research_corpus()
    vectorstore = build_vectorstore(docs)

    portfolio = build_sample_portfolio()
    profile = build_sample_profile()

    # Derived state used for filtering
    user_instruments = [p["symbol"] for p in portfolio["positions"]]
    user_region = profile["region"]
    cutoff_date = 20241201  # numeric YYYYMMDD, aligned with metadata

    question = "What are the main portfolio risks I should be aware of right now?"

    # 1) Selection: metadata-filtered retrieval
    filtered_docs = retrieve_filtered_docs(
        vectorstore=vectorstore,
        question=question,
        instruments=user_instruments,
        region=user_region,
        min_date=cutoff_date,
    )

    # 2) Packaging: profile + portfolio + sources
    profile_block = format_profile_summary(profile)
    portfolio_block = format_portfolio_snapshot(portfolio)
    sources_block = format_sources_block(filtered_docs)

    prompt = build_prompt()
    messages = prompt.format_messages(
        profile_block=profile_block,
        portfolio_block=portfolio_block,
        sources_block=sources_block,
        question=question,
    )

    llm = ChatOpenAI(model="gpt-4.1-mini", temperature=0.0)
    response = llm.invoke(messages)

    print("=== Risk summary ===")
    print(response.content)


if __name__ == "__main__":
    generate_risk_summary()
