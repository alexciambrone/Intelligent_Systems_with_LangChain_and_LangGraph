from __future__ import annotations
import os
from .config import GOOGLE_API_KEY
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from google.genai.types import HarmBlockThreshold, HarmCategory

def main() -> None:
    if not GOOGLE_API_KEY:
        raise RuntimeError("GOOGLE_API_KEY is not set (export it in your environment).")

    # Safety settings example from the LangChain reference
    safety_settings = {
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_ONLY_HIGH,
        HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE,
        HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
    }

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",
        temperature=0.3,
        top_p=0.95,
        top_k=40,
        max_tokens=200,
        request_timeout=30,
        max_retries=2,
        stop=["\n\nUser:", "\n\nHuman:"],
        seed=42,
        safety_settings=safety_settings,
        model_kwargs={}
    )

    resp = llm.invoke(
        [
            HumanMessage(
                content="Explain LangChain in one short paragraph. Keep it concrete."
            )
        ]
    )

    print("MODEL RESPONSE:")
    print(resp.content)

if __name__ == "__main__":
    main()
