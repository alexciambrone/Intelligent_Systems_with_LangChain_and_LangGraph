from langchain_community.callbacks.manager import get_openai_callback
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY
 
llm = ChatOpenAI(model = "gpt-4o-mini", temperature = 0)
 
with get_openai_callback() as cb:
	response = llm.invoke("Write a two-sentence summary of why token accounting matters.")
	print(response.content)
 
	# Aggregate usage for everything executed in the with-block
	print("prompt_tokens:", cb.prompt_tokens)
	print("completion_tokens:", cb.completion_tokens)
	print("total_tokens:", cb.total_tokens)
	print("total_cost:", cb.total_cost)  # may be 0.0 if pricing metadata is unavailable
