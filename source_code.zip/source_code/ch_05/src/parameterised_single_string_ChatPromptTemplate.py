from .config import OPENAI_API_KEY

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

# --- Basic safety checks so failures are clear up front ---
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")


# ChatOpenAI wrapper for modern chat models
support_chat_model = ChatOpenAI(
    model="gpt-4.1-mini",   # chat model → must use ChatOpenAI
    temperature=0.0
)

support_chat_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            (
                "You are a first-line customer support assistant for ACME Telecom. "
                "Answer clearly and politely. If you are not sure, say so and suggest "
                "how the customer can get help from a human agent."
            ),
        ),
        (
            "human",
            "Customer question: {question}\n\nAccount flags: {account_flags}",
        ),
    ]
)

support_chat_chain = support_chat_prompt | support_chat_model

reply = support_chat_chain.invoke(
    {
        "question": "My broadband is down. Can I get a refund for today's outage?",
        "account_flags": "Customer has had 3 outages in 30 days; loyalty tier: Gold.",
    }
)

print(reply.content)
