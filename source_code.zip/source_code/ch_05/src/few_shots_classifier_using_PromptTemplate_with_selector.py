from .config import OPENAI_API_KEY
from langchain_core.prompts import PromptTemplate
from langchain_core.prompts.few_shot import FewShotPromptTemplate
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_core.vectorstores import InMemoryVectorStore
from langchain_openai import OpenAIEmbeddings, ChatOpenAI

# Basic safety checks so failures are clear
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")

# Example library: questions and ideal explanations for different instruments
risk_examples = [
    {
        "question": "What are the main risks of holding a single tech stock?",
        "answer": "High idiosyncratic risk: company-specific news can move the price sharply.",
    },
    {
        "question": "What are the risks of a leveraged ETF that tracks an index?",
        "answer": "Leverage amplifies both gains and losses and can suffer from daily rebalancing decay.",
    },
    {
        "question": "What are the risks of selling a covered call on my shares?",
        "answer": "You cap your upside and may be forced to sell the shares if the option is exercised.",
    },
    {
        "question": "What are the risks of holding a long-dated government bond?",
        "answer": "Interest-rate risk: prices can fall if yields rise; inflation can erode real returns.",
    },
]

example_prompt = PromptTemplate.from_template(
    "Question: {question}\nExplanation: {answer}"
)

# Embeddings and vector store for semantic similarity over example questions
embeddings = OpenAIEmbeddings(model="text-embedding-3-small")

# Build a selector that retrieves the 3 most similar examples per query
example_selector = SemanticSimilarityExampleSelector.from_examples(
    examples=risk_examples,
    embeddings=embeddings,
    vectorstore_cls=InMemoryVectorStore,
    k=3,
    input_keys=["question"],
)

risk_prefix = """
You are a trading risk assistant.

Task:
Explain the main risks of the user's position in plain language.
Use the examples to match style and level of detail.
"""

risk_suffix = """
Question: {question}
Explanation:
"""

dynamic_risk_prompt = FewShotPromptTemplate(
    example_selector=example_selector,
    example_prompt=example_prompt,
    prefix=risk_prefix.strip(),
    suffix=risk_suffix.strip(),
    input_variables=["question"],
)

risk_llm = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.2,
)

risk_chain = dynamic_risk_prompt | risk_llm

result = risk_chain.invoke(
    {
        "question": "What are the risks of holding a 3x leveraged ETF tracking bank stocks?",
    }
)

print(result.content)