import os
import sqlite3
from typing import Any, Dict

from langchain_community.utilities import SQLDatabase
from langchain_experimental.sql import SQLDatabaseChain
from langchain_openai import ChatOpenAI
from langchain_community.callbacks.manager import get_openai_callback

from .config import OPENAI_API_KEY


def ensure_demo_db(db_path: str) -> None:
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    con = sqlite3.connect(db_path)
    try:
        cur = con.cursor()

        # Allowed table
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS deals (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              customer TEXT NOT NULL,
              discount_pct REAL NOT NULL
            );
            """
        )

        # A table we DO NOT want the chain to access
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS secrets (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              api_key TEXT NOT NULL
            );
            """
        )

        cur.execute("SELECT COUNT(*) FROM deals;")
        (count,) = cur.fetchone()
        if count == 0:
            cur.executemany(
                "INSERT INTO deals(customer, discount_pct) VALUES(?, ?);",
                [
                    ("Globex", 10.0),
                    ("Globex", 15.0),
                    ("Initech", 5.0),
                    ("Umbrella", 20.0),
                ],
            )

        cur.execute("SELECT COUNT(*) FROM secrets;")
        (scount,) = cur.fetchone()
        if scount == 0:
            cur.executemany(
                "INSERT INTO secrets(api_key) VALUES(?);",
                [
                    ("SUPER-SECRET-KEY-123",),
                    ("TOP-SECRET-KEY-456",),
                ],
            )

        con.commit()
    finally:
        con.close()


def run(question: str) -> Dict[str, Any]:
    here = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(here, "demo", "deals.db")
    ensure_demo_db(db_path)

    # Restrict the database “surface area” the chain can see.
    # include_tables controls what appears in table_info (and therefore what the LLM can plan against).
    db = SQLDatabase.from_uri(
        f"sqlite:///{db_path}",
        include_tables=["deals"],  # <--- THIS is the restriction
        sample_rows_in_table_info=2,
    )

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0, api_key=OPENAI_API_KEY)

    chain = SQLDatabaseChain.from_llm(
        llm=llm,
        db=db,
        verbose=True,  # prints what it's doing, including generated SQL
        return_intermediate_steps=True,  # lets us print the SQL cleanly
    )

    out = chain.invoke({"query": question})

    # SQLDatabaseChain typically returns:
    # - out["result"] as the final natural-language answer
    # - out["intermediate_steps"] containing the SQL and/or tool traces (format can vary by version)
    return out


def main() -> None:
    question = "What is the average discount percentage for Globex, and how many deals does that include?"

    if get_openai_callback is not None:
        with get_openai_callback() as cb:
            out = run(question)

            print("\nAnswer:", out.get("result"))

            steps = out.get("intermediate_steps")
            if steps:
                print("\n--- Intermediate steps ---")
                for s in steps:
                    print(s)

            print("\n--- Token usage ---")
            print("Total tokens:", getattr(cb, "total_tokens", None))
            print("Prompt tokens:", getattr(cb, "prompt_tokens", None))
            print("Completion tokens:", getattr(cb, "completion_tokens", None))
            print("Estimated cost:", getattr(cb, "total_cost", None))
    else:
        out = run(question)
        print("\nAnswer:", out.get("result"))
        steps = out.get("intermediate_steps")
        if steps:
            print("\n--- Intermediate steps ---")
            for s in steps:
                print(s)

    # Demonstrate the restriction works: "secrets" is not even visible in table info.
    # (Optional sanity check – safe to remove.)
    # print("\nVisible tables:", SQLDatabase.from_uri(...).get_usable_table_names())


if __name__ == "__main__":
    main()
