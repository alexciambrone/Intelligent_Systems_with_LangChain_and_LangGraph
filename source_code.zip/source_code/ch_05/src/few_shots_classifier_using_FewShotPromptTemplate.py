from .config import OPENAI_API_KEY
from langchain_core.prompts import PromptTemplate
from langchain_core.prompts.few_shot import FewShotPromptTemplate
from langchain_openai import ChatOpenAI

# Basic safety checks so failures are clear
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")

# Few-shot intent classifier for support tickets
examples = [
    {
        "message": "I want to cancel my internet contract at the end of this month.",
        "label": "CANCELLATION",
    },
    {
        "message": "You charged me twice for the same bill.",
        "label": "BILLING",
    },
    {
        "message": "My router keeps disconnecting every few minutes.",
        "label": "TECHNICAL",
    },
    {
        "message": "Can I upgrade to a faster plan?",
        "label": "OTHER",
    },
]

example_prompt = PromptTemplate.from_template(
    "Message: {message}\nLabel: {label}"
)

support_prefix = """
You are a customer-support triage assistant for ACME Telecom.

Task:
Read each customer message and assign exactly one label:
- BILLING
- TECHNICAL
- CANCELLATION
- OTHER

Use the examples to understand the labelling rule.
"""

support_suffix = """
Message: {message}
Label:
"""

few_shot_support_prompt = FewShotPromptTemplate(
    examples=examples,
    example_prompt=example_prompt,
    prefix=support_prefix.strip(),
    suffix=support_suffix.strip(),
    input_variables=["message"],
)

support_llm = ChatOpenAI(
    model="gpt-4.1-mini",
    temperature=0.0,
)

support_chain = few_shot_support_prompt | support_llm

result = support_chain.invoke(
    {
        "message": "I changed my mind and want to stop my contract next week.",
    }
)

print(result.content)