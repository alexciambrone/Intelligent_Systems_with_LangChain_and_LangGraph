from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Optional
from openai import OpenAI
from .config import OPENAI_API_KEY

@dataclass
class ModerationBlocked(Exception):
    message: str
    flagged: bool
    categories: Dict[str, bool]
    category_scores: Dict[str, float]

    def __str__(self) -> str:
        return self.message


def moderate_text(
    text: str,
    *,
    model: str = "omni-moderation-latest",
    error: bool = True,
    client: Optional[OpenAI] = None,
) -> Dict[str, Any]:
    """
    Moderates a single text input using OpenAI's Moderations endpoint.

    If error=True (fail-closed), raises ModerationBlocked when flagged.
    If error=False, returns the moderation payload so the caller can decide.

    Returns a dict with:
      - flagged (bool)
      - categories (dict[str,bool])
      - category_scores (dict[str,float])
      - raw (full response object)
    """
    client = client or OpenAI()

    response = client.moderations.create(
        model=model,
        input=text,
    )

    # OpenAI returns a list of results; for a single string input it's length 1.
    result = response.results[0]
    flagged = bool(result.flagged)

    categories = dict(result.categories) if result.categories is not None else {}
    category_scores = (
        dict(result.category_scores) if result.category_scores is not None else {}
    )

    payload = {
        "flagged": flagged,
        "categories": categories,
        "category_scores": category_scores,
        "raw": response,
    }

    if flagged and error:
        raise ModerationBlocked(
            message="Blocked by moderation.",
            flagged=flagged,
            categories=categories,
            category_scores=category_scores,
        )

    return payload


def main() -> None:
    safe_text = "Summarise the plot of Frankenstein in two sentences."
    safe = moderate_text(safe_text, error=True)
    print("SAFE:", safe["flagged"], safe_text)

    # A clearly unsafe request should raise when error=True.
    try:
        moderate_text("I want instructions to harm someone.", error=True)
    except ModerationBlocked as exc:
        print("BLOCKED:", exc)
        # Optional: show why
        print("Categories:", {k: v for k, v in exc.categories.items() if v})


if __name__ == "__main__":
    main()
