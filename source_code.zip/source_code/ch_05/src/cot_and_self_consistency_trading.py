from .config import OPENAI_API_KEY
from collections import Counter
import os
import re
from typing import List, Tuple

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your environment or .env file.")

# --- Chain-of-thought prompt ------------------------------------------------
cot_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            (
                "You are a cautious trading assistant. "
                "You explain your reasoning before giving a concise final answer.\n\n"
                "When you answer, follow this format exactly:\n"
                "THINKING:\n"
                "<step-by-step reasoning here>\n"
                "ANSWER:\n"
                "<short final answer here>"
            ),
        ),
        (
            "human",
            (
                "A client holds a 3x leveraged ETF on a bank index. "
                "The index falls by {index_move_percent}%. "
                "The ETF is {position_weight_percent}% of the portfolio value.\n\n"
                "What is the approximate percentage impact of this ETF position "
                "on the total portfolio, and why?"
            ),
        ),
    ]
)

cot_model = ChatOpenAI(
    model="gpt-4.1-mini",
    temperature=0.2,  # low temperature for a single, stable CoT path
)

cot_chain = cot_prompt | cot_model

def extract_final_answer(text: str) -> str:
    """
    Extract the short final answer from the model output.

    We expect the model to follow:

        THINKING:
        ...
        ANSWER:
        <short final answer>

    This helper is intentionally simple. For production use, consider a
    structured output format or an explicit JSON schema.
    """
    # Split on "ANSWER:" and take the part after it, if present.
    match = re.split(r"ANSWER:\s*", text, maxsplit=1, flags=re.IGNORECASE)
    if len(match) == 2:
        return match[1].strip()
    return text.strip()

def run_cot_once(index_move_percent: float, position_weight_percent: float) -> Tuple[str, str]:
    """
    Run a single chain-of-thought reasoning pass.

    Returns a tuple: (full_output, final_answer).
    """
    result = cot_chain.invoke(
        {
            "index_move_percent": index_move_percent,
            "position_weight_percent": position_weight_percent,
        }
    )
    full_text = result.content
    final_answer = extract_final_answer(full_text)
    return full_text, final_answer

# --- Self-consistency wrapper -----------------------------------------------
def self_consistent_answer(
    index_move_percent: float,
    position_weight_percent: float,
    num_samples: int = 7,
    temperature: float = 0.7,
) -> Tuple[str, List[Tuple[str, int]]]:
    """
    Run the CoT chain multiple times with higher temperature and return
    a self-consistent final answer.

    Args:
        index_move_percent: Move of the underlying index, e.g. -5.0 for -5%.
        position_weight_percent: Portfolio weight of the ETF, e.g. 20.0 for 20%.
        num_samples: How many reasoning paths to sample.
        temperature: Sampling temperature; higher values produce more diverse reasoning.

    Returns:
        A tuple:
          - selected_answer: the most frequent final answer across samples.
          - answer_counts: a list of (answer, count) pairs, sorted by count descending.
    """
    # Use a separate model instance so we can adjust temperature for sampling
    sampling_model = ChatOpenAI(
        model="gpt-4.1-mini",
        temperature=temperature,
    )
    sampling_chain = cot_prompt | sampling_model

    answers: List[str] = []

    for _ in range(num_samples):
        result = sampling_chain.invoke(
            {
                "index_move_percent": index_move_percent,
                "position_weight_percent": position_weight_percent,
            }
        )
        full_text = result.content
        final_answer = extract_final_answer(full_text)
        answers.append(final_answer)

    counts = Counter(answers)
    # Most common returns list of (answer, count) pairs
    most_common = counts.most_common()

    if not most_common:
        raise RuntimeError("No answers generated during self-consistency sampling.")

    selected_answer = most_common[0][0]
    # Convert Counter items to a stable list of tuples for inspection / logging
    answer_counts = [(ans, cnt) for ans, cnt in most_common]

    return selected_answer, answer_counts


# --- Example usage ----------------------------------------------------------
def main():
    """
    Demonstrate both a single CoT run and the self-consistent aggregation.

    Scenario:
      - 3x leveraged ETF on a bank index.
      - Index falls by 4%.
      - ETF is 15% of total portfolio value.
    """
    index_move = -4.0
    position_weight = 15.0

    print("=== Single chain-of-thought run ===")
    full_output, final_answer = run_cot_once(index_move, position_weight)
    print(full_output)
    print("\nParsed final answer:")
    print(final_answer)

    print("\n=== Self-consistent answer over multiple runs ===")
    selected, counts = self_consistent_answer(
        index_move_percent=index_move,
        position_weight_percent=position_weight,
        num_samples=9,
        temperature=0.8,
    )

    print("\nSelected final answer (self-consistent):")
    print(selected)

    print("\nAnswer distribution:")
    for ans, cnt in counts:
        print(f"{cnt} × {ans}")


if __name__ == "__main__":
    main()

