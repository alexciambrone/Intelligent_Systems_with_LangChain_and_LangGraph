import os
from langchain_openai import ChatOpenAI
from .config import OPENAI_API_KEY
from langchain_classic.chains import LLMMathChain
from langchain_community.callbacks.manager import get_openai_callback

def run_math_question(question: str) -> None:
    # Model configured to be deterministic: math translation benefits from low
    # randomness.
    llm = ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0,
    )

    llm_math = LLMMathChain.from_llm(llm=llm, verbose=True)

    with get_openai_callback() as cb:
        result = llm_math.invoke(question)
        print("Question:", question)
        print("Answer:", result)
        print("Tokens:", cb.total_tokens)
        print("Prompt tokens:", cb.prompt_tokens)
        print("Completion tokens:", cb.completion_tokens)
        print("Estimated cost:", cb.total_cost)


if __name__ == "__main__":
    run_math_question(
        "If I invest 100,000 EUR and it grows by 3.5% per year, what is the value after 7 years?"
    )
