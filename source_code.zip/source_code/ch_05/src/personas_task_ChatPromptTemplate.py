from .config import OPENAI_API_KEY
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI

# --- Basic safety checks so failures are clear up front ---
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")


# ChatOpenAI wrapper for modern chat models
catalog_model = ChatOpenAI(
    model="gpt-4.1-mini",   # chat model → must use ChatOpenAI
    temperature=0.0
)

catalog_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            (
                "You are a product search assistant for ACME Shop. "
                "Help users find products in the catalog and explain trade-offs. "
                "If a product is not in the catalog context, do not invent it."
            ),
        ),
        (
            "human",
            """
User query:
{user_query}

<CATALOG_CONTEXT>
{catalog_context}
</CATALOG_CONTEXT>

Task:
1. Use only products mentioned in CATALOG_CONTEXT.
2. Suggest up to three options that fit the user query.
3. Explain the differences in one short paragraph.
""",
        ),
    ]
)

support_chat_chain = catalog_prompt | catalog_model

# Simple fake catalog context – in later chapters this will
# come from a database or vector store
catalog_context = """
- ACME UltraLight 14" Laptop, 16 GB RAM, 512 GB SSD, ideal for travel and office work.
- ACME CreatorPro 15" Laptop, 32 GB RAM, 1 TB SSD, dedicated GPU, designed for video editing and 3D work.
- ACME BudgetBook 13" Laptop, 8 GB RAM, 256 GB SSD, good for web browsing and email.
"""

user_query = "I need a laptop that can handle video editing and some light gaming."

result = support_chat_chain.invoke(
    {
        "user_query": user_query,
        "catalog_context": catalog_context,
    }
)

# result is an AIMessage from ChatOpenAI
print(result.content)