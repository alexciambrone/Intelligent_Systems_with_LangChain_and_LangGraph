from .config import OPENAI_API_KEY

from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

# --- Basic safety checks so failures are clear up front ---
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")


# ChatOpenAI wrapper for modern chat models
policy_llm = ChatOpenAI(
    model="gpt-4.1-mini",   # chat model → must use ChatOpenAI
    temperature=0.0
)

base_prompt = PromptTemplate.from_template(
    """
You are a customer support helper for {brand_name}.

Task:
Explain the policy below to a new support agent in simple language.
Keep the explanation under 120 words.

Policy:
{policy_text}
"""
)

policy_prompt = base_prompt.partial(brand_name="ACME Telecom")

# LCEL pipeline: PromptTemplate → ChatOpenAI
policy_chain = policy_prompt | policy_llm

result = policy_chain.invoke(
    {
        "policy_text": (
            "Customers can cancel a new broadband contract within 14 days of activation "
            "with no penalty. After 14 days, an early termination fee applies."
        )
    }
)

# ChatOpenAI returns an AIMessage; print only the text content
print(result.content)
