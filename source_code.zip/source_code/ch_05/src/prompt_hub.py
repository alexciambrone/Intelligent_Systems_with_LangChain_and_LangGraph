import os

from langsmith import Client
from .config import OPENAI_API_KEY
from langchain_openai import ChatOpenAI

if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your environment or .env file.")

# Pulling via LangSmith client (private prompts can be referenced without an owner handle)
client = Client()

# Pull the version pointed to by a tag (e.g., "prod") OR pin a specific commit hash.
# prompt_by_tag = client.pull_prompt("joke-generator:prod")
# prompt_by_commit = client.pull_prompt("joke-generator:12344e88")
prompt = client.pull_prompt("hardkothari/prompt-maker")

llm = ChatOpenAI()

# Use the pulled prompt like any other prompt template
chain = prompt | llm
result = chain.invoke({"lazy_prompt": "Talk about Rome", "task": "Write a short, factual paragraph"})
print(result)
