from .config import OPENAI_API_KEY
import json
from typing import List, Dict, Any

from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI


def build_model() -> ChatOpenAI:
    """
    Build and return the ChatOpenAI model used across all chains.
    """
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set. Check your environment or .env file.")

    tot_model = ChatOpenAI(
        model="gpt-4.1-mini",
        temperature=0.2,  # low temperature for a single, stable CoT path
    )
    return tot_model


def build_generator_chain(model: ChatOpenAI):
    """
    Thought generator:
    Given the problem state, propose several alternative campaign ideas.
    """
    generator_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You are a senior e-commerce strategist for an online retailer.\n"
                    "Given a product category, a business goal, and constraints, "
                    "you must propose exactly three distinct campaign ideas.\n"
                    "Label them A, B, and C.\n"
                    "Each idea must be one or two short paragraphs and clearly actionable."
                ),
            ),
            (
                "human",
                (
                    "Product category: {product_category}\n"
                    "Business goal: {goal}\n"
                    "Constraints: {constraints}\n\n"
                    "Propose three distinct campaign ideas (A, B, C)."
                ),
            ),
        ]
    )
    return generator_prompt | model


def build_evaluator_chain(model: ChatOpenAI):
    """
    Evaluator:
    Score each idea using a simple rubric and return JSON so we can parse it.

    The model reads the raw ideas text and outputs a JSON array like:
    [
      {"id": "A", "score": 8, "rationale": "..."},
      {"id": "B", "score": 6, "rationale": "..."},
      {"id": "C", "score": 9, "rationale": "..."}
    ]
    """
    evaluator_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You are evaluating e-commerce campaign ideas for a retail business.\n"
                    "Rate each idea on a scale from 1 to 10 based on:\n"
                    "- expected impact on the stated business goal,\n"
                    "- feasibility under the constraints,\n"
                    "- risk of harming customer experience.\n"
                    "Higher scores are better.\n\n"
                    "Return your evaluation as JSON only, no extra text.\n"
                    "The JSON must be an array of objects with fields:\n"
                    "  id (A, B, or C), score (integer 1-10), rationale (short string)."
                ),
            ),
            (
                "human",
                (
                    "Product category: {product_category}\n"
                    "Business goal: {goal}\n"
                    "Constraints: {constraints}\n\n"
                    "Here are the campaign ideas:\n"
                    "-----------------------------\n"
                    "{ideas_text}\n"
                    "-----------------------------\n\n"
                    "Evaluate ideas A, B, and C and output JSON as specified."
                ),
            ),
        ]
    )
    return evaluator_prompt | model


def build_explainer_chain(model: ChatOpenAI):
    """
    Explainer:
    Turn the winning idea into a concise explanation for a business stakeholder.
    """
    explainer_prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                (
                    "You are a senior product manager.\n"
                    "Explain the chosen campaign idea clearly to a non-technical stakeholder.\n"
                    "Focus on what the campaign does and why it is a good fit "
                    "for the goal and constraints."
                ),
            ),
            (
                "human",
                (
                    "Product category: {product_category}\n"
                    "Business goal: {goal}\n"
                    "Constraints: {constraints}\n\n"
                    "All campaign ideas (A, B, C):\n"
                    "{all_ideas}\n\n"
                    "Evaluations (JSON):\n"
                    "{evaluations_json}\n\n"
                    "The best idea according to the evaluation is: {best_id}.\n"
                    "Explain this idea and justify briefly why it is the best choice."
                ),
            ),
        ]
    )
    return explainer_prompt | model


def parse_evaluations(json_text: str) -> List[Dict[str, Any]]:
    """
    Parse the evaluator's JSON output safely.

    Raises ValueError if parsing fails or if the structure is not as expected.
    """
    data = json.loads(json_text)
    if not isinstance(data, list):
        raise ValueError("Expected a JSON array of evaluations.")
    for item in data:
        if not isinstance(item, dict):
            raise ValueError("Each evaluation must be a JSON object.")
        if "id" not in item or "score" not in item:
            raise ValueError("Each evaluation must have 'id' and 'score' fields.")
    return data


def select_best_idea(evaluations: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Search strategy:
    Pick the idea with the highest score.
    If there is a tie, the first with that score wins.
    """
    return max(evaluations, key=lambda e: e["score"])


def main():
    """
    Minimal end-to-end example of a tree-of-thought style reasoning path:

    1. Generate several candidate campaign ideas (branching).
    2. Evaluate and score each idea (thought evaluation).
    3. Select the best idea via a simple search step.
    4. Explain the chosen idea to a stakeholder.
    """
    # Example problem state
    problem = {
        "product_category": "running shoes",
        "goal": "increase repeat purchases from existing customers over the next quarter",
        "constraints": "avoid deep discounts, respect existing loyalty tiers, no changes to shipping policy",
    }

    model = build_model()

    # 1. Generate candidate ideas
    generator_chain = build_generator_chain(model)
    ideas_msg = generator_chain.invoke(problem)
    ideas_text = ideas_msg.content
    print("=== Generated campaign ideas ===")
    print(ideas_text)
    print()

    # 2. Evaluate ideas with a rubric and JSON output
    evaluator_chain = build_evaluator_chain(model)
    eval_msg = evaluator_chain.invoke(
        {
            **problem,
            "ideas_text": ideas_text,
        }
    )
    print("=== Raw evaluations (JSON) ===")
    print(eval_msg.content)
    print()

    evaluations = parse_evaluations(eval_msg.content)
    best = select_best_idea(evaluations)

    # 3. Explain the chosen idea to a stakeholder
    explainer_chain = build_explainer_chain(model)
    explanation_msg = explainer_chain.invoke(
        {
            **problem,
            "all_ideas": ideas_text,
            "evaluations_json": json.dumps(evaluations, indent=2),
            "best_id": best["id"],
        }
    )

    print("=== Selected best idea ===")
    print(f"ID: {best['id']}, score: {best['score']}")
    print()
    print("=== Stakeholder explanation ===")
    print(explanation_msg.content)


if __name__ == "__main__":
    main()
