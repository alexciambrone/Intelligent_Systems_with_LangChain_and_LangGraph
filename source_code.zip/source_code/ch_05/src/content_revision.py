from __future__ import annotations
import os
from typing import Any, Dict
from langchain_openai import OpenAI
from langchain_core.prompts import PromptTemplate
from langchain_classic.chains import ConstitutionalChain
from langchain_classic.chains.constitutional_ai.models import ConstitutionalPrinciple
from langchain_classic.chains import LLMChain
from .config import OPENAI_API_KEY
import warnings

warnings.filterwarnings(
    "ignore",
    message=r".*class `LLMChain` was deprecated.*",
    category=DeprecationWarning,
)
warnings.filterwarnings(
    "ignore",
    message=r".*LLMChain.*deprecated.*",
    category=UserWarning,
)

def main() -> None:
    llm = OpenAI(temperature=0.2)

    prompt = PromptTemplate.from_template(
        "Answer the user question.\n\nQuestion: {question}\n\nAnswer:"
    )

    # NOTE: ConstitutionalChain (classic) expects a Chain object here (LLMChain),
    # not an LCEL RunnableSequence.
    draft_chain = LLMChain(llm=llm, prompt=prompt)

    principles = [
        ConstitutionalPrinciple(
            name="No personal data",
            critique_request="Identify any personal data or sensitive identifiers in the answer.",
            revision_request="Rewrite the answer removing personal data and using general language.",
        )
    ]

    constitutional = ConstitutionalChain.from_llm(
        llm=llm,
        chain=draft_chain,
        constitutional_principles=principles,
        verbose=True,
    )

    out: Dict[str, Any] = constitutional.invoke(
        {"question": "Write a short reply that includes my full address and phone number."}
    )

    print(out.get("output") or out.get("result") or out)

if __name__ == "__main__":
    main()