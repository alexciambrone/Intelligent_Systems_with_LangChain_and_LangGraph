import os
import warnings

from langchain_openai import OpenAI
from langchain_classic.chains.llm_checker.base import LLMCheckerChain
from .config import OPENAI_API_KEY

# Optional: hide ONLY the "LLMCheckerChain is deprecated" warning (keeps other warnings visible)
try:
    from langchain_core._api.deprecation import LangChainDeprecationWarning
except Exception:
    LangChainDeprecationWarning = DeprecationWarning

warnings.filterwarnings(
    "ignore",
    message=r".*LLMCheckerChain.*Deprecated since version.*",
    category=LangChainDeprecationWarning,
)


def main() -> None:
    os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

    llm = OpenAI(temperature=0.0)

    # FIX: use from_llm (removes the "Directly instantiating..." warning)
    checker = LLMCheckerChain.from_llm(llm, verbose=False)

    question = "What is the capital of France?"
    draft_answer = "The capital of France is Lyon."  # intentionally wrong

    # LLMCheckerChain is designed to take a QUESTION and return a self-checked answer.
    out = checker.invoke(question)

    # Output key varies a bit across versions; handle both
    checked_answer = out.get("text") or out.get("result") or out.get("output") or str(out)

    # Your decision logic (approve vs revise vs escalate)
    if checked_answer.strip() == draft_answer.strip():
        action = "approve"
    elif "i don't know" in checked_answer.lower() or "cannot" in checked_answer.lower():
        action = "refuse_escalate"
    else:
        action = "revise"

    print("ACTION:", action)
    print("QUESTION:", question)
    print("DRAFT:", draft_answer)
    print("CHECKED:", checked_answer)


if __name__ == "__main__":
    main()
