from .config import GOOGLE_API_KEY
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_google_genai import ChatGoogleGenerativeAI

# --- Basic safety checks so failures are clear up front ---
if not GOOGLE_API_KEY:
    raise RuntimeError("GOOGLE_API_KEY is not set. Check your .env file.")

trading_model = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0.2)

prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a trading assistant. Explain risks in plain language."),
        MessagesPlaceholder("history"),
        ("human", "{question}"),
    ]
)

chain = prompt | trading_model

# Your full conversation store (could come from anywhere)
full_history = [
    ("human", "What is diversification?"),
    ("ai", "It means spreading investments across different assets..."),
    ("human", "What is volatility?"),
    ("ai", "Volatility is how much prices move up and down..."),
]

def build_history(full_history, mode: str):
    if mode == "none":
        return []
    if mode == "last_turn":
        return full_history[-2:]  # last human+ai pair
    if mode == "only_user":
        return [m for m in full_history if m[0] == "human"]
    if mode == "last_4_messages":
        return full_history[-4:]
    return full_history  # default: everything

# Call 1: no history
answer1 = chain.invoke(
    {"history": build_history(full_history, "none"), "question": "Is 60% tech risky?"}
)
print(answer1.content)

# Call 2: include last turn only
answer2 = chain.invoke(
    {"history": build_history(full_history, "last_turn"), "question": "And what about ETFs?"}
)
print(answer2.content)

# Call 3: include everything
answer3 = chain.invoke(
    {"history": build_history(full_history, "all"), "question": "Summarize what we've covered."}
)
print(answer3.content)