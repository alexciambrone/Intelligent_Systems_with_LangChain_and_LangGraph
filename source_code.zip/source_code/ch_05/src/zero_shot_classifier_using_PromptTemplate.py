from .config import OPENAI_API_KEY
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

# Basic safety checks so failures are clear
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")
    
# Zero-shot intent classifier for support tickets
support_intent_prompt = PromptTemplate.from_template(
    """
You are a customer-support triage assistant for ACME Telecom.

Task:
Read the customer message and classify it into exactly one of:
- BILLING
- TECHNICAL
- CANCELLATION
- OTHER

Output only the label.

Customer message:
{message}
"""
)

classifier_model = ChatOpenAI(
    model="gpt-4.1-mini",   # chat model → must use ChatOpenAI
    temperature=0.2
)

intent_chain = support_intent_prompt | classifier_model

result = intent_chain.invoke(
    {
        "message": "My internet has been very slow since yesterday evening.",
    }
)

print(result.content)
