from .config import OPENAI_API_KEY
from langchain_core.prompts import (
	ChatPromptTemplate,
	FewShotChatMessagePromptTemplate,
)
from langchain_openai import ChatOpenAI
 
# Basic safety checks so failures are clear
if not OPENAI_API_KEY:
	raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")
 
# Example library: short, realistic e-commerce conversations
examples = [
	{
    	"customer_query": "I'm buying a mid-range gaming laptop. What else should I add?",
    	"assistant_reply": (
        	"You could add a cooling pad to keep the laptop temperature stable "
        	"during long sessions, and a mid-range gaming mouse for better control."
    	),
	},
	{
    	"customer_query": "I just ordered a mirrorless camera body. Any accessories?",
    	"assistant_reply": (
        	"A fast prime lens will improve low-light and portrait shots, "
        	"and an extra battery helps on long shooting days."
    	),
	},
	{
    	"customer_query": "I'm getting a new 4K TV for my living room.",
    	"assistant_reply": (
        	"Consider a soundbar for clearer dialogue and richer sound, "
        	"and a wall mount if you want to save floor space."
    	),
	},
]
 
# How each example appears as a chat exchange: one human turn, one assistant turn
example_prompt = ChatPromptTemplate.from_messages(
	[
    	("human", "{customer_query}"),
    	("ai", "{assistant_reply}"),
	]
)
 
# Few-shot message block: expands into alternating human/ai messages
few_shot_examples = FewShotChatMessagePromptTemplate(
	examples=examples,
	example_prompt=example_prompt,
)
 
# Full chat prompt:
# - system message for role and rules
# - few-shot examples as real chat history
# - live human message with the current customer query
recommendation_prompt = ChatPromptTemplate.from_messages(
	[
    	(
        	"system",
        	(
            	"You are an e-commerce assistant for ACME Shop. "
            	"For each customer query, suggest at most two complementary products. "
            	"Keep answers concise, practical, and avoid marketing buzzwords."
        	),
    	),
    	few_shot_examples,
    	("human", "{customer_query}"),
	]
)
 
model = ChatOpenAI(
	model="gpt-4.1-mini",
	temperature=0.3,
)
 
chain = recommendation_prompt | model
 
result = chain.invoke(
	{
    	"customer_query": (
        	"I'm ordering wireless noise-cancelling headphones. "
        	"What else would you suggest?"
    	),
	}
)
 
print(result.content)