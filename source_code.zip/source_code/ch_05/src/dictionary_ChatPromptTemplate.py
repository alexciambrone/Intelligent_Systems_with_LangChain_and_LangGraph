# src/dictionary_ChatPromptTemplate.py

from .config import OPENAI_API_KEY

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough, RunnableLambda
from langchain_openai import ChatOpenAI


# --- Basic safety checks so failures are clear up front ---
if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your .env file.")


# ChatOpenAI wrapper for modern chat models
analysis_model = ChatOpenAI(
    model="gpt-4.1-mini",   # chat model → must use ChatOpenAI
    temperature=0.0,
    api_key=OPENAI_API_KEY,  # explicit, so readers see where the key is used
)

# --- Minimal "retriever" so the example actually runs ---
#
# In later chapters, this will be something like:
#   retriever = vectorstore.as_retriever(search_kwargs={"k": 4})
#
# For now we ignore the question and always return the same context string.
portfolio_context = """
- 40% in large European bank stocks
- 25% in broad market index ETFs
- 20% in medium-duration government bonds
- 15% in cash and money-market instruments

Bank stocks are more volatile than bonds and broad market ETFs.
If bank stocks fall sharply, overall portfolio value can drop,
especially in the short term.
"""

retriever = RunnableLambda(lambda question: portfolio_context)

analysis_prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            (
                "You are a trading assistant. Use the CONTEXT section to explain "
                "portfolio risks in plain language. Do not give personalised advice."
            ),
        ),
        (
            "human",
            """
CONTEXT:
{context}

QUESTION:
{question}
""",
        ),
    ]
)

# Dict input:
# - "question" = whatever the user passes in
# - "context"  = retriever(question)
analysis_chain = (
    {
        "question": RunnablePassthrough(),
        "context": retriever,
    }
    | analysis_prompt
    | analysis_model
)


if __name__ == "__main__":
    user_question = "How sensitive is my portfolio to a sudden fall in bank stocks?"
    response = analysis_chain.invoke(user_question)

    # response is an AIMessage
    print(response.content)
