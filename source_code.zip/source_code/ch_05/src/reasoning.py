from .config import OPENAI_API_KEY
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

if not OPENAI_API_KEY:
    raise RuntimeError("OPENAI_API_KEY is not set. Check your environment or .env file.")

template = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a problem-solving assistant."),
        ("user", "{problem}")
    ]
)

chat = ChatOpenAI(
    model="o3-mini",
    reasoning_effort="high",  # commonly: "low" | "medium" | "high" (some setups also support "minimal")
)

chain = template | chat
response = chain.invoke({"problem": "Design an algorithm to find the kth largest element in an unsorted array."})
print(response.content)


