from __future__ import annotations

import os
from typing import Dict

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

from .config import OPENAI_API_KEY


def main() -> None:
    if not OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set.")

    # Example token bias: discourage these tokens
    logit_bias: Dict[str, int] = {
        "2869": -100,  # " sorry"
        "6342": -100,  # " apologize"
    }

    llm = ChatOpenAI(
        model="gpt-4.1-mini",
        temperature=0.3,
        top_p=0.95,
        max_tokens=200,              # alias of max_completion_tokens
        request_timeout=30,          # seconds
        max_retries=2,
        stop=["\n\nUser:", "\n\nHuman:"],
        frequency_penalty=0.2,
        presence_penalty=0.1,
        logit_bias=logit_bias,
        seed=42,                     # IMPORTANT: pass explicitly (not in model_kwargs)
        model_kwargs={
            # Extra OpenAI request fields (only those valid for your endpoint/model)
            "response_format": {"type": "text"},
        },
    )

    resp = llm.invoke(
        [HumanMessage(content="Explain LangChain in one short paragraph. Avoid apologetic language.")]
    )
    print(resp.content)


if __name__ == "__main__":
    main()
