from langchain_core.prompts import PromptTemplate, ChatPromptTemplate

# A reusable system instruction block expressed as a PromptTemplate.
system_prompt_template = PromptTemplate.from_template("a: {a} b: {b}")

# Compose it into a multi-message chat prompt.
chat_prompt_template = ChatPromptTemplate.from_messages(
    [
        ("system", system_prompt_template.template),
        ("human", "hi"),
        ("ai", "{c}"),
    ]
)

# invoke() returns a prompt value object; access .messages to get the list.
prompt_value = chat_prompt_template.invoke({"a": "a", "b": "b", "c": "c"})
messages = prompt_value.messages

# messages is now a list of structured chat messages in the right order.
# In a real chain you would pass it to a chat model.
print(len(messages))
print(messages[0].content)
print(messages[1].content)
print(messages[2].content)
