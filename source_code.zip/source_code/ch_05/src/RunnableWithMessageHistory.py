from __future__ import annotations

from typing import Dict

from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_openai import ChatOpenAI

from .config import GOOGLE_API_KEY

# --- Basic safety checks so failures are clear up front ---
# NOTE: This checks GOOGLE_API_KEY, but ChatOpenAI typically uses OPENAI_API_KEY.
# Keep or change this depending on how your .config is wired.
if not GOOGLE_API_KEY:
    raise RuntimeError("GOOGLE_API_KEY is not set. Check your .env file.")

# Simple in-memory history store keyed by session_id.
# Replace this with a database-backed implementation when you need durability.
_sessions: Dict[str, InMemoryChatMessageHistory] = {}


def get_session_history(session_id: str) -> InMemoryChatMessageHistory:
    if session_id not in _sessions:
        _sessions[session_id] = InMemoryChatMessageHistory()
    return _sessions[session_id]


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are a concise support assistant. Use the conversation history."),
        MessagesPlaceholder("history"),
        ("human", "{input}"),
    ]
)

model = ChatOpenAI(model="gpt-4.1-mini", temperature=0.2)

base_chain = prompt | model

chat_chain = RunnableWithMessageHistory(
    base_chain,
    get_session_history,
    input_messages_key="input",
    history_messages_key="history",
)


def print_history(session_id: str) -> None:
    """Pretty-print the stored chat history for a session."""
    history = get_session_history(session_id)
    print("\n=== InMemoryChatMessageHistory ===")
    print("Session:", session_id)
    print("Message count:", len(history.messages))
    for i, m in enumerate(history.messages, start=1):
        # m is a BaseMessage (HumanMessage / AIMessage / SystemMessage)
        role = m.type  # "human", "ai", "system"
        content = m.content
        print(f"{i:02d}. {role}: {content}")
    print("=== end ===\n")


if __name__ == "__main__":
    session_id = "acme-ticket-1042"
    cfg = {"configurable": {"session_id": session_id}}

    r1 = chat_chain.invoke(
        {"input": "Hi. My dashboard shows a sudden drop in active users."},
        config=cfg,
    )
    r2 = chat_chain.invoke(
        {"input": "What are the first two checks you would run?"},
        config=cfg,
    )

    print("Stored message count:", len(get_session_history(session_id).messages))
    print("Last reply:", r2.content)

    # Print the whole history at the end
    print_history(session_id)
